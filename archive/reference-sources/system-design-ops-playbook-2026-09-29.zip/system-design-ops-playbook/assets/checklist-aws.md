# AWS初期設計チェックリスト

## 最優先(後から変えにくい)
- [ ] AWS Organizations 構成(OU、アカウント一覧:管理/ログアーカイブ/監査/本番/ステージング/開発/サンドボックス)
- [ ] Control Tower(ランディングゾーン)の採用有無
- [ ] リージョン(メイン/DR)とデータ所在地要件
- [ ] VPC CIDR割り当て表(既存NW・オンプレ・将来分と重複なし)
- [ ] サブネット構成(パブリック/プライベートApp/プライベートDB × AZ数)
- [ ] IaCツール(Terraform / CDK / CloudFormation)と state 管理方法
- [ ] 手作業でのリソース作成禁止ルール

## セキュリティ(初日)
- [ ] 全アカウントのルートユーザーにMFA、アクセスキーなし
- [ ] IAM Identity Center、権限セット一覧、MFA必須
- [ ] IAMユーザーの長期アクセスキー原則禁止(CI/CDはOIDC)
- [ ] SCPによるガードレール(リージョン制限、CloudTrail停止禁止等)
- [ ] CloudTrail組織証跡 → ログアーカイブアカウントのS3(Object Lock)
- [ ] GuardDuty / Security Hub / AWS Config 有効化(委任管理者=監査アカウント)
- [ ] S3ブロックパブリックアクセス(アカウント単位)
- [ ] EBS/RDS/S3のデフォルト暗号化、KMSキー方針
- [ ] Secrets Manager / Parameter Store の使い分け

## 運用
- [ ] 命名規則:______
- [ ] 必須タグ:Project / Environment / Owner / CostCenter / ManagedBy
- [ ] コンピュート方式と理由(ADR):______
- [ ] データストア方式・マルチAZ:______
- [ ] CloudWatch Logs 保存期間(全ロググループ)
- [ ] アラームと通知先(SNS → Slack/オンコール)
- [ ] AWS Backup プラン(頻度・保持・別リージョン/別アカウントコピー)
- [ ] CI/CD と本番デプロイ承認フロー
- [ ] ランタイム・エンジンバージョンのEOL管理(Lambda/RDS/EKS等)

## コスト
- [ ] AWS Budgets(80%実績・100%予測で通知)
- [ ] コスト配分タグの有効化
- [ ] Cost Anomaly Detection
- [ ] 開発環境の夜間停止
- [ ] Savings Plans は利用安定後に検討(日付:____)
- [ ] サポートプラン:______

## 体制
- [ ] AWSアカウント管理責任者:______
- [ ] セキュリティアラート確認者:______
- [ ] コスト確認者と頻度:______
- [ ] 障害時連絡体制:______

## Well-Architected レビュー
- [ ] 運用上の優秀性
- [ ] セキュリティ
- [ ] 信頼性
- [ ] パフォーマンス効率
- [ ] コスト最適化
- [ ] 持続可能性
