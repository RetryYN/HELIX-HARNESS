# 05. 「なるべく書かない」と依存関係・外部サービスの更新管理

## 目次
1. なぜ「なるべくコードを書かない」になるのか
2. 任せるもの/自分で書くもの
3. 任せることで生まれる新しい保守
4. 更新管理:気づく・試す・影響を小さくする
5. 運用のリズムと具体的な設定例

---

## 1. なぜ「なるべくコードを書かない」になるのか

- コードは書いた瞬間から保守の対象。**資産であると同時に負債**
- 自前で作ると、機能を作る手間より、その後のセキュリティ対応・バグ修正・引き継ぎのほうがずっと重い
- 正確には:**「書くべきところに集中するために、それ以外はなるべく書かない」**。守る範囲を小さくすれば、守るべきところを丁寧に守れる

## 2. 任せるもの/自分で書くもの

| 分野 | 任せる先の例 |
|---|---|
| ログ・トレース | OpenTelemetry、既存のロガー、Datadog/CloudWatch |
| 認証 | Auth0、Amazon Cognito、Entra ID、Firebase Authentication |
| 決済 | Stripe、PAY.JP等 |
| キュー・DB | SQS、RDS/Aurora、DynamoDB などのマネージドサービス |
| メール送信 | Amazon SES、SendGrid |
| 検索 | OpenSearch Service 等 |

**自分で書くべきもの**:自社ビジネスの核になるロジック(注文の状態遷移、割引ルール、独自の業務フロー)。既製品では代わりにならず、他社との違いになる部分。

## 3. 任せることで生まれる新しい保守

「書かない」は「考えない」ではない。

- バージョンアップ対応
- サービスの仕様変更・API廃止・サービス終了
- 障害時に中身が見えない(提供元の復旧待ち)
- 料金体系の変更
- ベンダーロックイン(抜けにくくなる)

→ 使うものを選ぶ目と、**差し替えやすいよう間に一枚かませる設計**が大事。

## 4. 更新管理:3つの仕組み

### 気づく仕組み
| 対象 | 方法 |
|---|---|
| ライブラリ | Dependabot / Renovate で新バージョンのPRを自動作成。脆弱性は優先度を上げて通知 |
| 脆弱性 | GitHubのDependabot alerts、Snyk、Trivy(コンテナイメージ)、Amazon Inspector |
| 外部API | チェンジログ、非推奨(deprecation)告知メール、ステータスページを購読。**担当者を決めて**定期確認 |
| EOL | 言語、フレームワーク、OS、DB、クラウドのランタイムのサポート終了日を一覧化(endoflife.date等で確認)して計画的に上げる |

### 安全に試す仕組み
- いきなり本番に入れない:**CIで自動テスト → ステージングで動作確認 → 本番**
- テストが充実していれば、更新して壊れていないかを機械的に確認できる(テスト=生きた仕様書)
- 外部APIには**契約テスト**(Pactなど)やモックで「このAPIがこう返したらこう動く」を検証

### 影響を小さくする設計
- **バージョン固定**:ロックファイル(package-lock.json、poetry.lock、go.sum 等)で正確なバージョンを固定
- **APIバージョン固定**:Stripeのようにバージョン指定できるサービスは明示的に固定。提供元の更新で勝手に挙動が変わるのを防ぎ、自分たちのタイミングで上げる
- **アダプター層(ラッパー)**:外部サービスを直接あちこちから呼ばず、一か所に集約。変更・乗り換え時の修正箇所が一か所で済む

```python
# 悪い例:あちこちで stripe.PaymentIntent.create(...) を直接呼ぶ

# 良い例:アダプター層
class PaymentGateway:            # インターフェース
    def charge(self, amount: int, currency: str, idempotency_key: str) -> "ChargeResult": ...

class StripeGateway(PaymentGateway):
    def charge(self, amount, currency, idempotency_key):
        intent = stripe.PaymentIntent.create(
            amount=amount, currency=currency,
            idempotency_key=idempotency_key,
        )
        return ChargeResult(id=intent.id, status=intent.status)
```

## 5. 運用のリズムと具体的な設定例

- 「毎週(または毎月)決まった日に依存関係の更新をまとめて処理する」リズムを作る
- 放置するとバージョン差が開き、一気に上げるのが大変になる → **小さく、こまめに上げる**
- メジャーアップデートは個別にチケット化し、リリースノートの破壊的変更(Breaking Changes)を確認

### Dependabot(.github/dependabot.yml)
```yaml
version: 2
updates:
  - package-ecosystem: "npm"
    directory: "/"
    schedule:
      interval: "weekly"
      day: "monday"
      time: "09:00"
      timezone: "Asia/Tokyo"
    open-pull-requests-limit: 10
    groups:
      minor-and-patch:
        update-types: ["minor", "patch"]
  - package-ecosystem: "docker"
    directory: "/"
    schedule:
      interval: "weekly"
  - package-ecosystem: "github-actions"
    directory: "/"
    schedule:
      interval: "monthly"
```

### Renovate(renovate.json)
```json
{
  "extends": ["config:recommended"],
  "timezone": "Asia/Tokyo",
  "schedule": ["before 9am on monday"],
  "packageRules": [
    { "matchUpdateTypes": ["minor", "patch"], "groupName": "minor and patch", "automerge": true },
    { "matchUpdateTypes": ["major"], "labels": ["major-update"] }
  ],
  "vulnerabilityAlerts": { "labels": ["security"] }
}
```

### EOL管理表の例
| 対象 | 現バージョン | EOL | 次の目標 | 担当 | 期限 |
|---|---|---|---|---|---|
| Node.js | (記入) | (公式で確認) | 次のLTS | | |
| PostgreSQL(RDS) | | | | | |
| Lambdaランタイム | | | | | |
| EKS(Kubernetes) | | | | | |
