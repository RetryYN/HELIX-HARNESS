# 01. ログ設計

## 目次
1. ログの種類(レイヤー別)とログレベル
2. 実務でよく設定するもの
3. 網羅的な設定項目
4. ログ設計が重要な理由
5. 書きすぎの弊害と対策
6. 後から差し込む難しさ
7. ログを極めると何が変わるか(設計も含めて)
8. 具体的な設定例

---

## 1. ログの種類(レイヤー別)

| レイヤー | 主なログ | 用途 |
|---|---|---|
| アプリケーション | アプリケーションログ、エラーログ、デバッグログ、業務ログ(注文・決済などのイベント) | 動作確認、障害調査、業務追跡 |
| Web/プロキシ | アクセスログ、エラーログ(Nginx、Apache、ロードバランサー) | リクエスト分析、不正アクセス検知 |
| データベース | エラーログ、スロークエリログ、一般クエリログ、トランザクションログ(MySQL binlog、PostgreSQL WAL)、監査ログ | 性能改善、障害復旧、操作追跡 |
| OS | syslog / journald、カーネルログ(dmesg)、Windowsイベントログ | システム障害、ハードウェア異常 |
| 認証・セキュリティ | 認証ログ(/var/log/auth.log、/var/log/secure)、監査ログ(auditd)、権限変更ログ、sudoログ | 不正検知、コンプライアンス |
| ネットワーク | ファイアウォールログ、VPCフローログ、DNSクエリログ、WAFログ、IDS/IPSログ | 通信の追跡、攻撃検知 |
| クラウド基盤 | 操作ログ(AWS CloudTrail、Azure Activity Log、GCP Cloud Audit Logs)、S3等のアクセスログ | 誰が何を変更したかの記録 |
| コンテナ・オーケストレーション | コンテナの標準出力、Kubernetesの監査ログ・イベント | 分散環境での追跡 |
| ジョブ・バッチ | バッチ実行ログ、cronログ | 定期処理の成否確認 |
| 運用 | デプロイログ、CI/CDログ、設定変更履歴 | 変更と障害の突き合わせ |

### ログレベル
| レベル | 使いどころ | 例 |
|---|---|---|
| DEBUG | 開発時の詳細な内部状態。本番では原則出さない | 変数の中身、SQL全文 |
| INFO | 正常な業務イベントの節目 | 注文確定、ジョブ開始/終了、ログイン成功 |
| WARN | 異常ではないが注意が必要。放置すると問題化 | リトライ発生、閾値接近、非推奨API使用 |
| ERROR | 処理が失敗。人の確認が必要な可能性 | 決済失敗、外部API 5xx、未処理例外 |
| FATAL | システムが継続不能 | 起動失敗、DB接続不能で全停止 |

## 2. 実務でよく設定するもの

最低限セット:**アプリケーションログ・エラーログ・アクセスログ**。セキュリティ要件があれば**監査ログ(認証ログ)**を追加。

- **ログレベル**:本番はINFOまたはWARN以上、開発はDEBUG。本番DEBUGはログ量増大と機密情報出力のリスク。
- **出力先**:コンテナ環境は標準出力 → 集約基盤(Datadog、CloudWatch Logs、Elasticsearch/OpenSearch、Loki)が主流。
- **ローテーション・保存期間**:Linuxはlogrotateで日次またはサイズ単位、圧縮、世代管理。保存期間は社内規定・法令に合わせる(監査ログは1年以上がよくある目安)。
- **フォーマット**:JSON構造化ログ。最低限 timestamp / level / request_id / message。

## 3. 網羅的な設定項目

| 設定項目 | 内容・よくある設定 |
|---|---|
| ログレベル | 本番INFO/WARN以上、開発DEBUG。モジュール単位で個別に変更可能にする |
| 出力先 | ファイル、標準出力、syslog、外部集約基盤 |
| フォーマット | テキストかJSON。timestamp、level、service、env、host、pid、request_id/trace_id、user_id、message、error情報 |
| タイムスタンプ | UTC統一推奨、ミリ秒精度、ISO 8601(例:`2026-09-29T01:23:45.678Z`) |
| ローテーション | 日次・サイズ単位、圧縮、世代数 |
| 保存期間・アーカイブ | 短期はホット(検索可能)、長期はS3等へ移動 |
| マスキング | パスワード、トークン、カード番号、個人情報を出さない・伏せる |
| サンプリング | 大量のアクセスログやDEBUGは一部だけ記録 |
| 相関ID | request_id / trace_id で複数サービスをまたいで追跡 |
| 権限・改ざん防止 | 閲覧権限の制限、監査ログは追記専用・別アカウント保管(S3 Object Lock等) |
| 時刻同期 | NTP(AWSならAmazon Time Sync Service)で全サーバーの時刻を揃える |
| 監視・アラート | ERROR件数の急増、特定キーワードで通知 |
| 可視化・検索 | ダッシュボード、よく使う検索クエリの保存 |

進め方:アプリ・アクセス・エラーログ+ローテーションから始め、要件に応じて監査ログやクラウド操作ログを足す。

## 4. ログ設計が重要な理由

ログは「問題が起きたあとに、何が起きたかを知る唯一の手段」であることが多く、**必要なログは後から取れない**。

- **障害対応のスピード**:request_idで一気通貫に追えるか、エラー時に入力値・状態が残っているかで、調査が数分か数日かが決まる。INFOが多すぎてエラーが埋もれるのも設計不足。
- **セキュリティとコンプライアンス**:誰がいつ何をしたかを証明できないと、被害範囲の特定も報告もできない。個人情報保護法、PCI DSS、ISMS等でログの取得・保管が求められることがある。逆にパスワードや個人情報の出力はログ自体が漏えい源になる。
- **コストと性能**:量に比例してストレージ・集約基盤の料金が増える。同期書き込みで応答が遅くなる。
- **分析・改善への活用**:構造化ログなら利用状況分析、ボトルネック特定、ビジネス指標集計に使える。

設計の出発点は**「誰が(開発者・運用者・監査担当)、どんな場面で、何を知りたいか」からの逆算**。レベル・出力項目・フォーマット・保存期間・マスキングのルールを決め、チーム内で統一する。

> **つまり:ログは「多ければ安心」ではなく、「後で使う人が、必要なときに、必要な情報へすぐたどり着けるか」で価値が決まる。**

## 5. 書きすぎの弊害と対策

| 弊害 | 内容 |
|---|---|
| 情報漏えい | リクエスト/レスポンスを丸ごと出すとパスワード、トークン、カード番号、個人情報が残る。ログはアプリ本体より閲覧権限が緩く、外部サービスにも送られる |
| コスト膨張 | クラウドのログ基盤は取り込み量・保存量課金が多い。本番DEBUG出しっぱなしで月額が桁違いになることも |
| 性能劣化 | ディスクI/Oと文字列生成コスト。ループ内・高頻度処理での大量出力。ディスク満杯でサーバーごと停止 |
| 調査が難しくなる | 重要なエラーがノイズに埋もれる、検索が遅い、アラート過多で誰も見なくなる |
| 法令上の問題 | 個人情報を必要以上に保存 |
| 保存期間の短縮 | 量が多すぎて保存期間を短くせざるを得ず、必要なときに古いログがない |

対策:
- ログレベルを正しく使い分ける
- 機密情報はマスキング、または**ホワイトリスト方式**(出してよい項目だけ出す)
- 高頻度ログはサンプリング(例:成功リクエストは10%、エラーは100%)
- 「このログは誰がいつ使うのか」に答えられないものは出さない
- 原則:**必要な情報を、必要な場所に、必要な量だけ**

## 6. 後から差し込む難しさ

| 後付けするもの | 難しさ | 理由 |
|---|---|---|
| 特定箇所へのログ追加 | 低 | 1行足してデプロイ。ただし「障害が起きてから足す」になりがちで、その障害の情報はもう取れない |
| request_id / trace_id の伝搬 | 高 | 関数呼び出し、非同期処理、外部API、キューのメッセージまで全経路に引き回す必要。漏れると追跡が途切れる |
| フォーマット統一(JSON化) | 高 | 全箇所の修正。既存の監視・アラートが旧形式に依存していると壊れる |
| マスキング | 高 | 既に機密情報を出している箇所の洗い出し、過去ログの扱い |
| ログレベルの見直し | 中 | 「とりあえずINFO」を一つずつ意味で振り分け直す |

**最初に作っておくべき土台**(これがあれば個々のログは後から足しても統一される):
1. ロガーを共通化してフォーマットを決める
2. request_id をミドルウェアで自動付与する
3. マスキングをロガー側でまとめて処理する

後付けせざるを得ない場合:フレームワークのミドルウェア、OpenTelemetryの自動計装(auto-instrumentation)で既存コードをあまり触らずにカバー。

## 7. ログを極めると何が変わるか

- **障害対応で頼られる**:どのログをどう絞り込めばいいかが分かる
- **システム全体が見える**:アクセスログ・アプリログ・スロークエリ・クラウド操作ログを突き合わせ、リクエストの流れを立体的に理解 → アーキテクチャ設計力へ
- **コードの書き方が変わる**:「本番でこのエラーが起きたら何を知りたいか」を考えて書く。レビューで「ここ、ログに何も残らない」と指摘できる
- **キャリアが広がる**:SRE、セキュリティ(SOC、フォレンジック)、オブザーバビリティ基盤、データエンジニアリング
- **最初の一歩**:過去の障害を一つ選び、**ログだけで原因を再現できるか**試す。足りなかった情報が改善ポイント

### 設計も変わる(オブザーバビリティ前提の設計)
- **処理の境界に観測点を置く**:外部API呼び出し、DBアクセス、キュー投入/取り出し、状態遷移で何を記録するかを最初に決める
- **trace_idの伝搬を設計要件にする**:HTTPヘッダー(W3C `traceparent`)やメッセージ属性に載せる。OpenTelemetryを前提にするかをここで判断
- **エラー設計が丁寧になる**:例外を握りつぶさない、エラーに種類とコード、ユーザー向けメッセージと内部向け詳細を分ける
- **業務イベントを明確に出力する**:「注文が作成された」「支払いが完了した」→ 監査・分析・デバッグが同時に楽に(発展形はイベントソーシング)
- **非機能要件の見積もりに入る**:ログ量からコスト試算、非同期出力で性能影響を抑える、個人情報を出さないデータの持ち方

## 8. 具体的な設定例

### 構造化ログの例(JSON)
```json
{
  "timestamp": "2026-09-29T01:23:45.678Z",
  "level": "ERROR",
  "service": "order-api",
  "env": "prod",
  "request_id": "7f3c9a1e-2b4d-4e8f-9a0b-1c2d3e4f5a6b",
  "trace_id": "4bf92f3577b34da6a3ce929d0e0e4736",
  "user_id": "u_12345",
  "event": "payment_failed",
  "message": "Payment gateway returned 502",
  "error": {"type": "PaymentGatewayError", "code": "PG-502", "retryable": true},
  "duration_ms": 3012
}
```

### Python(標準logging + JSON + マスキング + request_id)
```python
import json, logging, re, contextvars
from datetime import datetime, timezone

request_id_var = contextvars.ContextVar("request_id", default="-")
SENSITIVE_KEYS = {"password", "token", "authorization", "card_number", "secret"}
CARD_RE = re.compile(r"\b(?:\d[ -]?){13,16}\b")

def mask(obj):
    if isinstance(obj, dict):
        return {k: ("***" if k.lower() in SENSITIVE_KEYS else mask(v)) for k, v in obj.items()}
    if isinstance(obj, str):
        return CARD_RE.sub("****", obj)
    return obj

class JsonFormatter(logging.Formatter):
    def format(self, record):
        payload = {
            "timestamp": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "request_id": request_id_var.get(),
            "message": mask(record.getMessage()),
        }
        if hasattr(record, "fields"):
            payload.update(mask(record.fields))
        if record.exc_info:
            payload["exception"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)

handler = logging.StreamHandler()
handler.setFormatter(JsonFormatter())
logging.basicConfig(level=logging.INFO, handlers=[handler])
log = logging.getLogger("order-api")

# Webフレームワークのミドルウェアで:
#   request_id_var.set(request.headers.get("X-Request-ID") or str(uuid4()))
log.info("order created", extra={"fields": {"order_id": "o_1", "amount": 5000}})
```

### logrotate(/etc/logrotate.d/myapp)
```
/var/log/myapp/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    copytruncate
}
```

### Nginx アクセスログをJSONで
```nginx
log_format json_combined escape=json
  '{"time":"$time_iso8601","remote_addr":"$remote_addr","method":"$request_method",'
  '"uri":"$uri","status":$status,"bytes":$body_bytes_sent,'
  '"request_time":$request_time,"request_id":"$request_id","ua":"$http_user_agent"}';
access_log /var/log/nginx/access.log json_combined;
```
※クエリ文字列にトークン等が入り得るなら `$request_uri` ではなく `$uri` を使う。

### 保存期間の目安(要件・法令で最終決定すること)
| ログ | ホット(検索可) | アーカイブ |
|---|---|---|
| アプリ/エラーログ | 30〜90日 | 1年 |
| アクセスログ | 30日 | 1年 |
| 監査ログ・CloudTrail | 90日 | 1〜7年(Object Lockで改ざん防止) |
| DEBUG | 本番は出さない(一時有効化なら数日) | なし |
