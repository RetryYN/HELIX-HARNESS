# 06. AWS

## 目次
1. AWSに載せると楽になるか
2. AWSに載せると決めたら絶対に決めること(後から変えにくい順)
3. どこで・どこまで決めるか(フェーズと深さ)
4. 具体的な設定例

※AWSのサービス名・仕様・料金は変わるため、実装時は公式ドキュメントで最新情報を確認すること。

---

## 1. AWSに載せると楽になるか

**楽になる部分と、新たに考えることが増える部分の両方がある。**

### 楽になるところ
- **物理的な運用から解放**:サーバー調達、故障ディスクの交換、データセンターの電源・空調(非機能要求グレードの「機材設置環境」まわり)
- **マネージドサービス**ほど楽になる
  - RDS/Aurora:バックアップ、フェイルオーバー、マイナーバージョンのパッチ適用を自動化
  - ECS on Fargate / Lambda:OSやサーバー管理自体がなくなる
- 可用性・運用の仕組みを設定で用意できる:マルチAZ冗長化、オートスケーリング、CloudWatch(ログ・メトリクス)、CloudTrail(操作ログ)

### 残る・増えるところ
- **責任共有モデル**:AWSが守るのはインフラそのもの。その上の設定・データ・アプリは利用者の責任(IAM権限やS3公開設定のミスは自分たちの事故)
- **AWS自体の更新対応**:Lambdaランタイム、RDSエンジンバージョン、EKSのKubernetesバージョンにはサポート期限があり、過ぎると強制アップグレードや利用不可も(→ 05-dependencies.md のEOL管理対象になる)
- **コスト管理**:従量課金なので、ログ出しすぎ・リソース消し忘れがそのまま請求に。予算アラートはほぼ必須
- **選択肢が多すぎる**:同じことを複数の方法で実現でき、構成が複雑になりがち

### 楽さは「どこまで任せるか」で決まる
| 選択 | 自分たちの管理範囲 |
|---|---|
| EC2に自分でサーバー | OSパッチ、ミドルウェア、スケーリング → オンプレとあまり変わらない |
| ECS on Fargate | コンテナイメージとアプリ |
| Lambda | コードと設定 |
| RDS/Aurora | スキーマ、クエリ、パラメータ |
| DynamoDB | テーブル設計、キャパシティ設定 |

→ 管理しなくていいものは、できるだけマネージドに寄せる。

## 2. 絶対に決めること(後から変えにくい順)

### 最優先:後から変えるのがほぼ不可能
| 項目 | 決めること | よくある決め方 |
|---|---|---|
| アカウント構成 | 環境・システムの分け方 | AWS Organizationsで本番・ステージング・開発を別アカウントに分離。Control Towerで初期構成(ランディングゾーン)。ログアーカイブ用・セキュリティ監査用アカウントも分ける |
| リージョン | どこで動かす | 日本向けなら東京(ap-northeast-1)、DR用に大阪(ap-northeast-3)。データ所在地の要件を確認 |
| ネットワーク(VPC) | IP範囲、サブネット構成 | 他VPCやオンプレと重ならないCIDR。パブリック/プライベート(アプリ)/プライベート(DB)サブネットをマルチAZで |
| IaCツール | インフラのコード化 | Terraform、AWS CDK、CloudFormationのどれかに統一。手作業で作ったリソースを後からコード化するのは大変 |

### セキュリティ:初日から必須
| 項目 | 決めること | よくある決め方 |
|---|---|---|
| ルートユーザー | 最強権限の扱い | MFA設定、日常は一切使わない、アクセスキーを作らない |
| 人のアクセス | ログイン方法 | IAM Identity Centerで一元管理、MFA必須、IAMユーザーの長期アクセスキーは原則作らない |
| 権限設計 | 誰に何を許すか | 最小権限、ロール単位で付与、本番書き込み権限は限定。SCPでOrganizations全体のガードレール |
| 操作ログ | 誰が何をしたか | CloudTrailを組織全体で有効化、ログアーカイブアカウントのS3へ(改ざん防止) |
| 脅威検知 | 異常の自動検知 | GuardDuty、Security Hub、AWS Configを有効化 |
| 暗号化・秘密情報 | 鍵とパスワード | KMSで保存データ暗号化、パスワード・APIキーはSecrets Manager |
| 公開設定 | 誤公開防止 | S3ブロックパブリックアクセスをアカウント単位で有効化 |

### 運用:最初に型を作る
| 項目 | 決めること | よくある決め方 |
|---|---|---|
| 命名規則・タグ | 名前と分類 | `{system}-{env}-{purpose}`(例:`shop-prod-api`)、`Project`・`Environment`・`Owner`・`CostCenter`タグを必須化 |
| コンピュート | アプリの実行基盤 | 管理を減らすならECS on Fargate/Lambda、細かく制御するならEC2/EKS |
| データストア | DBの種類と構成 | RDS/Aurora か DynamoDB か、マルチAZにするか |
| ログ・監視 | 集約先と気づき方 | CloudWatch Logsに集約、保存期間設定(デフォルト無期限なので必ず設定)、主要メトリクスにアラーム、通知先 |
| バックアップ・DR | どこまで戻す | AWS Backupで一元管理、RPO・RTOを決め、必要なら別リージョン/別アカウントにコピー |
| CI/CD | デプロイ方法 | GitHub Actions(OIDCでAWSに接続、長期キー不要)やCodePipeline、本番は承認フロー |

### コスト:放置すると事故
| 項目 | 決めること | よくある決め方 |
|---|---|---|
| 予算アラート | いくらで気づくか | AWS Budgetsで月額予算、80%・100%(予測含む)で通知 |
| コスト可視化 | 何にいくら | コスト配分タグを有効化、Cost Explorerで定期確認、Cost Anomaly Detection |
| 支払い・契約 | 割引・サポート | 安定稼働分はSavings Plans(利用が安定してから)、本番があるならBusiness以上のサポートプラン |

### 体制:技術以外で決めること
- AWSアカウントの管理者
- セキュリティアラート(GuardDuty等)を見る人
- コストを見る人
- 障害時の連絡体制
→ 曖昧だと、通知が誰にも見られない。

**最優先の4つは後から変えると移行作業レベル。** コンピュートやDBの選択はIaCがしっかりしていれば比較的変えやすい。

## 3. どこで・どこまで決めるか

### 基本の考え方
- 戻れない「一方通行のドア」の判断は早めにじっくり
- 戻れる「両開きのドア」の判断は必要になるまで遅らせて素早く
- 全部を最初に決めると、情報不足のまま決めることになり手戻りが増える

### フェーズごとに決めること
| フェーズ | 決めること | 深さの目安 |
|---|---|---|
| 企画・構想 | AWSを使う理由、対象範囲、予算感、体制 | 方向性。「なぜAWSか」を言語化できればOK |
| 要件定義 | 非機能要件のレベル(稼働率、RPO/RTO、性能、セキュリティ、ログ保存期間)、リージョン、データ所在地、法令 | **数値で合意**。ここが曖昧だと後の設計が全部ぶれる |
| 基本設計(方式設計) | アカウント構成、VPC(CIDR)、IaCツール、認証・権限方針、コンピュートとDB方式、ログ・監視方針、バックアップ・DR方式、命名規則・タグ | **後から変えにくいものはここで確定**。構成図と方針書に |
| 詳細設計 | サブネットの具体アドレス、セキュリティグループのルール、IAMポリシーの中身、インスタンスサイズ、アラームしきい値、ログフォーマット | パラメータレベル。最初は仮の値でよい |
| 構築・試験 | 性能試験を踏まえたサイズ調整、しきい値調整、ランブック作成、障害・復旧訓練 | 実測値で決め直し、要件を満たすか検証 |
| 運用 | コスト最適化、Savings Plans購入、更新計画、監視ルールの見直し | 継続的に見直す |

### 早く決めすぎないほうがいいもの
- インスタンスサイズ、DBの性能クラス → 実負荷を見てから
- Savings Plans等の長期割引 → 利用量が安定してから
- アラームのしきい値 → 平常時の値を見てから(でないと誤報だらけ)
→ 「仮の値で始めて、あとで見直す」と決めておくこと自体が正しい決め方。

### 決めた理由を残す
「なぜFargateか」「なぜこのCIDRか」をADRに(→ assets/template-adr.md)。

## 4. 具体的な設定例

### VPC CIDR設計の例(/16をアカウント・環境ごとに割り当て)
| 環境 | VPC CIDR | パブリック(AZ-a/c/d) | プライベートApp | プライベートDB |
|---|---|---|---|---|
| prod | 10.10.0.0/16 | 10.10.0.0/24, 10.10.1.0/24, 10.10.2.0/24 | 10.10.16.0/20, 10.10.32.0/20, 10.10.48.0/20 | 10.10.64.0/24, 10.10.65.0/24, 10.10.66.0/24 |
| stg | 10.20.0.0/16 | 同様 | 同様 | 同様 |
| dev | 10.30.0.0/16 | 同様 | 同様 | 同様 |
| (将来/オンプレ用に予約) | 10.100.0.0/16〜 | | | |

### アカウント構成の例
```
Organization(管理アカウント:請求とOrganizations管理のみ)
├── Security OU
│   ├── log-archive   (CloudTrail/Configログの集約、Object Lock)
│   └── audit         (GuardDuty/Security Hubの委任管理者)
├── Workloads OU
│   ├── shop-prod
│   ├── shop-stg
│   └── shop-dev
└── Sandbox OU      (検証用、予算上限を厳しく)
```

### 必須タグの例
| タグキー | 例 | 用途 |
|---|---|---|
| Project | shop | コスト配分 |
| Environment | prod / stg / dev | 権限制御、コスト配分 |
| Owner | team-backend | 問い合わせ先 |
| CostCenter | CC-1234 | 経理 |
| ManagedBy | terraform | 手作業リソースの判別 |

### CloudWatch Logs 保存期間(Terraform例)
```hcl
resource "aws_cloudwatch_log_group" "app" {
  name              = "/ecs/shop-prod-api"
  retention_in_days = 90
  kms_key_id        = aws_kms_key.logs.arn
  tags = { Project = "shop", Environment = "prod", Owner = "team-backend" }
}
```

### 予算アラート(Terraform例)
```hcl
resource "aws_budgets_budget" "monthly" {
  name         = "shop-prod-monthly"
  budget_type  = "COST"
  limit_amount = "3000"
  limit_unit   = "USD"
  time_unit    = "MONTHLY"

  notification {
    comparison_operator        = "GREATER_THAN"
    threshold                  = 80
    threshold_type             = "PERCENTAGE"
    notification_type          = "ACTUAL"
    subscriber_email_addresses = ["infra-alerts@example.com"]
  }
  notification {
    comparison_operator        = "GREATER_THAN"
    threshold                  = 100
    threshold_type             = "PERCENTAGE"
    notification_type          = "FORECASTED"
    subscriber_email_addresses = ["infra-alerts@example.com"]
  }
}
```
