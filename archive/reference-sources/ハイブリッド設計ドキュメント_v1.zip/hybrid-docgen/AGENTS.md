# AGENTS.md — このリポジトリで作業するAIエージェントへ

このリポジトリは「Vモデル・ドキュメントジェネレータ」。YAML(docs/)を唯一の正本として、
Excel/図面/工程表を生成し、トレーサビリティを機械検証する。

## 絶対規則
1. 正本は `docs/*.yaml`。`build/` は生成物であり直接編集しない。
2. docs/ を変更したら必ず `python tools/build.py detect` を実行し、赤は自分で修正して緑にしてから報告する。
3. `tools/` は明示的な依頼がない限り変更しない。
4. 検出を黙らせる目的の修正（trace宣言の削除、catalogのna化）は禁止。
5. 実行記録は docs/assign.yaml が正本。実行していない作業を done/pass にしない（証跡必須）。
6. 文書を編集する前に、その文書末尾の `agent:` ブロック（defines=定義可能な接頭辞 / read_first=先に読む文書 / done_when=完了基準）を確認する。

## 規律の三重の網（ADR-0004）
- 編集時: Claude Code フックが docs 変更後に detect を自動実行(.claude/settings.json → tools/hook_gate.py)
- コミット時: `git config core.hooksPath scripts/hooks` で秘密情報/整合/全ゲートを検査
- push時: CI(spec-gate.yml)が両OSで全ゲート
判断を伴う手順(impactの上下左右・粒度・プロト合意)はhookで強制しない——vmodel-workflowスキルに従う。

## 全体地図
仕組み全体（正本→ゲート→割当→信号→敵対検証→3層防御）は `ハーネス導入ガイド.md` を参照。

## スクラム運営レイヤ（ハイブリッド）
本配布は 110〜122 にスクラム運営文書を持つ。日々の運営（バックログ/スプリント/レビュー/レトロ）は scrum-workflow スキルに従い、`build/agent/sprint.md` で現在地を掴む。統合トレースは G→EP→US(02)→要件→設計→テスト。

## 詳細手順（スキル）
- 作業の進め方・ゲート対応: `.claude/skills/vmodel-workflow/SKILL.md`
- 実体レビュー(敵対検証): `.claude/skills/vmodel-substance-review/SKILL.md`
- テスト・診断の思考法(視点/深さ配分/止めどき): `.claude/skills/vmodel-test-thinking/SKILL.md`
- 画面・ビジュアル検証(状態網羅/違和感の言語化): `.claude/skills/vmodel-visual-review/SKILL.md`
- スクラム運営(進め方/分割・見積/受入/レビュー/テーラリング): `.claude/skills/scrum-workflow/SKILL.md` ほか scrum-* 7スキル
- コード最小主義(書く前の7段の問い/ハードコードの嗅覚/依存の判断): `.claude/skills/vmodel-code-minimalism/SKILL.md`
- YAMLの書式・ID・トレース宣言: `.claude/skills/vmodel-authoring/SKILL.md`
- 文書の取捨選択・粒度・記録先の判断: `.claude/skills/vmodel-design-judgement/SKILL.md`

スキルが自動ロードされない環境（Codex/Cursor等）では、docs/ に触れる前に上記3ファイルを読むこと。

## 主要コマンド
```
python tools/build.py init "<名前>"      # 新規雛形
python tools/build.py profile <PoC|Standard|Enterprise>
python tools/build.py build              # xlsx/md 生成
python tools/build.py detect             # 全検出器（変更後は必須）
python tools/spec_trace.py --strict      # トレース閉包の厳格ゲート
python tools/build.py assign             # 実行割当台帳の生成/同期（実装フェーズの作業指示）
python tools/build.py signals            # 台帳→signals.json（証跡必須）→ schedule --live で還流
python tools/build.py agentdocs          # 実装持込用ダイジェスト(architecture/coding/test/design/marketing/sprint)
python tools/build.py impact --id <ID>|--doc NN  # 変更の見直し範囲(上/下/横/台帳)を機械列挙
python tools/build.py diff|notes --base <旧docs>  # 変更差分レポート/リリースノート
python tools/build.py diagrams|coverage|schedule
```
