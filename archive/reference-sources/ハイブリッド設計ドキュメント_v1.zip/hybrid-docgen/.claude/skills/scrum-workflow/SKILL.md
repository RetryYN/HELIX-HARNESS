---
name: scrum-workflow
description: スクラム・ドキュメントジェネレータ(scrum-docgen)での作業手順。このリポジトリで設計書・スクラム文書の新規作成・追記・修正、バックログ/ストーリー/受入基準の追加、スプリント運営記録、ビルド、納品物生成を頼まれたら必ずこのスキルに従う。docs/*.yaml、build/、tools/build.py、プロダクトバックログ、トレーサビリティ、カバレッジ、スプリント計画に言及されたときも使用する。既存コードから設計書を起こす(リバース)場合も対象。
---

# スクラム・ドキュメントジェネレータ 作業ワークフロー

Vモデル版と違い、スクラムの文書は「大量前倒しの重い成果物」ではなく、**スプリントごとに更新される生きた正本**である。書く量ではなく、意思決定と会話を支える最小の記録を、常に緑（機械ゲート通過）に保つことを目的とする。

## 大原則（これだけは崩さない）

1. **正本は `docs/*.yaml` のみ。** `build/` は生成物であり直接編集しない。Excel/mdを直したくなったら対応する `docs/*.yaml` を直して再生成する。
2. **変更したら必ずゲートを通す。** 編集のたびに最低限 `python tools/build.py detect` を実行し、赤が出たら**ユーザーに報告する前に自分で緑にする**。緑にできない場合のみ検出内容と試した修正を添えて報告する。
3. **`tools/` は触らない。** エンジン改修を明示的に依頼された場合を除き変更禁止（エンジンはVモデル版と共通）。
4. **前倒しで作り込まない。** まだ着手しないスプリントの受入基準やタスクを先に埋めない。バックログは「上位ほど詳細、下位は粗く」（漸進的詳細化）。na にはせず、粒度を粗いまま置く。

## スプリントのループに沿った進め方

スクラムの文書更新は工程の直線ではなく、**スプリントの反復**に対応する。各局面で触る文書は決まっている。

### A. プロダクト立ち上げ（最初の一度）
```
python tools/build.py init "<プロダクト名>"        # docs/ に18文書の雛形を生成
python tools/build.py profile <PoC|Standard|Enterprise>  # 規模で採用/粒度を自動セット
```
- profile 選択はユーザーに確認する。目安: 検証=PoC、1チーム=Standard(既定)、監査/大規模=Enterprise。提供形態(Web/Mobile/Desktop/CLI/APIService)も併用可。判断基準は **scrum-tailoring-judgement** に従う。
- 埋める順は Why→What: 01 ビジョン/インセプションデッキ → 02 プロダクトゴール → 03 プロダクトバックログ → 15 チーム憲章。ここまでが「スプリント0」で整えるべき土台。

### B. バックログ・リファインメント（最頻出・毎スプリント）
1. `docs/112_プロダクトバックログ.yaml` を開き、上位PBIを詳細化する。まず末尾の `agent:` ブロック（read_first/done_when）を確認。
2. Epic を Story(US) に割る。**新規Storyは 02_要求定義書 のUS一覧に追加し、要求(R-)へ紐付けて 43_要求・要件一覧(管理台帳) に登録する**(USのIDは02が正本。ここからVモデル網に接続される)。分割の判断は **scrum-story-splitting**（INVEST・垂直スライス）に従う。**型を埋めるだけの記入はしない**——中身の質は各思考スキルの領分。
3. 詳細化したStoryに受入基準(AC)を書く。ACの設計思想は **scrum-acceptance-thinking**（BDD・壊れ方の発見）に従い、`docs/29_受入基準・BDDシナリオ.yaml` に AC-xxx を定義。
4. 見積り(SP)は **scrum-story-splitting** の相対見積りで。ReadyかどうかはDoR（117）で判定。
5. ゲート:
```
python tools/build.py detect --profile Standard   # スコープ内の全検出器
python tools/spec_trace.py --strict              # トレース閉包を全種ハードゲート
```

### C. スプリントプランニング（各スプリント開始）
1. スプリントゴール(SG)を決め `docs/116_スプリント計画.yaml` に SP-n / SG-n を定義。Readyなバックログ上位から選択。
2. 選んだStory群を `docs/115_リリースプラン.yaml` のリリーススライスに接続（US → SP → R）。
3. スプリントバックログ（タスク分解）は07に書くが、**タスクIDはトレース対象にしない**（使い捨て。俯瞰図・16に持ち込まない。詳細は scrum-authoring）。
4. `python tools/build.py schedule` でスプリント/リリース計画の工程衛生（先行・日程・進捗）を確認。

### D. スプリント実行〜レビュー〜レトロ（各スプリント終盤）
- 日次: `docs/118_デイリースクラム・進行記録.yaml` に進捗・障害・差し込みを追記。障害は `docs/14_課題・リスク・意思決定管理.yaml` へ。
- 完了: DoD（117）を満たしたStoryのみ Done。インクリメント INC-n を `docs/119_スプリントレビュー記録.yaml` に記録し、Story群と接続（US → INC → REV）。
- レビュー: デモ結果・ステークホルダーFB・バックログ調整を11に。**「インクリメントは本当に出荷可能か／SGは本当に達成されたか」を疑う敵対検証は scrum-increment-review** の領分。
- レトロ: `docs/120_レトロスペクティブ記録.yaml` にKPTと改善アクション。実績は `docs/121_バーンダウン・ベロシティ実績.yaml` に還流。
```
python tools/build.py build       # xlsx/md 再生成
python tools/build.py coverage    # 状態+粒度+充足度
```

### E. 既存コードから起こす（リバース/brownfield）
1. A で init し profile を設定。
2. コードを読み、**Why→Whatの順に**埋める: 02 プロダクトゴール（G）→ 03 バックログ（Epic/Story を EP-/US- で）→ 09 受入基準（AC）。実装済み機能は「Done相当のStory」として起こす。
3. DB/API/セキュリティ等の設計内容が必要なら、方法論非依存なので**Vモデル版の該当テンプレを docs/ に追加**して同じトレース網に接続する（scrum-tailoring-judgement 参照）。
4. 1文書ごとにゲートを回す（まとめて書いて後で直すと赤の原因特定が難しい）。

### F. 納品物を作る
```
python tools/build.py build       # 全文書 xlsx（記入済み＋空テンプレ）+ md
python tools/build.py diagrams    # 図面PNG
python tools/build.py coverage    # カバレッジ
python tools/build.py schedule    # スプリント/リリース計画
```
- 出力サフィックス: 同梱サンプルは「_見本」、init した自案件は「_現況」、空スケルトンは「_テンプレート」。
- 納品一式は `build/` をそのまま渡せる。

## 変更時の見直し規約（どこまで辿るか）
感覚でなく `python tools/build.py impact --id <ID>`（文書単位は `--doc NN`）で見直し範囲を列挙する。スクラムのトレースは **Goal→Epic→Story→AC→Sprint→Increment→Release→運用**。
- **上(↑)** traces_from の根（Goal/Epic）まで: 変更が上位の意図と整合するか**読む**（直すのではなく読む。直したくなったら別のバックログ変更として起こす）。
- **下(↓)** 子孫と受入基準: 波及先を見直し、必要なら修正。ACが変わったらそのStoryは再度DoR/DoD判定。
- **横(⇔)** 対応するスプリント/インクリメント: Done済みStoryのACを変えたら、そのインクリメントは**再検証対象**。
手順: 上位を読む → 対象と下流を修正 → detect → 受入を再確認 → schedule。

## ゲートが赤になったときの直し方

| 検出 | 典型原因 | 修正 |
|---|---|---|
| validate: 未定義の参照 | 本文やtraceが存在しないIDを指す | 参照先ID（G/EP/US/AC/SP/INC）を定義元文書で定義するか、参照を正しいIDに直す |
| validate: 未参照定義 | 定義したIDがどこからも使われない | 下流から参照を張る。不要なら定義を削除 |
| schema: 未知キー/型違い | ブロックのキー名ミス、ncols不一致 | schema/doc.schema.json に適合させる（scrum-authoring 参照） |
| trace: 宙吊り/逆流 | traces_from が未定義ID/後工程を指す | 上位の正しいID（Story→Epic→Goal）へ付け替える |
| trace: 双方向不一致 | Storyの tests とACの traces_from が非対称 | 両側を揃える（US-xxx の acceptance に AC-xxx、AC-xxx の traces_from に US-xxx） |
| terms/consistency: 表記ゆれ/ADR不一致 | 用語ゆれ、ADR宣言と実態の乖離 | 用語を統一、ADRを実態に合わせる |
| coverage: done宣言↔記入率 | done宣言だがプレースホルダ残り | 中身を埋めるか status を戻す |
| agent: defines不一致 | ID定義を増減したのにメタデータ未同期 | `python tools/agent_meta.py apply` |
| schedule: 矛盾 | wbs.yaml の先行/日付/進捗の不整合 | wbs.yaml を修正 |

## やってはいけないこと
- build/ 配下を直接編集する。
- ゲートを通さずに「完了しました」と報告する。
- 一覧表（バックログ・受入一覧等）の**先頭列以外にIDを置く**（先頭列が定義IDとして抽出される）。
- 検出を黙らせる目的で catalog の status を na にする、trace 宣言を削除する。
- **タスクIDをトレースに持ち込む**（スプリント内で使い捨て。Storyより下は追跡しない）。
- まだ着手しないスプリントの受入・タスクを前倒しで作り込む（漸進的詳細化に反する）。
