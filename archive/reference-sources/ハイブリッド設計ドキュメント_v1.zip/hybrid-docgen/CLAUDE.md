# CLAUDE.md

規約と作業手順は **AGENTS.md** に一本化してある。まずそれに従うこと。

Claude Code 固有の補足:
- `.claude/skills/` のスキル群（vmodel-* 7つ / scrum-* 8つ）が自動トリガーする。
  docs/*.yaml に触れるタスクでは必ず該当スキルを使用する。スクラム運営文書(110〜122)は scrum-workflow に従う。
- ビルドは VSCode タスク（Ctrl/Cmd+Shift+B）でも実行可。
