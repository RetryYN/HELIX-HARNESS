# -*- coding: utf-8 -*-
"""hook_gate: Claude Code の PostToolUse フックから呼ばれる薄い門番。

docs/*.yaml への Edit/Write を検知したら detect を実行し、赤なら非ゼロ終了で
エージェントに即時フィードバックする（「変更後は必ず detect」を記憶でなく機構にする）。
判断を伴う手順(impact/上下左右の見直し)は強制しない——それは vmodel-workflow スキルの領分。
"""
import sys, os, json

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from util import run_tool


def main():
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return 0  # 入力が読めないときは黙って通す(フックが作業を壊さないこと最優先)
    path = str((payload.get("tool_input") or {}).get("file_path", ""))
    if (os.sep + "docs" + os.sep) not in path or not path.endswith((".yaml", ".yml")):
        return 0
    r = run_tool([sys.executable, os.path.join(HERE, "build.py"), "detect"])
    if r.returncode != 0:
        tail = "\n".join((r.stdout or "").splitlines()[-12:])
        print(f"[hook] docs変更後の detect が赤です。コミット/次作業の前に自分で修正してください:\n{tail}",
              file=sys.stderr)
        return 2  # Claude Code はstderrをエージェントに返す
    print("[hook] detect 緑（docs変更を検証済み）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
