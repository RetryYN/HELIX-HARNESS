# -*- coding: utf-8 -*-
"""package: 納品zipを正しく作る(UTF-8フラグ保証＋自己検査)。

  python tools/package.py <出力.zip>

Info-ZIP等の外部zipコマンドは日本語名にUTF-8フラグを付けないことがあり、
Windows標準解凍で全ファイル名が化ける(固定パス参照の検証系が全滅する)。
本ツールは Python zipfile で梱包し(非ASCII名は必ずUTF-8フラグが立つ)、
直後に verify_files の zip 検査を自動実行して欠落ゼロを保証する。
"""
import os, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, HERE)

EXCLUDE_DIRS = {".git", "__pycache__", ".pytest_cache"}


def main(out):
    base = os.path.basename(ROOT)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for dp, dns, fns in os.walk(ROOT):
            dns[:] = [d for d in dns if d not in EXCLUDE_DIRS]
            for fn in sorted(fns):
                p = os.path.join(dp, fn)
                arc = os.path.join(base, os.path.relpath(p, ROOT))
                zf.write(p, arc)
    from verify_files import check_zip
    bad = check_zip(out)
    n = len(zipfile.ZipFile(out).infolist())
    if bad:
        print(f"[package] ✗ UTF-8フラグ欠落 {len(bad)} 件 — 納品不可")
        for b in bad[:5]: print("   ", b)
        return 1
    print(f"[package] {out} ({n}エントリ) — 全エントリUTF-8フラグ確認済み ✓")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "/tmp/package.zip"))
