# -*- coding: utf-8 -*-
"""実体サンプリングレビュー(review): グッドハート対策の第2層。

  python tools/build.py review            # リスク加重で対象を抽出し、ブラインドレビュー用パケットを生成
  python tools/build.py review --n 8      # 抽出件数を指定(既定5)
  python tools/build.py review --status   # 敵対判定の集約(反駁されない攻撃が1つでもあればFLAG)

設計原則(敵対検証):
- 投票ではなく攻撃/防御。攻撃者(attacker)は意見でなく**具体的な反例**を構築する。防御者(defender)は
  攻撃ごとに提示情報の引用で反駁する。役割は別セッション・可能なら別プロバイダのモデルに割り当てる。
- パケットは自己完結(双方ともリポジトリ・会話履歴・作成経緯にアクセスしない=ブラインド)。
- 記録は docs/review.yaml の attacks に追記する。各攻撃 = {attacker, counterexample(反例の本体),
  claim(何が破れるか), rebuttal(防御の反駁; 無ければ空), rebutted_by}。集約規則:
    rebuttal が空の攻撃が1つでもある → FLAG(反駁されない攻撃が立っている)
    攻撃が1つ以上あり全て反駁済み → PASS(攻防の記録つき。約1割を人間抜き打ちに指名)
    攻撃者が no_attack を宣言(攻撃の試行ログ必須) → PASS-WEAK(人間抜き打ちの優先対象)
    それ以外 → OPEN
- 緑=壊れていない、PASS=攻撃に耐えた、であり品質の証明ではない(49_AI成果物検証設計 参照)。
"""
import os, sys, json, random, argparse
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
import sys as _sys; _sys.path.insert(0, HERE)
from util import load_tool
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
OUT = os.path.join(ROOT, "build", "review")
LEDGER = os.path.join(DOCS, "review.yaml")
ASSIGN = os.path.join(DOCS, "assign.yaml")


def _load_yaml(p):
    return yaml.safe_load(open(p, encoding="utf-8")) if os.path.exists(p) else None


def candidates():
    """レビュー候補IDとリスク要因を導出する。"""
    b = load_tool("build")
    docs, defmap, defall, refs, dep = b._extract_ids()
    asg = _load_yaml(ASSIGN) or {}
    fail_ids, thin_ev, dates = set(), set(), {}
    for sec in ("impl", "verify"):
        for r in asg.get(sec) or []:
            if r.get("status") in ("fail", "blocked"):
                fail_ids.add(r["id"]); fail_ids.update(r.get("traces") or [])
            ev = str(r.get("evidence", "")).strip()
            if r.get("status") in ("done", "pass") and len(ev) < 30:
                thin_ev.add(r["id"])
            if r.get("date"):
                dates[r["id"]] = r["date"]
    # ファンアウト: そのIDを参照する文書数
    fan = {i: sum(1 for rs in refs.values() if i in rs) for i in defmap}
    hi = sorted(fan.values())[int(len(fan) * 0.75)] if fan else 0
    out = []
    recent = sorted(dates.values())[-max(1, len(dates)//4):] if dates else []
    for i, doc in defmap.items():
        score, why = 1, []      # 全IDに基礎点1(純ランダム成分を残す)
        if i in fail_ids: score += 3; why.append("fail/blocked履歴")
        if i in thin_ev: score += 2; why.append("証跡が最小限")
        if fan.get(i, 0) >= hi and hi > 0: score += 2; why.append(f"高ファンアウト({fan[i]}文書)")
        if dates.get(i) in recent and recent: score += 1; why.append("直近更新")
        out.append({"id": i, "doc": doc, "score": score, "reasons": why or ["ランダム抽出"]})
    return out


def _context_of(i, doc):
    """対象IDの自己完結コンテキスト(要件文/宣言/台帳行)を集める。"""
    d = _load_yaml(os.path.join(DOCS, doc + ".yaml")) or {}
    lines = []
    for e in (d.get("spec", {}) or {}).get("defines", []) or []:
        if e.get("id") == i:
            lines.append("宣言: " + json.dumps(e, ensure_ascii=False))
    for ch in d.get("chapters", []):
        for b in ch.get("blocks", []):
            if b.get("t") == "table":
                for row in b.get("rows", []):
                    if any(i == str(c).strip() or i in str(c) for c in row[:1]):
                        lines.append("定義行: " + " | ".join(str(c) for c in row))
    asg = _load_yaml(ASSIGN) or {}
    for sec in ("impl", "verify"):
        for r in asg.get(sec) or []:
            if r.get("id") == i:
                lines.append(f"台帳({sec}): status={r.get('status')} date={r.get('date')} "
                             f"evidence={r.get('evidence','')}")
    return lines


PACKET = """# 敵対検証パケット {rv}

## 攻撃者(attacker)への指示
あなたの任務はこの成果物を**破る**ことです。妥当性の評価は求めていません。
**このパケット以外の情報(会話履歴・リポジトリ・作成経緯)にはアクセスできない前提**で、提示情報のみから攻撃してください。

## 対象
- ID: {id}（定義元: {doc}）
- 抽出理由: {reasons}

## 提示情報(これが全てです)
{context}

## 攻撃の成立条件（意見は攻撃ではない）
次のいずれかの**具体的な反例**を構築できたとき、攻撃は成立します:
1. 判定不能の実証: この記述に対し**合否が分かれる2つの読み方**を両方書く（両方とも本文と矛盾しないこと）。
2. 境界の突破: 宣言されたテスト集合が覆わない**具体的な入力・状態・順序**を1つ挙げ、なぜ既存テストで検出されないかを示す。
3. 証跡の崩し: evidence の記述から**再確認の手順を組み立てられない**ことを、欠けている情報を特定して示す。
4. トレースの空洞化: traces/tests の対応が**意味的に成立しない反例**（そのテストが緑でも要件が満たされないシナリオ）を1つ構成する。
「曖昧だと思う」「不十分に見える」は攻撃ではありません。反例そのものを書いてください。
攻撃が構築できない場合は no_attack を宣言し、**試行した攻撃とそれが成立しなかった理由**を最低3件記録してください（試行ログなしの no_attack は無効）。

## 防御者(defender)への指示（攻撃記録を受け取った別モデル）
各攻撃に対し、**提示情報の引用のみ**を根拠に反駁してください。反駁は「その反例は本文の『…』により排除される」の形式。引用で排除できない攻撃には反駁を書かないこと（書けないことが正しい判定です）。

## 記録形式（docs/review.yaml の attacks にこのまま追記）
```yaml
- attacker: <モデル名>
  date: 'YYYY-MM-DD'
  claim: <何が破れるか(1行)>
  counterexample: <反例の本体(具体的に)>
  rebuttal: ''            # 防御者が引用つきで記入。反駁できなければ空のまま
  rebutted_by: ''
```
no_attack の場合:
```yaml
- attacker: <モデル名>
  date: 'YYYY-MM-DD'
  no_attack: true
  attempts:
  - <試行した攻撃とその不成立理由> (最低3件)
```
"""

def cmd_review(n=5, seed=None):
    cand = candidates()
    rng = random.Random(seed)
    pool = [c for c in cand for _ in range(c["score"])]     # スコア加重
    picked, seen = [], set()
    while pool and len(picked) < n:
        c = rng.choice(pool)
        if c["id"] not in seen:
            seen.add(c["id"]); picked.append(c)
        pool = [x for x in pool if x["id"] not in seen]
    os.makedirs(OUT, exist_ok=True)
    led = _load_yaml(LEDGER) or {"note": "敵対検証台帳。attacks のみ手で追記する。"
                                          "集約規則: 反駁されない攻撃が1つでもあればFLAG / 全攻撃が反駁済みでPASS / "
                                          "no_attack(試行ログつき)はPASS-WEAK=人間抜き打ちの優先対象。",
                                  "samples": []}
    base = len(led["samples"])
    for k, c in enumerate(picked, 1):
        rv = f"RV-{base + k:03d}"
        ctx = _context_of(c["id"], c["doc"]) or ["(定義行が見つからない — それ自体が指摘対象)"]
        pk = os.path.join(OUT, f"{rv}_{c['id']}.md")
        open(pk, "w", encoding="utf-8").write(PACKET.format(
            rv=rv, id=c["id"], doc=c["doc"], reasons="、".join(c["reasons"]),
            context="\n".join("- " + l for l in ctx)))
        led["samples"].append({"rv": rv, "id": c["id"], "doc": c["doc"],
                               "reasons": c["reasons"], "packet": os.path.relpath(pk, ROOT),
                               "attacks": [], "human_check": ""})
        print(f"  {rv}: {c['id']} ({'、'.join(c['reasons'])}) → {os.path.relpath(pk, ROOT)}")
    yaml.safe_dump(led, open(LEDGER, "w", encoding="utf-8"),
                   allow_unicode=True, sort_keys=False, width=120)
    print(f"[review] {len(picked)} 件を抽出 → docs/review.yaml / パケット build/review/")
    print("  攻撃者・防御者は別セッション・可能なら別プロバイダの高性能モデル。パケットのみを渡すこと(ブラインド)。")
    return 0


def cmd_status():
    led = _load_yaml(LEDGER)
    if not led:
        print("[review] 台帳なし。まず `python tools/build.py review` を実行してください。"); return 0
    rng = random.Random(20260708)
    flag, ok, weak, open_ = [], [], [], []
    for s in led["samples"]:
        atks = [a for a in (s.get("attacks") or []) if not a.get("no_attack")]
        noat = [a for a in (s.get("attacks") or []) if a.get("no_attack")]
        standing = [a for a in atks if not str(a.get("rebuttal", "")).strip()]
        bad_noat = [a for a in noat if len(a.get("attempts") or []) < 3]
        if standing: flag.append((s, standing))
        elif atks: ok.append(s)
        elif noat and not bad_noat: weak.append(s)
        else: open_.append(s)
    print(f"[review] FLAG {len(flag)} / PASS(攻撃を反駁) {len(ok)} / PASS-WEAK(no_attack) {len(weak)} / OPEN {len(open_)}")
    for s, standing in flag:
        a = standing[0]
        print(f"   ✗ {s['rv']} {s['id']} 反駁されない攻撃[{a.get('attacker','?')}]: "
              f"{str(a.get('claim',''))[:56]} → 人間確認・是正へ")
    picks = [s for s in ok if not s.get("human_check")]
    k = max(1, len(picks) // 10) if picks else 0
    for s in (rng.sample(picks, k) if k else []):
        print(f"   ◎ 人間抜き打ち(PASS群の約1割): {s['rv']} {s['id']} — 攻防記録を原本と突合し human_check に記入")
    for s in weak:
        if not s.get("human_check"):
            print(f"   ◎ 人間抜き打ち(優先: no_attack): {s['rv']} {s['id']} — 試行ログの実質を確認")
    return 1 if flag else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=5)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--status", action="store_true")
    a = ap.parse_args()
    sys.exit(cmd_status() if a.status else cmd_review(a.n, a.seed))
