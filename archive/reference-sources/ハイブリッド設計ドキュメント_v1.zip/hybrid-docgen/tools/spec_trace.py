# -*- coding: utf-8 -*-
"""宣言トレースの閉包検証（自動検出の強化）。

spec.defines[].traces_from / traces_to / tests は現状どのゲートでも検証されない。
本チェッカは型宣言のトレースを機械検証し、ドリフト（宙吊り/逆流/テスト欠落/台帳不一致）を検出する。
既存エンジン(build.py)・型突合(spec_types.py)・メッシュ(spec_check.py)を変更せず追加動作する。

検出:
  T1 宙吊りトレース  traces_from/to・tests が、定義にも参照にも存在しないIDを指す
  T2 逆方向トレース  traces_from が“下流フェーズ”のIDを指す（V字の逆流）
  T3 テスト未宣言    要件系(F-/NF-)の宣言に tests: が無い（シフトレフト漏れ）
  T4 台帳不一致      宣言 traces_from と 台帳(43)要件一覧の「トレース元」列が食い違う
  T5 双方向不一致    要件.tests と テスト.traces_from が非対称（片方向しか宣言していない）

  python3 tools/spec_trace.py     exit 0=整合 / 1=不整合(T1/T2 が有る時)
"""
import os, sys, re, glob
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
import sys as _sys; _sys.path.insert(0, HERE)
from util import load_tool
import id_utils as IU
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
TESTRE = re.compile(r"^(?:UT|IT|ST|AT|US)-\d+[a-z]?$")
REQKIND = ("機能要件", "非機能要件")   # tests を持つべき種別




def load_declared():
    out = []   # (doc, id, kind, tf, tt, tests)
    files = sorted(glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml")))
    try:
        import scope as _scope; files = _scope.filter_files(files)
    except Exception:
        pass
    seen = set()
    for f in files:
        d = yaml.safe_load(open(f, encoding="utf-8")) or {}
        name = os.path.basename(f)[:-5]
        for e in IU.declared_items(d):
            iid = e.get("id")
            if iid:
                seen.add(iid)
            out.append((name, iid, e.get("kind", ""),
                        list(e.get("traces_from", []) or []),
                        list(e.get("traces_to", []) or []),
                        list(e.get("tests", []) or [])))
    # 定義表から検出されるIDも閉包検査の宇宙に揃える。
    _, defmap, _, _, _ = IU.extract_from_files(files)
    for iid, name in sorted(defmap.items()):
        if iid not in seen:
            out.append((name, iid, "table", [], [], []))
    return out


def load_ledger():
    """台帳(43)要件一覧の id -> (トレース元IDセット, 対応テスト文字列)。"""
    sc = load_tool("spec_check")
    _, ken = sc.load_ledger()
    src = {k: v.get("srcids", set()) for k, v in ken.items()}
    tst = {k: str(v.get("tst", "")).strip() for k, v in ken.items()}
    return src, tst


def main():
    import argparse
    ap = argparse.ArgumentParser(description="宣言トレースの閉包検証")
    ap.add_argument("--strict", action="store_true",
                    help="テスト欠落/台帳不一致/双方向不一致もexit 1にする(既定は宙吊り/逆流のみハード)")
    args = ap.parse_args()
    b = load_tool("build")
    docs, defmap, defall, refs, dep = b._extract_ids()
    universe = set(defmap) | set().union(*refs.values()) if refs else set(defmap)
    phase = b._PHASE
    declared = load_declared()
    ledger_src, ledger_tst = load_ledger()

    def ledger_has_test(i):
        s = ledger_tst.get(i, "")
        return bool(s) and s != "-"

    def doc_phase(name):
        return phase.get(name.split("_")[0]) if name else None

    issues = []
    tests_declared_for = 0
    try:
        import scope as _scope
        EXT = _scope.external_ids()
        EXTP = _scope.external_prefixes()
        verify_in_scope = any(_scope.file_in_scope(s) for s in
                              ("06_単体テスト設計書", "07_結合テスト設計書",
                               "08_総合テスト設計書", "09_受入テスト設計書"))
    except Exception:
        EXT = set(); EXTP = (); verify_in_scope = True
    for doc, i, kind, tf, tt, tests in declared:
        dph = doc_phase(doc)
        # T1 宙吊り（tests は test 形式なら参照集合で存在確認、その他IDは universe で確認）
        for k, arr in (("traces_from", tf), ("traces_to", tt), ("tests", tests)):
            for x in arr:
                if not x or x in EXT or (EXTP and str(x).startswith(EXTP)):
                    continue                    # 対象外書面/対象外検証種別のIDは外部扱い
                if TESTRE.match(x):
                    if x not in universe:
                        issues.append(("宙吊りトレース", f"{doc.split('_')[0]}:{i}",
                                       f"{k} の {x} がどの設計・テストにも出現しない"))
                elif x not in universe:
                    issues.append(("宙吊りトレース", f"{doc.split('_')[0]}:{i}",
                                   f"{k} の {x} が未定義・未参照"))
        # T2 逆方向（traces_from は上流＝フェーズ小 であるべき）
        if dph is not None:
            for x in tf:
                src_doc = defmap.get(x)
                sph = doc_phase(src_doc) if src_doc else None
                if sph is not None and sph > dph:
                    issues.append(("逆方向トレース", f"{doc.split('_')[0]}:{i}",
                                   f"traces_from {x}（{src_doc.split('_')[0]}/後工程）は下流→V字逆流"))
        # T3 テスト未宣言（要件系のみ・宣言スタイル採用docに限定）
        if kind in REQKIND:
            if tests:
                tests_declared_for += 1
            elif (tf or tt) and not ledger_has_test(i) and verify_in_scope:
                # 宣言にも台帳にも対応テストが無い＝真のテスト欠落（検証工程が対象内のときだけ指摘）
                issues.append(("テスト欠落", f"{doc.split('_')[0]}:{i}",
                               f"{kind} に対応テストが宣言にも台帳にも無い"))
        # T4 台帳不一致（台帳に同IDがあり、双方 traces_from を持つのに集合が食い違う）
        if i in ledger_src and tf:
            lset = {x for x in ledger_src[i] if x.startswith(("BR-", "RS-", "R-", "NR-", "F-", "NF-"))}
            dset = set(tf)
            if lset and dset and lset != dset:
                only_d = dset - lset; only_l = lset - dset
                detail = []
                if only_d: detail.append("宣言のみ:" + ",".join(sorted(only_d)))
                if only_l: detail.append("台帳のみ:" + ",".join(sorted(only_l)))
                issues.append(("台帳不一致", f"{doc.split('_')[0]}:{i}",
                               "traces_from が台帳と不一致（" + " / ".join(detail) + "）"))

    # T5 双方向不一致（要件.tests と テスト.traces_from の対称性）
    req_tests = {}; test_from = {}; test_ids = set()
    for doc, i, kind, tf, tt, tests in declared:
        if not i:
            continue
        if i.startswith(("F-", "NF-")) and tests:
            req_tests[i] = set(tests)
        if i.split("-")[0] in ("UT", "IT", "ST", "AT"):
            test_ids.add(i); test_from[i] = set(tf)
    for r, ts in req_tests.items():
        for t in ts:
            if t in test_ids and r not in test_from.get(t, set()):
                issues.append(("双方向不一致", f"{r}↔{t}",
                               f"要件 {r} は {t} を対応テストに挙げるが、{t} の traces_from に {r} が無い"))
    for t, rs in test_from.items():
        for r in rs:
            if r in req_tests and t not in req_tests.get(r, set()):
                issues.append(("双方向不一致", f"{t}↔{r}",
                               f"テスト {t} は {r} をtraces_fromに挙げるが、{r} の tests に {t} が無い"))

    ndecl = len(declared)
    print(f"[trace] 宣言 {ndecl} 件 / トレース付き要件 {tests_declared_for} 件 / ID宇宙 {len(universe)}")
    if not issues:
        print("  ✓ 宣言トレース閉包OK: 宙吊り/逆流/テスト欠落/台帳不一致 なし")
        return 0
    from collections import Counter
    c = Counter(x[0] for x in issues)
    print("  ✗ 不整合 " + " / ".join(f"{k}={v}" for k, v in c.items()))
    for kind, tgt, msg in issues:
        print(f"     - [{kind}] {tgt}: {msg}")
    if args.strict:
        return 1  # strict: 検出があれば種別を問わず失敗
    hard = {"宙吊りトレース", "逆方向トレース"}
    soft = [k for k, _, _ in issues if k not in hard]
    if soft and not any(k in hard for k, _, _ in issues):
        print("  ※ 上記はソフト検出(警告)のため exit 0。CI等で失敗させる場合は --strict を付与してください。")
    return 1 if any(k in hard for k, _, _ in issues) else 0


if __name__ == "__main__":
    sys.exit(main())
