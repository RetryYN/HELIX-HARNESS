# -*- coding: utf-8 -*-
"""JSON Schema でドキュメント構造を機械検証するゲート。

対象は番号付き設計doc（docs/・templates/ の [0-9][0-9]*_*.yaml）のみ。
catalog/traceability/wbs 等の支援YAMLは別構造のため対象外。
未知キー・型違い・block種別違い・spec.defines のトレース綴り違い等を検出する。

  python3 tools/schema_check.py            docs+templates を検証（exit 0=適合/1=不適合）
  python3 tools/schema_check.py --docs-only

jsonschema 未導入時は明示メッセージを出して 0 で抜ける（ローカルを壊さない）。
CI では requirements 経由で導入され実行される。
"""
import os, sys, glob, json, argparse
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import util  # 副作用: cp932コンソールでの記号出力ガード
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
TEMPLATES = os.path.join(ROOT, "templates")
SCHEMA = os.path.join(ROOT, "schema", "doc.schema.json")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--docs-only", action="store_true", help="templatesを対象にしない")
    a = ap.parse_args()
    try:
        import jsonschema
    except ImportError:
        print("[schema] jsonschema 未導入のためスキップ（pip install jsonschema で有効化）")
        return 0
    if not os.path.exists(SCHEMA):
        print("[schema] schema/doc.schema.json が見つかりません"); return 0
    sch = json.load(open(SCHEMA, encoding="utf-8"))
    V = jsonschema.Draft7Validator(sch)

    targets = sorted(glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml")))
    if not a.docs_only:
        targets += sorted(glob.glob(os.path.join(TEMPLATES, "[0-9][0-9]*_*.yaml")))
    try:
        import scope as _scope
        targets = _scope.filter_files(targets)
    except Exception:
        pass

    issues = []
    for f in targets:
        try:
            d = yaml.safe_load(open(f, encoding="utf-8"))
        except Exception as e:
            issues.append((os.path.basename(f)[:-5], "-", f"YAMLパース失敗: {str(e)[:60]}"))
            continue
        for e in sorted(V.iter_errors(d), key=lambda e: list(e.absolute_path)):
            path = "/".join(str(p) for p in e.absolute_path) or "(root)"
            issues.append((os.path.basename(f)[:-5], path, e.message[:80]))

    print(f"[schema] 検証 {len(targets)} 件 / スキーマ: schema/doc.schema.json")
    if not issues:
        print("  ✓ 全ドキュメントがスキーマ適合（未知キー/型違い/block種別/spec綴り なし）")
        return 0
    from collections import Counter
    c = Counter(i[0] for i in issues)
    print(f"  ✗ 不適合 {len(issues)} 件（{len(c)} 書面）")
    for name, path, msg in issues[:40]:
        print(f"     - {name.split('_')[0]} @{path}: {msg}")
    return 1


if __name__ == "__main__":
    sys.exit(main())
