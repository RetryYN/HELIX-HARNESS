# -*- coding: utf-8 -*-
"""build/ の xlsx を Google スプレッドシートへ掃き出す。
  python tools/build.py sheets --credentials service_account.json [--folder <DriveフォルダID>]
サービスアカウントのメールに対象スプレッドシート/フォルダを共有しておくこと。
"""
import os, glob
def push(build_dir, credentials, folder_id=None):
    try:
        import gspread
        from openpyxl import load_workbook
    except ImportError:
        raise SystemExit("pip install gspread gspread-formatting openpyxl を実行してください。")
    gc=gspread.service_account(filename=credentials)
    files=sorted(glob.glob(os.path.join(build_dir,"*.xlsx")))
    for path in files:
        name=os.path.splitext(os.path.basename(path))[0]
        wb=load_workbook(path)
        try:
            sh=gc.open(name)
        except gspread.SpreadsheetNotFound:
            sh=gc.create(name, folder_id=folder_id) if folder_id else gc.create(name)
        # 既存ワークシートを一旦クリア
        existing={w.title:w for w in sh.worksheets()}
        for ws in wb.worksheets:
            rows=[[("" if c.value is None else c.value) for c in r] for r in ws.iter_rows()]
            ncols=max((len(r) for r in rows),default=1); nrows=max(len(rows),1)
            if ws.title in existing:
                g=existing[ws.title]; g.clear()
            else:
                g=sh.add_worksheet(title=ws.title, rows=nrows+5, cols=ncols+2)
            if rows: g.update(rows, value_input_option="USER_ENTERED")
        # 余分な初期シート削除
        if "Sheet1" in {w.title for w in sh.worksheets()} and len(sh.worksheets())>1:
            try: sh.del_worksheet(sh.worksheet("Sheet1"))
            except Exception: pass
        print(f"  ✓ {name} → {sh.url}")
    print("[sheets] 掃き出し完了。書式(色/結合)はGAS版または再フォーマットで付与できます。")
