# -*- coding: utf-8 -*-
"""設計内スペックの型検査(自動検出の基盤)。
docに埋め込んだ型付き宣言 spec.defines を読み、
  (1) 宣言の重複/形式を検査
  (2) ヒューリスティック検出(build._extract_ids)と突合し、未宣言/宣言のみ/不一致を検出
型宣言があれば検出は“語の推測”でなく“宣言の読み取り”になり、内容とのズレも機械検出できる。
  python3 tools/spec_types.py      exit 0=整合 / 1=不整合
"""
import os, sys, glob, importlib.util
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import util  # 副作用: cp932コンソールでの記号出力ガード
import yaml
import id_utils as IU

HERE = os.path.dirname(os.path.abspath(__file__))
DOCS = os.path.join(HERE, "..", "docs")

def load_declared():
    declared = {}   # id -> (doc, kind)
    dup = []
    files = sorted(glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml")))
    try:
        import scope as _scope; files = _scope.filter_files(files)   # スコープ活性時のみ
    except Exception:
        pass
    for f in files:
        d = yaml.safe_load(open(f, encoding="utf-8"))
        name = os.path.basename(f)[:-5]
        for e in IU.declared_items(d or {}):
            i = e.get("id")
            if not i:
                continue
            if i in declared:
                dup.append((i, declared[i][0], name))
            declared[i] = (name, e.get("kind", ""))
    # spec/agent宣言が無いが、定義表の先頭列から正本として検出されるIDは
    # lightweightな table 宣言として扱う（例: ルール表BR-*、スクラムAC子ID）。
    _, defmap, _, _, _ = IU.extract_from_files(files)
    for i, name in sorted(defmap.items()):
        declared.setdefault(i, (name, "table"))
    return declared, dup

def heuristic_defmap():
    spec = importlib.util.spec_from_file_location("b", os.path.join(HERE, "build.py"))
    b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
    _, defmap, _, _, _ = b._extract_ids()
    return defmap

def main():
    declared, dup = load_declared()
    defmap = heuristic_defmap()
    issues = []
    for i, (doc, doc2) in [(k, (v[0], v[0])) for k, v in ()]:
        pass
    # 1) 宣言重複
    for i, a, c in dup:
        issues.append(("宣言重複", i, f"{a} と {c} で二重宣言"))
    # 2) 内容にあるが未宣言(ドリフト): heuristicが定義検出したのに宣言が無い
    for i, doc in sorted(defmap.items()):
        if i not in declared:
            issues.append(("未宣言", i, f"{doc.split('_')[0]} の内容に定義があるが型宣言が無い"))
    # 3) 宣言のみ(内容欠落): 宣言があるのにheuristicが内容から検出できない
    for i, (doc, kind) in sorted(declared.items()):
        if i not in defmap:
            issues.append(("宣言のみ", i, f"{doc.split('_')[0]} に宣言があるが内容(表)に定義が無い"))
    # 4) 定義元不一致: 宣言docとheuristic検出docが違う
    for i, (doc, kind) in sorted(declared.items()):
        if i in defmap and defmap[i] != doc:
            issues.append(("定義元不一致", i, f"宣言={doc.split('_')[0]} / 検出={defmap[i].split('_')[0]}"))

    print(f"[types] 型宣言 {len(declared)} 件 / ヒューリスティック検出 {len(defmap)} 件")
    if not issues:
        print("  \u2713 型宣言と内容が完全一致: 宣言の読み取りだけで自動検出できる(推測不要)")
        # 型化された自動検出カタログ(抜粋)
        from collections import Counter
        kc = Counter(k for _, k in declared.values())
        print("  種別:", " / ".join(f"{k}={v}" for k, v in sorted(kc.items())))
        return 0
    from collections import Counter
    c = Counter(x[0] for x in issues)
    print("  \u2717 不整合 " + " / ".join(f"{k}={v}" for k, v in c.items()))
    for kind, tgt, msg in issues:
        print(f"     - [{kind}] {tgt}: {msg}")
    return 1

if __name__ == "__main__":
    sys.exit(main())
