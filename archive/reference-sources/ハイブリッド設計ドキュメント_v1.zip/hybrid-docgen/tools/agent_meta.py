# -*- coding: utf-8 -*-
"""agent メタデータ（エージェント向け文書契約）の付与と突合。

  python tools/agent_meta.py apply     # docs/・templates/ の各文書に agent: を導出して付与/更新
  python tools/agent_meta.py --check   # agent.defines / read_first が実態と一致するか突合（CIゲート）

思想は spec_types.py と同じ「宣言はメタデータ、実態はツールが突合」:
- defines    … この文書で定義してよいID接頭辞。実際の定義(_extract_ids)から導出。
- read_first … 書く前に読むべき上流文書。参照IDの定義元から導出。
- done_when  … 完了基準。defines と台帳要否から生成。
手で編集した場合も --check が実態との乖離を赤にするため、メタデータは腐らない。
"""
import os, sys, re, glob
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
import sys as _sys; _sys.path.insert(0, HERE)
from util import load_tool
import id_utils as IU
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
TPL  = os.path.join(ROOT, "templates")
LEDGER_PREF = ("R-", "RS-", "NR-", "F-", "NF-")   # 43台帳への登録が必要な接頭辞
AGENT_RE = re.compile(r"\nagent:\n(?:[ \t]+[^\n]*\n?)*", re.M)


def derive():
    """docs/ の実態から 文書名→(defines接頭辞, read_first, ledger要否) を導出する。"""
    b = load_tool("build")
    docs, defmap, defall, refs, dep = b._extract_ids()
    out = {}
    for name in docs:
        path = os.path.join(DOCS, name + ".yaml")
        dd = yaml.safe_load(open(path, encoding="utf-8")) if os.path.exists(path) else {}
        has_spec = bool(((dd or {}).get("spec", {}) or {}).get("defines"))
        vals = sorted({i for i, d in defmap.items() if d == name})
        # スクラム文書は agent.defines が実ID契約、Vモデル文書は接頭辞契約。
        is_scrum = bool(getattr(b, "_is_scrum_mode", lambda: False)())
        prefixes = vals if (is_scrum and not has_spec) else sorted({IU.contract_token(i) for i in vals})
        upstream = sorted({defmap[r] for r in refs.get(name, ())
                           if r in defmap and defmap[r] != name})
        ledger = any(str(p).startswith(LEDGER_PREF) for p in prefixes)
        if ledger:
            led = "43_要求・要件一覧(管理台帳)"
            if led not in upstream and not name.startswith("43_"):
                upstream.append(led)
        out[name] = (prefixes, upstream, ledger)
    return out


def render(prefixes, read_first, ledger):
    L = ["agent:"]
    L.append("  defines: [" + ", ".join(prefixes) + "]")
    if read_first:
        L.append("  read_first:")
        for r in read_first:
            L.append(f"  - {r}")
    if prefixes:
        dw = "/".join(prefixes) + " 系IDを一覧の先頭列と spec.defines の双方に定義し、上流IDへの traces_from を宣言"
        if ledger:
            dw += "し、43台帳の一覧に同IDを登録"
        dw += "。python tools/build.py detect が緑であること。"
    else:
        dw = "採用章の表・段落を埋める（新IDは定義しない）。python tools/build.py detect が緑であること。"
    L.append(f"  done_when: {dw}")
    return "\n".join(L) + "\n"


def upsert(path, block):
    s = open(path, encoding="utf-8").read()
    if AGENT_RE.search(s):
        s = AGENT_RE.sub("\n" + block, s, count=1)
    else:
        s = s.rstrip() + "\n" + block
    open(path, "w", encoding="utf-8").write(s)


def cmd_apply():
    meta = derive()
    n = 0
    for name, (pfx, rf, led) in meta.items():
        upsert(os.path.join(DOCS, name + ".yaml"), render(pfx, rf, led)); n += 1
        # 同番号のテンプレにも契約を付与（read_first はテンプレ集合内に存在するものだけ）。
        # 不変則: テンプレは「これから書く」文書なので、契約は常に接頭辞（見本の実IDを持ち込まない。
        # 実IDを書くと init 直後の空プロジェクトに孤立定義が生える）。contract_token は冪等。
        tp = os.path.join(TPL, name + ".yaml")
        if os.path.exists(tp):
            trf = [r for r in rf if os.path.exists(os.path.join(TPL, r + ".yaml"))]
            tpfx = sorted({IU.contract_token(p) for p in pfx})
            upsert(tp, render(tpfx, trf, led)); n += 1
    print(f"[agent] {n} 文書に agent メタデータを付与/更新しました。")
    return 0


def cmd_check():
    meta = derive()
    issues = []
    for scope, base in (("docs", DOCS), ("templates", TPL)):
        for fp in sorted(glob.glob(os.path.join(base, "[0-9][0-9]*_*.yaml"))):
            name = os.path.basename(fp)[:-5]
            d = yaml.safe_load(open(fp, encoding="utf-8")) or {}
            ag = d.get("agent")
            if ag is None:
                issues.append((name, scope, "agent メタデータ未付与（tools/agent_meta.py apply を実行）"))
                continue
            decl = set(ag.get("defines") or [])
            actual = set(meta.get(name, ((), (), False))[0])
            if scope == "templates":
                # テンプレの契約は接頭辞（apply の不変則と対称）。実態も接頭辞に畳んで突合する。
                actual = {IU.contract_token(a) for a in actual}
            # defines は許可リスト: 未記入(宣言のみ)は正常、許可外の実定義(実態のみ)を赤にする
            extra = actual - decl
            if extra:
                issues.append((name, scope,
                               f"defines の許可外ID/接頭辞を定義している: {', '.join(sorted(extra))}"
                               f"（契約を広げるなら tools/agent_meta.py apply で同期）"))
            for r in ag.get("read_first") or []:
                if not os.path.exists(os.path.join(base, r + ".yaml")):
                    issues.append((name, scope, f"read_first の {r} が存在しない"))
    ndocs = len(glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml")))
    ntpl = len(glob.glob(os.path.join(TPL, "[0-9][0-9]*_*.yaml")))
    print(f"[agent] 突合 {ndocs + ntpl} 文書（docs {ndocs} / templates {ntpl}）")
    if not issues:
        print("  ✓ agent メタデータは実態と一致（defines接頭辞/read_first存在）")
        return 0
    print(f"  ✗ 不一致 {len(issues)} 件:")
    for name, scope, msg in issues:
        print(f"     - [{scope}] {name}: {msg}")
    return 1


if __name__ == "__main__":
    if "--check" in sys.argv or "check" in sys.argv:
        sys.exit(cmd_check())
    sys.exit(cmd_apply())
