# -*- coding: utf-8 -*-
"""スコープ解決: 「案件(アプリ)選択 = profile」×「書面選択 = catalog採用/実在」から
検出スコープを確定し、検出器を条件分岐させる共有基盤。

  - profile(profiles.yaml)で各カタログ項目の採用/対象外(na)を解決（cmd_profileと同じ規則）
  - 採用項目の file と実在ファイルの積 = 対象書面。対象外書面のIDは“外部”として許容
    （参照されても未定義扱いにせず、欠落も指摘しない）
  - 既定（スコープ非活性）では一切フィルタしない＝現行の全書面検出と同一挙動

活性化は環境変数 VMODEL_SCOPE=<scope.jsonのパス> で行う（detectコマンドが自動設定）。
各検出器はこのモジュールの active()/filter_files()/external_ids() を参照して分岐する。

  単体プレビュー:  python tools/scope.py --profile PoC
  検出の一括実行:  python tools/build.py detect --profile PoC
"""
import os, sys, json, glob, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
import sys as _sys; _sys.path.insert(0, HERE)
from util import load_tool
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
OUT = os.path.join(ROOT, "build")
ENV = "VMODEL_SCOPE"


# ── 検出器から呼ぶ共有API（スコープ非活性なら“素通し”） ──────────────
def active():
    p = os.environ.get(ENV)
    if not p or not os.path.exists(p):
        return None
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return None


def _stem(path):
    return os.path.basename(path)[:-5] if path.endswith(".yaml") else os.path.basename(path)


def filter_files(files):
    """対象書面だけに絞り込む（非活性なら files をそのまま返す）。"""
    sc = active()
    if not sc:
        return files
    keep = set(sc.get("in_files", []))
    return [f for f in files if _stem(f) in keep]


def external_ids():
    """対象外書面で定義されるID集合（参照許容・欠落非指摘に使う）。"""
    sc = active()
    return set(sc.get("out_ids", [])) if sc else set()


def external_prefixes():
    """対象外の検証工程のテスト種別プレフィックス（例: 'UT-'）。"""
    sc = active()
    return tuple(sc.get("out_prefixes", [])) if sc else ()


def is_external(idv):
    sc = active()
    if not sc:
        return False
    return idv in set(sc.get("out_ids", [])) or str(idv).startswith(tuple(sc.get("out_prefixes", [])))


def file_in_scope(stem):
    sc = active()
    return True if not sc else (stem in set(sc.get("in_files", [])))


# ── 解決ロジック ──────────────────────────────────────────────


def _load(name):
    import yaml
    return yaml.safe_load(open(os.path.join(DOCS, name), encoding="utf-8"))


def resolve(profile=None, only=None, exclude=None, caps=None):
    """profile＋能力フラグ(caps)＋手動選択(only/exclude)から対象書面・対象外IDを確定。
    caps: 無効化するカタログ・カテゴリ id の集合（例: {'mobile','agent'}）。
    """
    cat = _load("catalog.yaml")
    items = [dict(it) for it in cat.get("items", [])]
    valid_cats = {c["id"] for c in cat.get("categories", [])}

    # 1) profile で採用/na を解決（cmd_profile と同じ規則）
    prof_used = None
    if profile:
        profs = _load("profiles.yaml").get("profiles", {})
        if profile not in profs:
            raise SystemExit(f"[scope] 未知のprofile: {profile} / 利用可能: {', '.join(profs)}")
        prof_used = profile
        pf = profs[profile]; adopt = pf.get("adopt", {}); dstat = pf.get("default_status", "keep")
        for e in items:
            iid = e["id"]
            if iid in adopt:
                if e["status"] == "na":
                    e["status"] = "todo"
            elif dstat == "na":
                e["status"] = "na"
            elif dstat == "done":
                e["status"] = "done" if e["status"] != "na" else "na"

    # 1.5) 能力フラグ: 指定カテゴリを丸ごと対象外(na)にする
    caps = set(caps or [])
    unknown = caps - valid_cats
    if unknown:
        raise SystemExit(f"[scope] 未知の能力(カテゴリ): {', '.join(sorted(unknown))} / "
                         f"利用可能: {', '.join(sorted(valid_cats))}")
    if caps:
        for e in items:
            if e.get("category") in caps:
                e["status"] = "na"

    # 2) file 単位に集約：ある書面は、その書面に紐づく採用項目が1つでもあれば対象
    present = {_stem(f) for f in glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml"))}
    adopted_files, na_files = set(), set()
    for e in items:
        fl = e.get("file")
        if not fl or fl not in present:
            continue
        (adopted_files if e["status"] != "na" else na_files).add(fl)
    # 既定(profile無し・選択無し)は全実在書面を対象にする（現行挙動を維持）
    base = adopted_files if (profile or only or exclude or caps) else set(present)
    in_files = set(base) - (na_files - adopted_files)

    # 3) 手動の書面選択（stem か catalog-id で指定可）
    id2file = {e["id"]: e.get("file") for e in items}
    def norm(tok):
        tok = tok.strip()
        return id2file.get(tok, tok)
    if only:
        sel = {norm(t) for t in only}
        in_files = {f for f in present if f in sel}
    if exclude:
        exc = {norm(t) for t in exclude}
        in_files -= exc

    in_files &= present
    out_files = present - in_files

    # 4) 対象外書面で“定義”されるIDを外部集合として抽出
    b = load_tool("build")
    docs, defmap, defall, refs, dep = b._extract_ids()
    out_ids = sorted(i for i, fstem in defmap.items() if fstem in out_files)

    # 5) 対象外の検証工程は、そのテスト種別(UT/IT/ST/AT)を丸ごと外部扱いにする
    VPREFIX = {"06_単体テスト設計書": "UT-", "07_結合テスト設計書": "IT-",
               "08_総合テスト設計書": "ST-", "09_受入テスト設計書": "AT-"}
    out_prefixes = sorted({p for f, p in VPREFIX.items() if f in out_files})

    return {
        "profile": prof_used,
        "caps": sorted(caps),
        "in_files": sorted(in_files),
        "out_files": sorted(out_files),
        "out_ids": out_ids,
        "out_prefixes": out_prefixes,
    }


def write_active(scope):
    os.makedirs(OUT, exist_ok=True)
    p = os.path.join(OUT, "scope.active.json")
    json.dump(scope, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    return p


def describe(scope):
    tag = scope["profile"] or "(なし=全書面)"
    if scope.get("caps"):
        tag += " / 無効能力=" + ",".join(scope["caps"])
    print(f"[scope] profile={tag}")
    print(f"  対象書面 {len(scope['in_files'])} / 対象外 {len(scope['out_files'])}")
    if scope["out_files"]:
        print("  対象外書面: " + ", ".join(s.split('_')[0] for s in scope["out_files"]))
    if scope["out_ids"]:
        shown = scope["out_ids"][:12]
        more = "" if len(scope["out_ids"]) <= 12 else f" …他{len(scope['out_ids'])-12}"
        print(f"  外部扱いID {len(scope['out_ids'])}: " + ", ".join(shown) + more)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile")
    ap.add_argument("--only", help="対象書面をカンマ区切りで限定(stem か catalog-id)")
    ap.add_argument("--exclude", help="対象外にする書面(stem か catalog-id)")
    ap.add_argument("--caps", help="無効化する能力(カタログ・カテゴリ)をカンマ区切り。例: mobile,agent,saas")
    a = ap.parse_args()
    scope = resolve(a.profile,
                    a.only.split(",") if a.only else None,
                    a.exclude.split(",") if a.exclude else None,
                    a.caps.split(",") if a.caps else None)
    describe(scope)
    p = write_active(scope)
    print(f"  → {os.path.relpath(p, ROOT)} に保存（検出で使う場合は build.py detect を利用）")


if __name__ == "__main__":
    main()
