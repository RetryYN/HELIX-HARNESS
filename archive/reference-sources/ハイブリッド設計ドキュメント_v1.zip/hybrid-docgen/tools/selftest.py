# -*- coding: utf-8 -*-
"""エンジン自己診断（ツール自身の単体テスト）。

  python tools/selftest.py

文書ではなく tools/*.py の純関数・正規表現・レンダラを検査する。
外部状態(docs/の中身)に依存しないため、Vモデル/スクラム/ハイブリッドの
どの配布でも同一に走る。CI(spec-gate)の先頭ゲート。
"""
import os, sys, re, tempfile, unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import id_utils as IU
import agent_meta as AM


class TestContractToken(unittest.TestCase):
    def test_hyphen_prefix(self):
        self.assertEqual(IU.contract_token("F-001"), "F-")
        self.assertEqual(IU.contract_token("AC-12-1"), "AC-")

    def test_versionish(self):
        self.assertEqual(IU.contract_token("G1"), "G")
        self.assertEqual(IU.contract_token("R0.9"), "R")

    def test_idempotent(self):
        # apply がテンプレへ書く不変則の前提: 接頭辞に再適用しても不変
        for tok in ("F-", "EP-", "G", "R"):
            self.assertEqual(IU.contract_token(tok), tok)


class TestScrumRank(unittest.TestCase):
    def test_hierarchy_order(self):
        ranks = [IU.scrum_rank(x) for x in ("G1", "EP-01", "US-03", "AC-03-1")]
        self.assertEqual(ranks, sorted(ranks))
        self.assertTrue(all(r is not None for r in ranks))

    def test_non_scrum_is_none(self):
        for x in ("F-001", "NSG-01", "42", "ADR-0001"):
            self.assertIsNone(IU.scrum_rank(x))


class TestFindIds(unittest.TestCase):
    def test_compressed_expansion(self):
        self.assertEqual(IU.find_ids("US-01/02/10"), {"US-01", "US-02", "US-10"})

    def test_zero_padding_kept(self):
        self.assertIn("US-02", IU.find_ids("US-01/2"))

    def test_no_partial_word(self):
        # 「US-09改善」のような後続文字つきでも US-09 を(参照として)拾える一方、
        # 非ID表記 US-xx は拾わないこと。
        self.assertIn("US-09", IU.find_ids("US-09改善"))
        self.assertEqual(IU.find_ids("US-xx / SP-x / Gx"), set())


class TestDefTableTitle(unittest.TestCase):
    def test_partial_match(self):
        self.assertTrue(IU.is_def_table_title("3. 機能一覧(コア)"))
        self.assertFalse(IU.is_def_table_title("バックログ一覧(PBI)") and
                         "プロダクトバックログ" not in IU.DEF_TABLE_TITLES and False)
        # 「バックログ一覧(PBI)」は SCRUM タイトル群のどれも部分一致しない設計
        # (US の二重定義回避)。scrum配布でのみ意味を持つため存在時だけ検査。
        if "プロダクトバックログ" in IU.DEF_TABLE_TITLES:
            self.assertFalse(IU.is_def_table_title("バックログ一覧(PBI)"))


class TestRowCompanions(unittest.TestCase):
    def _fixture(self, doc_yaml):
        import yaml
        fd, p = tempfile.mkstemp(suffix="_99_試験.yaml", dir=None, text=True)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(doc_yaml)
        return p

    def test_head_and_companions(self):
        p = self._fixture(
            "file: 99_試験\n"
            "chapters:\n"
            "- title: 機能一覧\n"
            "  blocks:\n"
            "  - t: table\n"
            "    rows:\n"
            "    - [F-001, 説明, 'US-01/02']\n"
        )
        try:
            comp = IU.def_row_companions([p])
            self.assertEqual(comp.get("F-001"), {"US-01", "US-02"})
        finally:
            os.unlink(p)

    def test_spec_docs_skipped(self):
        p = self._fixture(
            "file: 99_試験\n"
            "spec:\n"
            "  defines:\n"
            "  - id: F-001\n"
            "chapters:\n"
            "- title: 機能一覧\n"
            "  blocks:\n"
            "  - t: table\n"
            "    rows:\n"
            "    - [F-001, 説明, US-01]\n"
        )
        try:
            self.assertEqual(IU.def_row_companions([p]), {})
        finally:
            os.unlink(p)

    def test_note_columns_excluded(self):
        # 備考列に書かれた親IDでは閉包が偽充足しない(宣言列のみが同伴)
        p = self._fixture(
            "file: 99_試験\n"
            "chapters:\n"
            "- title: 機能一覧\n"
            "  blocks:\n"
            "  - t: table\n"
            "    cols:\n"
            "    - [A, ID, 8]\n"
            "    - [B, 対応, 8]\n"
            "    - [C, 備考, 20]\n"
            "    rows:\n"
            "    - [F-001, US-01, 'US-99は備考なので同伴しない']\n"
        )
        try:
            comp = IU.def_row_companions([p])
            self.assertEqual(comp.get("F-001"), {"US-01"})
        finally:
            os.unlink(p)

    def test_no_cols_defined_keeps_legacy(self):
        # cols定義が無い表は従来どおり全セルから拾う(後方互換)
        p = self._fixture(
            "file: 99_試験\n"
            "chapters:\n"
            "- title: 機能一覧\n"
            "  blocks:\n"
            "  - t: table\n"
            "    rows:\n"
            "    - [F-001, US-01]\n"
        )
        try:
            self.assertEqual(IU.def_row_companions([p]).get("F-001"), {"US-01"})
        finally:
            os.unlink(p)

    def test_broken_yaml_is_silent_here(self):
        # 壊れたYAMLは本関数では黙ってスキップされる(多層防御:
        # schema_check / validate / check / verify_files が exit=1 で止める)。
        p = self._fixture("chapters: [broken\n")
        try:
            self.assertEqual(IU.def_row_companions([p]), {})
        finally:
            os.unlink(p)


class TestAgentUpsert(unittest.TestCase):
    def test_replace_and_append(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "x.yaml")
            open(p, "w", encoding="utf-8").write("file: x\ntitle: t\n")
            AM.upsert(p, "agent:\n  defines: [F-]\n")
            s1 = open(p, encoding="utf-8").read()
            self.assertEqual(s1.count("\nagent:"), 1)
            AM.upsert(p, "agent:\n  defines: [F-, NF-]\n")
            s2 = open(p, encoding="utf-8").read()
            self.assertEqual(s2.count("\nagent:"), 1)      # 置換であり重複追加しない
            self.assertIn("NF-", s2)

    def test_nested_agent_key_not_hit(self):
        # 章内の(インデントされた) agent: キーを誤って書き換えないこと
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "x.yaml")
            body = "file: x\nchapters:\n- title: t\n  agent:\n    memo: 章内の別物\n"
            open(p, "w", encoding="utf-8").write(body)
            AM.upsert(p, "agent:\n  defines: [F-]\n")
            s = open(p, encoding="utf-8").read()
            self.assertIn("memo: 章内の別物", s)


class TestBurnupRenderer(unittest.TestCase):
    def test_smoke_and_edge(self):
        import matplotlib
        matplotlib.use("Agg")
        import diagram_dsl as DD
        if "burnup" not in DD.RENDERERS:
            self.skipTest("burnup未搭載の配布")
        with tempfile.TemporaryDirectory() as d:
            for pts in ([{"label": "SP-1後", "done": 12, "scope": 72}],          # 1点(零除算なし)
                        [{"label": "t0", "done": 0, "scope": 0}]):               # 全ゼロ(vmax防御)
                p = os.path.join(d, "b.png")
                DD.render_one({"name": "試験", "type": "burnup", "points": pts}, p)
                self.assertGreater(os.path.getsize(p), 1000)


if __name__ == "__main__":
    r = unittest.main(verbosity=1, exit=False).result
    sys.exit(0 if r.wasSuccessful() else 1)
