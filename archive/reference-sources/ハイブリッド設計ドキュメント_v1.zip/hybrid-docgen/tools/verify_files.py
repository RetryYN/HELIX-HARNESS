# -*- coding: utf-8 -*-
"""ファイル検証: 文字化け・破損の早期検出。
  - テキスト(yaml/json/md/py/txt/csv)がUTF-8で読めるか、置換文字(U+FFFD)が無いか
  - YAMLがパースできるか
  - build/図面のPNGが空でないか
  - (任意)引数にzipパスを渡すと、日本語ファイル名にUTF-8フラグ(bit11)が立っているか検査
使い方: python3 tools/verify_files.py [package.zip]
終了コード: 0=健全 / 1=問題あり
"""
import os, sys, re
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import util  # 副作用: cp932コンソールでの記号出力ガード

# 秘密情報の検出パターン(納品事故防止。docs/templates のテキストを走査)
SECRET_PATTERNS = [
    ("AWSアクセスキー", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("GitHubトークン", re.compile(r"gh[pousr]_[A-Za-z0-9]{36,}")),
    ("秘密鍵ブロック", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |PGP )?PRIVATE KEY-----")),
    ("OpenAI/類似APIキー", re.compile(r"\bsk-[A-Za-z0-9]{20,}")),
    ("Slackトークン", re.compile(r"xox[baprs]-[A-Za-z0-9-]{10,}")),
    ("Bearerトークン", re.compile(r"Bearer [A-Za-z0-9._\-]{25,}")),
    ("パスワード直書き", re.compile(r"(?i)(?:password|passwd|secret)\s*[:=]\s*['\"][^'\"\s]{8,}['\"]")),
]
import glob, zipfile
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
TEXT_EXT = (".yaml", ".yml", ".json", ".md", ".py", ".txt", ".csv")

def check_tree():
    bad_utf8, repl, bad_yaml = [], [], []
    for root, _, files in os.walk(ROOT):
        for fn in files:
            if not fn.endswith(TEXT_EXT):
                continue
            p = os.path.join(root, fn)
            try:
                s = open(p, "rb").read().decode("utf-8")
            except UnicodeDecodeError:
                bad_utf8.append(p); continue
            if "\ufffd" in s:
                repl.append(p)
            if fn.endswith((".yaml", ".yml")):
                try:
                    yaml.safe_load(open(p, encoding="utf-8"))
                except Exception:
                    bad_yaml.append(p)
    pngs = glob.glob(os.path.join(ROOT, "build", "図面", "*.png"))
    empty = [p for p in pngs if os.path.getsize(p) < 2000]
    secrets = []
    for base in ("docs", "templates", "api"):
        for dp, _, fs in os.walk(os.path.join(ROOT, base)):
            for fn in fs:
                if not fn.endswith((".yaml", ".yml", ".md", ".json", ".feature")):
                    continue
                p = os.path.join(dp, fn)
                try:
                    txt = open(p, "rb").read().decode("utf-8", errors="ignore")
                except Exception:
                    continue
                for label, pat in SECRET_PATTERNS:
                    m = pat.search(txt)
                    if m:
                        secrets.append((p, label, m.group(0)[:12] + "…"))
    return bad_utf8, repl, bad_yaml, pngs, empty, secrets

def check_zip(path):
    zf = zipfile.ZipFile(path)
    non = [i.filename for i in zf.infolist()
           if not (i.flag_bits & 0x800) and any(ord(c) > 127 for c in i.filename)]
    return non

def main():
    bad_utf8, repl, bad_yaml, pngs, empty, secrets = check_tree()
    ok = True
    print(f"[verify] テキストUTF-8不正={len(bad_utf8)} 置換文字={len(repl)} YAML壊れ={len(bad_yaml)}"
          f" 秘密情報={len(secrets)} / PNG {len(pngs)}枚(極小{len(empty)})")
    for p, label, head in secrets:
        ok = False; print(f"   ✗ [秘密情報:{label}] {os.path.relpath(p, ROOT)}: {head}"
                          "（実在の資格情報は削除し、例示はダミー形式に置換すること）")
    for label, items in [("UTF-8不正", bad_utf8), ("置換文字", repl), ("YAML壊れ", bad_yaml), ("極小PNG", empty)]:
        for p in items:
            ok = False; print(f"   \u2717 [{label}] {os.path.relpath(p, ROOT)}")
    if len(sys.argv) > 1 and os.path.exists(sys.argv[1]):
        non = check_zip(sys.argv[1])
        print(f"[verify] ZIP日本語名でUTF-8フラグ無し={len(non)}")
        for f in non[:10]:
            ok = False; print(f"   \u2717 [ZIP名] {f}")
    print("  \u2713 健全" if ok else "  \u2717 問題あり")
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
