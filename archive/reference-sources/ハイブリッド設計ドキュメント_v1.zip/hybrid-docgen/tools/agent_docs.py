# -*- coding: utf-8 -*-
"""agentdocs: コーディングエージェント向けの目的別ダイジェスト(md)を docs/*.yaml から生成する。

  python tools/build.py agentdocs   # build/agent/ に design.md / architecture.md / coding.md / test.md

設計原則:
- これらの .md は **読み取り専用の生成ビュー** であり、正本ではない。正本は常に docs/*.yaml。
  手で編集しても次の生成で消える(冒頭に編集禁止ヘッダを付す)。第二の正本を作らないための構造的な措置。
- 目的は文脈の圧縮: 実装リポジトリで作業するエージェントが、109文書を読まずに
  「アーキテクチャ / 規約 / テスト戦略 / 設計対応」を1ファイルずつで把握できること。
- 採用状況(catalog)を尊重: status=na の文書はダイジェストから除外する。
"""
import os, sys, glob, datetime
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
import sys as _sys; _sys.path.insert(0, HERE)
from util import load_tool, nfc
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
OUT = os.path.join(ROOT, "build", "agent")

# ダイジェスト定義: 出力名 → (目的の一文, 収録する文書番号の優先順)
DIGESTS = {
    "architecture.md": ("システムの構造: 方式・構成・ドメイン境界・配置。実装前に全体像を掴むために読む。",
                        ["18", "04", "27", "45", "25", "26", "72", "76", "82", "88"]),
    "coding.md":       ("コードの書き方の規約: 命名・実装方針・設計原則・用語。コードを書く/レビューする前に読む。",
                        ["15", "95", "96", "94", "30"]),
    "test.md":         ("テスト戦略: 計画・検証方式・技法・カバレッジ基準・各レベルのテスト設計。テストを書く前に読む。",
                        ["12", "28", "06", "07", "08", "09", "109", "102"]),
    "design.md":       ("機能の設計対応: 要件→基本→詳細のダイジェスト。個別機能を実装する前に該当IDの行を読む。",
                        ["03", "04", "05", "17", "24", "108"]),
    "sprint.md":       ("スクラム運営の現在地: ゴール・バックログ・今スプリントの計画/記録・実績。日々の作業前に読む。",
                        ["111", "112", "116", "117", "119", "121", "122"]),
    "marketing.md":    ("対外文書の声と語彙: ターゲット・価値提案・正式な表示名・用語・トーン。"
                        "公開ページ/ユーザードキュメント/サポート文言/告知を書く前に読む。"
                        "用語の難易度は48の読者定義に、表記は41の表示名カタログに従うこと（内部用語と表示用語は意図的に異なりうる）。",
                        ["01", "46", "48", "41", "47", "30"]),
}

HEADER = """<!-- 自動生成ファイル: 編集禁止 -->
> **このファイルは docs/*.yaml から生成された読み取り専用ビューです（正本ではありません）。**
> 内容を変えたい場合は対応する docs/*.yaml を編集し、`python tools/build.py agentdocs` で再生成してください。
> 生成: {ts} / 生成元: {srcs}

**目的**: {purpose}

"""


def _adopted():
    """catalog の status=na な file 集合を返す（除外用）。"""
    p = os.path.join(DOCS, "catalog.yaml")
    na = set()
    if os.path.exists(p):
        cat = yaml.safe_load(open(p, encoding="utf-8")) or {}
        for it in cat.get("items", []):
            if it.get("status") == "na" and it.get("file"):
                na.add(nfc(it["file"]))
    return na


def _find(num):
    hits = glob.glob(os.path.join(DOCS, f"{num}_*.yaml"))
    return hits[0] if hits else None


def render_digest(name, purpose, nums, mdx, na):
    parts, srcs = [], []
    for num in nums:
        fp = _find(num)
        if not fp:
            continue
        base = os.path.basename(fp)[:-5]
        if nfc(base) in na:
            continue
        d = yaml.safe_load(open(fp, encoding="utf-8")) or {}
        body = mdx.render_doc(d)
        # ダイジェストでは文書見出しを1段下げ、meta表(冒頭の項目|値)を落として圧縮
        lines = body.splitlines()
        out, skip_meta = [], 0
        for i, l in enumerate(lines):
            if l.startswith("# "):
                out.append("#" + l); continue
            if l.startswith("| 項目 | 値 |"):
                skip_meta = 1; continue
            if skip_meta and l.startswith("|"):
                continue
            skip_meta = 0
            out.append(l)
        # 章見出しも1段下げ
        out = [("#" + l if l.startswith("## ") or l.startswith("### ") or l.startswith("#### ") else l) for l in out]
        parts.append("\n".join(out).strip() + "\n")
        srcs.append(base)
    ts = datetime.date.today().isoformat()
    return HEADER.format(ts=ts, srcs=", ".join(srcs) or "(該当なし)", purpose=purpose) + "\n\n---\n\n".join(parts), srcs


def main():
    mdx = load_tool("md_export")
    na = _adopted()
    os.makedirs(OUT, exist_ok=True)
    for name, (purpose, nums) in DIGESTS.items():
        text, srcs = render_digest(name, purpose, nums, mdx, na)
        open(os.path.join(OUT, name), "w", encoding="utf-8").write(text)
        print(f"[agentdocs] {name} ← {len(srcs)}文書 ({', '.join(s.split('_')[0] for s in srcs)})")
    print(f"[agentdocs] → build/agent/  （読み取り専用ビュー。正本は docs/*.yaml）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
