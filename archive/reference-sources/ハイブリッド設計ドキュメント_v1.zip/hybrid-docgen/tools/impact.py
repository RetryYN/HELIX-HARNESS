# -*- coding: utf-8 -*-
"""impact: 変更の影響範囲を依存グラフから列挙する(「どこまで見直すか」の機械回答)。

  python tools/build.py impact --id F-004    # ID起点: 上(遡り)/下(波及)/横(検証)/本文参照/台帳
  python tools/build.py impact --doc 22      # 文書起点: 依存の入出エッジと定義IDの波及サマリ

エージェントの見直し規約(vmodel-workflow スキル参照):
  上(↑) = traces_from を根まで遡る……変更が上流の意図とまだ整合するかを読む
  下(↓) = 自分を traces_from に持つ子孫と tests……変更の波及先。子孫の記述と宣言テストを見直す
  横(⇔) = 宣言テスト(検証書面)と assign 台帳の該当タスク……V字対の検証側。実行済みなら再実行対象
  本文参照 = 表・本文にIDが登場する文書……記述の食い違いが生まれやすい場所
"""
import os, sys, argparse
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from util import load_tool

DOCS = os.path.join(os.path.abspath(os.path.join(HERE, "..")), "docs")


def _spec_index():
    """全文書の spec.defines を {id: {doc, kind, up:[], down:[], tests:[]}} に索引化。
    up は traces_from（上流宣言）、down は traces_to（下流宣言。02のUS→R など）。"""
    import glob
    idx = {}
    for fp in sorted(glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml"))):
        name = os.path.basename(fp)[:-5]
        d = yaml.safe_load(open(fp, encoding="utf-8")) or {}
        for e in (d.get("spec", {}) or {}).get("defines", []) or []:
            if e.get("id"):
                idx[e["id"]] = {"doc": name, "kind": e.get("kind", ""),
                                "up": list(e.get("traces_from") or []),
                                "down": list(e.get("traces_to") or []),
                                "tests": list(e.get("tests") or [])}
    return idx


def _closure(seed, nxt):
    seen, work = [], [seed]
    while work:
        x = work.pop()
        for y in nxt(x):
            if y not in seen and y != seed:
                seen.append(y); work.append(y)
    return seen


def impact_id(target):
    b = load_tool("build")
    docs, defmap, defall, refs, dep = b._extract_ids()
    idx = _spec_index()
    if target not in defmap and target not in idx:
        print(f"[impact] {target} は定義されていません（validate の未定義参照を確認）"); return 1
    down_map = {}
    for i, e in idx.items():
        for u in e["up"]:
            down_map.setdefault(u, []).append(i)
        for d_ in e.get("down", ()):          # traces_to は自分→下流の宣言
            down_map.setdefault(i, []).append(d_)
    # 上下の導出は2つの網を合成する:
    #  - idx      … spec.defines の traces_from（Vモデル網）
    #  - comp     … 定義表の行内共起による G→EP→US→AC（スクラム網。scrum層がある場合のみ）
    # ハイブリッド配布では EP→US(共起) → US→要件(spec) と両網を跨いで閉包を辿れる。
    import glob as _glob
    import id_utils as IU
    comp = {}
    if IU.scrum_mode():
        comp = IU.def_row_companions(sorted(_glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml"))))
    rk = IU.scrum_rank

    to_up = {}
    for i, e in idx.items():
        for d_ in e.get("down", ()):
            to_up.setdefault(d_, []).append(i)

    def up_of(x):
        out = list(idx.get(x, {}).get("up", [])) + list(to_up.get(x, ()))
        r = rk(x)
        if r is not None:
            out += [y for y in comp.get(x, ()) if (rk(y) or 99) < r]
            out += [h for h, cs in comp.items() if x in cs and (rk(h) or 99) < r]
        return sorted(set(out))

    def down_of(x):
        out = list(down_map.get(x, []))
        r = rk(x)
        if r is not None:
            out += [y for y in comp.get(x, ()) if (rk(y) or -1) > r]
            out += [h for h, cs in comp.items() if x in cs and (rk(h) or -1) > r]
        return sorted(set(out))

    ups = _closure(target, up_of)
    downs = _closure(target, down_of)
    tests = sorted({t for i in [target] + downs for t in idx.get(i, {}).get("tests", [])})
    scrum_fallback = bool(comp) and rk(target) is not None
    ref_docs = sorted(n for n, ids in refs.items() if target in ids)
    # 台帳
    asg = yaml.safe_load(open(os.path.join(DOCS, "assign.yaml"), encoding="utf-8")) \
        if os.path.exists(os.path.join(DOCS, "assign.yaml")) else {}
    hits = []
    for sec in ("impl", "verify"):
        for r in (asg or {}).get(sec) or []:
            rid = r.get("id")
            if rid == target or rid in downs or rid in tests \
               or target in set(r.get("traces") or []):
                hits.append((sec, rid, r.get("status", "")))
    loc = defmap.get(target) or idx.get(target, {}).get("doc", "?")
    print(f"[impact] {target}（定義: {loc}）の見直し範囲")
    print(f"  ↑ 上流(意図との整合を読む): {', '.join(ups) or '（根＝これが最上流）'}")
    print(f"  ↓ 下流(波及先の記述を見直す): {', '.join(downs) or 'なし'}")
    if scrum_fallback:
        acs = sorted(x for x in [target] + downs if str(x).startswith("AC-"))
        print(f"  ⇔ 横(検証=再確認対象のAC): {', '.join(acs) or 'なし（受入の正本は29/06系を確認）'}")
        if tests:
            print(f"  ⇔ 横(宣言テスト=再実行対象): {', '.join(tests)}")
    else:
        print(f"  ⇔ 横(宣言テスト=再実行対象): {', '.join(tests) or 'なし ← テスト欠落の疑い'}")
    print(f"  📄 本文参照(食い違いが出やすい): {', '.join(ref_docs) or 'なし'}")
    for sec, rid, st in hits:
        mark = "再実行が必要" if st in ("done", "pass") else f"status={st}"
        print(f"  📒 台帳({sec}): {rid} … {mark}")
    print(f"  → 手順: 上流を読む → 対象と下流を修正 → detect → 横のテストを再実行し台帳更新 → signals")
    return 0


def impact_doc(num):
    b = load_tool("build")
    docs, defmap, defall, refs, dep = b._extract_ids()
    me = next((n for n in docs if n.startswith(num + "_")), None)
    if not me:
        print(f"[impact] {num}_* が見つかりません"); return 1
    my_ids = sorted(i for i, d in defmap.items() if d == me)
    users = sorted(n for n, ids in refs.items() if n != me and ids & set(my_ids))
    my_refs = sorted({defmap[i] for i in refs.get(me, set()) if i in defmap and defmap[i] != me})
    print(f"[impact] {me} の見直し範囲")
    print(f"  定義ID {len(my_ids)} 件: {', '.join(my_ids[:15])}{' …' if len(my_ids)>15 else ''}")
    print(f"  ← この文書が参照する定義元(上流・整合を読む): {', '.join(my_refs) or 'なし'}")
    print(f"  → この文書のIDを参照する文書(下流・見直す): {', '.join(users) or 'なし'}")
    print(f"  → 個別IDの深掘り: impact --id <ID>")
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--id"); g.add_argument("--doc")
    a = ap.parse_args()
    sys.exit(impact_id(a.id) if a.id else impact_doc(a.doc))
