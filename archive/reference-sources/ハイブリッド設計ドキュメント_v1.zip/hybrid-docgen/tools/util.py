# -*- coding: utf-8 -*-
"""tools共通ユーティリティ（重複していた _imp / 出力ラベル判定 の一本化）。"""
import os, sys, subprocess, unicodedata, importlib.util

# cp932等のコンソールで ✓✗△ などが UnicodeEncodeError にならないための防御(表示は?に劣化するが落ちない)
for _st in (sys.stdout, sys.stderr):
    try:
        _st.reconfigure(errors="replace")
    except Exception:
        pass
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
_cache = {}


def load_tool(name):
    """tools/<name>.py をモジュールとして読み込む（キャッシュあり）。"""
    if name not in _cache:
        spec = importlib.util.spec_from_file_location(name, os.path.join(HERE, name + ".py"))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        _cache[name] = m
    return _cache[name]


def out_label():
    """記入済み出力のサフィックス: 同梱サンプル(product.yaml: sample: true)=見本 / 自案件=現況。"""
    try:
        p = yaml.safe_load(open(os.path.join(DOCS, "product.yaml"), encoding="utf-8")) or {}
        return "見本" if p.get("sample") else "現況"
    except Exception:
        return "見本"


def nfc(s):
    """ファイル名突合用のNFC正規化(macOSのNFD名対策)。"""
    return unicodedata.normalize("NFC", str(s))


def run_tool(cmd, **kw):
    """子プロセス実行の標準形: 子はUTF-8で出力(PYTHONUTF8/PYTHONIOENCODING強制)、親はutf-8/replaceで受ける。
    Windows(cp932)でも decode 例外や文字化けを起こさないための一本化。"""
    env = dict(os.environ)
    env.update(kw.pop("env", {}) or {})
    env.update(PYTHONUTF8="1", PYTHONIOENCODING="utf-8")   # 強制は最後(呼出側envに上書きされない)
    return subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", env=env, **kw)
