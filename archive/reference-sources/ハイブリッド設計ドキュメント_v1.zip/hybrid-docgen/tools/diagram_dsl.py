# -*- coding: utf-8 -*-
"""データ駆動 作図エンジン。docs/diagrams.yaml を読み、YAMLの定義から図を描画する(案件非依存)。
対応タイプ: flow / er / sequence / wireframe
"""
import os, yaml
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Ellipse, Polygon, Circle
import matplotlib.font_manager as fm

_FP=None
for c in ["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",          # Linux
          "/usr/share/fonts/truetype/fonts-japanese-gothic.ttf",             # Linux
          "C:/Windows/Fonts/YuGothM.ttc", "C:/Windows/Fonts/meiryo.ttc",     # Windows
          "C:/Windows/Fonts/msgothic.ttc",                                    # Windows
          "/System/Library/Fonts/ヒラギノ角ゴシック W3.ttc",                     # macOS
          "/System/Library/Fonts/Hiragino Sans GB.ttc"]:                     # macOS
    if os.path.exists(c): _FP=c; break
if _FP:
    JF=fm.FontProperties(fname=_FP)
else:
    # パスで見つからない場合はフォント名で探索（豆腐化の最終防衛線）
    _names={f.name for f in fm.fontManager.ttflist}
    _cand=next((n for n in ("Noto Sans CJK JP","Yu Gothic","Meiryo","MS Gothic",
                            "Hiragino Sans","IPAGothic") if n in _names), None)
    JF=fm.FontProperties(family=_cand) if _cand else fm.FontProperties()

THEME={
 "navy":"#1F3864","blue":"#2E5496","band":"#D9E1F2","green":"#E2EFDA","greene":"#548235",
 "gold":"#FFF3D6","golde":"#BF8F00","red":"#C00000","gray":"#808080","white":"#FFFFFF"
}
STYLE={  # node style -> (facecolor, edgecolor, textcolor, rounded)
 "box":("#D9E1F2","#1F3864","#1F3864",True),
 "plain":("#FFFFFF","#1F3864","#1F3864",True),
 "data":("#E2EFDA","#548235","#548235",True),
 "ext":("#FFFFFF","#1F3864","#1F3864",False),
 "warn":("#FFF3D6","#BF8F00","#BF8F00",True),
 "ok":("#E2EFDA","#548235","#548235",True),
 "bad":("#F2DCDB","#C00000","#C00000",True),
}

def _t(ax,x,y,s,size=9,color="#222",bold=False,ha="left",va="center"):
    ax.text(x,y,s,fontproperties=JF,fontsize=size,color=color,ha=ha,va=va,fontweight=("bold" if bold else "normal"))

def _fig(w=9.8,h=5.6,title=""):
    fig,ax=plt.subplots(figsize=(w,h),dpi=150); ax.set_xlim(0,100); ax.set_ylim(0,100*h/w); ax.axis("off")
    if title: _t(ax,2,100*h/w-4,title,size=14,color=THEME["navy"],bold=True)
    return fig,ax,100*h/w

def _save(fig,path): plt.tight_layout(); fig.savefig(path,dpi=150,bbox_inches="tight"); plt.close(fig)

def _arrow(ax,p1,p2,label="",dashed=False,color="#555"):
    ax.add_patch(FancyArrowPatch(p1,p2,arrowstyle="-|>",mutation_scale=13,color=color,lw=1.3,
                 linestyle="--" if dashed else "-",connectionstyle="arc3,rad=0"))
    if label:
        _t(ax,(p1[0]+p2[0])/2,(p1[1]+p2[1])/2+1.4,label,size=8,color="#333",ha="center")

# ---------------- flow ----------------
def render_flow(ax,Y,spec):
    cols=spec.get("cols",6); rows=spec.get("rows",5)
    x0,y0=8,Y-10; colw=(92-8)/max(cols,1); rowh=(y0-8)/max(rows,1)
    def cx(c): return x0+ (c+0.5)*colw
    def cy(r): return y0- (r+0.5)*rowh
    # groups (背景の帯/箱)
    for g in spec.get("groups",[]):
        c0,c1=g["cols"]; r0,r1=g["rows"]
        gx=x0+c0*colw; gy=y0-(r1+1)*rowh; gw=(c1-c0+1)*colw; gh=(r1-r0+1)*rowh
        ax.add_patch(Rectangle((gx+1,gy+1),gw-2,gh-2,fc=g.get("fill","#F5F7FB"),ec=g.get("ec","#C9D2E3"),lw=1.1))
        _t(ax,gx+3,gy+gh-3,g.get("label",""),size=8,color=THEME["gray"])
    pos={}
    for n in spec["nodes"]:
        st=n.get("style","box"); fc,ec,tc,rnd=STYLE.get(st,STYLE["box"])
        w=n.get("w",colw*0.8); h=n.get("h",rowh*0.55)
        x=cx(n["col"]); y=cy(n["row"]); pos[n["id"]]=(x,y,w,h)
        if st=="decision":
            ax.add_patch(Polygon([(x,y+h/2),(x+w/2,y),(x,y-h/2),(x-w/2,y)],closed=True,fc="#FFF3D6",ec="#BF8F00",lw=1.3))
            _t(ax,x,y,n["label"],size=8,color="#BF8F00",ha="center")
        elif st in ("start","end"):
            ax.add_patch(Circle((x,y),1.4,fc=("k" if st=="end" else "#FFFFFF"),ec="k",lw=1.4))
        elif st=="oval":
            ax.add_patch(Ellipse((x,y),w,h,fc=fc,ec=ec,lw=1.2)); _t(ax,x,y,n["label"],size=8,color=tc,ha="center")
        else:
            bs=("round,pad=0.02,rounding_size=1.2" if rnd else "square,pad=0.02")
            ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle=bs,fc=fc,ec=ec,lw=1.4))
            _t(ax,x,y,n["label"],size=n.get("fs",9),color=tc,ha="center")
    def anchor(a,b):
        ax_,ay,aw,ah=a; bx,by,bw,bh=b
        # 中心間ベクトルで箱の辺に接続
        dx,dy=bx-ax_,by-ay
        def edge(cx0,cy0,w,h,dx,dy):
            if dx==0 and dy==0: return cx0,cy0
            sx = (w/2)/abs(dx) if dx!=0 else 1e9
            sy = (h/2)/abs(dy) if dy!=0 else 1e9
            s=min(sx,sy); return cx0+dx*s, cy0+dy*s
        p1=edge(ax_,ay,aw,ah,dx,dy); p2=edge(bx,by,bw,bh,-dx,-dy)
        return p1,p2
    for e in spec.get("edges",[]):
        a=pos[e["from"]]; b=pos[e["to"]]
        p1,p2=anchor(a,b)
        _arrow(ax,p1,p2,e.get("label",""),e.get("dashed",False),
               THEME.get(e.get("color","gray"),"#555") if e.get("color") else "#555")
    if spec.get("note"): _t(ax,2,3,spec["note"],size=8,color=THEME["gray"])

# ---------------- er ----------------
def render_er(ax,Y,spec):
    cols=spec.get("cols",3); rows=spec.get("rows",3)
    x0,y0=6,Y-9; colw=(94-6)/max(cols,1); rowh=(y0-6)/max(rows,1)
    pos={}
    for ent in spec["entities"]:
        c,r=ent["col"],ent["row"]; fields=ent.get("fields",[])
        w=colw*0.82; hh=6+3.2*len(fields)
        x=x0+c*colw+colw*0.09; y=y0-r*rowh
        ax.add_patch(Rectangle((x,y-hh),w,hh,fc="#FFFFFF",ec=THEME["navy"],lw=1.5))
        ax.add_patch(Rectangle((x,y-4.5),w,4.5,fc=THEME["navy"],ec=THEME["navy"]))
        _t(ax,x+w/2,y-2.25,ent["name"],size=8.5,color="white",ha="center")
        for i,fld in enumerate(fields):
            _t(ax,x+1.5,y-6.5-3.0*i,fld,size=7.4,color="#222")
        pos[ent["id"]]=(x+w/2,y-hh/2,w,hh,x,y,hh)
    for rel in spec.get("relations",[]):
        a=pos[rel["from"]]; b=pos[rel["to"]]
        p1=(a[0],a[1]); p2=(b[0],b[1])
        ax.add_patch(FancyArrowPatch(p1,p2,arrowstyle="-",mutation_scale=1,color=THEME["navy"],lw=1.2))
        _t(ax,(p1[0]+p2[0])/2,(p1[1]+p2[1])/2+1.3,rel.get("label",""),size=7.6,color="#333",ha="center")
    if spec.get("note"): _t(ax,2,3,spec["note"],size=8,color=THEME["gray"])

# ---------------- sequence ----------------
def render_sequence(ax,Y,spec):
    actors=spec["actors"]; n=len(actors)
    x0=8; xw=(92-8)/max(n-1,1)
    xs=[x0+i*xw for i in range(n)]
    top=Y-9
    for i,a in enumerate(actors):
        ax.add_patch(FancyBboxPatch((xs[i]-xw*0.32,top),xw*0.64,5,boxstyle="round,pad=0.02,rounding_size=1",
                     fc=THEME["band"],ec=THEME["navy"],lw=1.3))
        _t(ax,xs[i],top+2.5,a,size=8,color=THEME["navy"],ha="center")
        ax.plot([xs[i],xs[i]],[top,6],color="#9AA7C0",lw=1.0,ls=(0,(4,3)))
    y=top-4; step=spec.get("step",5)
    for m in spec["messages"]:
        i,j=m["from"],m["to"]
        if i==j:
            ax.add_patch(Rectangle((xs[i]-1,y-2),2,3,fc=THEME["band"],ec=THEME["blue"]))
            _t(ax,xs[i]+3,y-0.5,m.get("label",""),size=8,color="#222")
        else:
            _arrow(ax,(xs[i],y),(xs[j],y),"",m.get("dashed",False),
                   THEME.get(m.get("color","gray"),"#555") if m.get("color") else "#555")
            _t(ax,(xs[i]+xs[j])/2,y+1.2,m.get("label",""),size=8,color=(THEME.get(m.get("color"),"#333") if m.get("color") else "#333"),ha="center")
        y-=step
    if spec.get("note"): _t(ax,2,3,spec["note"],size=8,color=THEME["gray"])

# ---------------- wireframe ----------------
def render_wireframe(ax,Y,spec):
    ax.add_patch(Rectangle((3,5),94,Y-11,fc="#FFFFFF",ec="#999",lw=1.2))
    ax.add_patch(Rectangle((3,Y-11),94,5,fc="#EEF2F8",ec="#999"))
    _t(ax,5,Y-8.5,spec.get("header","App"),size=10,color=THEME["navy"])
    side=spec.get("sidebar",[])
    if side:
        ax.add_patch(Rectangle((3,5),16,Y-16,fc="#F5F7FB",ec="#999"))
        for i,s in enumerate(side): _t(ax,4.5,Y-13-i*4.2,"• "+s,size=8,color="#333")
    cols=spec.get("columns",[]); cx0=21; cw=(96-cx0)/max(len(cols),1)
    for ci,col in enumerate(cols):
        x=cx0+ci*cw
        ax.add_patch(Rectangle((x,7),cw-1.5,Y-19,fc=col.get("fill","#EEF2F8"),ec="#BBB"))
        _t(ax,x+(cw-1.5)/2,Y-13,col.get("name",""),size=9,color=THEME["navy"],bold=True,ha="center")
        for k,card in enumerate(col.get("cards",[])):
            cy=Y-17-k*7
            ax.add_patch(Rectangle((x+1,cy-4),cw-3.5,6,fc="#FFFFFF",ec="#CCC"))
            _t(ax,x+2,cy-0.5,card,size=7.5,color="#333")
    if spec.get("note"): _t(ax,2,3,spec["note"],size=8,color=THEME["gray"])

# ---------------- burnup ----------------
def render_burnup(ax,Y,spec):
    """リリースバーンアップ: 完了SP累計とスコープ線の推移。points: [{label, done, scope, memo?}]"""
    pts=spec.get("points",[])
    if not pts: return
    n=len(pts); x0,x1=12,92; y0,y1=10,Y-14
    vmax=max(max(float(p["scope"]) for p in pts), max(float(p["done"]) for p in pts)) or 1
    def X(i): return x0+(x1-x0)*(i/(n-1) if n>1 else 0)
    def V(v): return y0+(y1-y0)*(float(v)/vmax)
    # 軸
    ax.plot([x0,x1],[y0,y0],color="#999",lw=1.0); ax.plot([x0,x0],[y0,y1+2],color="#999",lw=1.0)
    for g in (0.25,0.5,0.75,1.0):
        ax.plot([x0,x1],[y0+(y1-y0)*g]*2,color="#e6e6e6",lw=0.8,zorder=0)
        _t(ax,x0-1.5,y0+(y1-y0)*g,str(int(vmax*g)),size=8,color="#888",ha="right")
    # スコープ線(階段)と完了線
    xs=[X(i) for i in range(n)]
    sc=[V(p["scope"]) for p in pts]; dn=[V(p["done"]) for p in pts]
    ax.plot(xs,sc,color=THEME["navy"],lw=1.6,linestyle="--",marker="s",markersize=4)
    ax.plot(xs,dn,color=THEME.get("greene","#548235"),lw=2.0,marker="o",markersize=5)
    for i,p in enumerate(pts):
        _t(ax,xs[i],y0-3.2,str(p.get("label","")),size=8.5,color="#333",ha="center")
        if p.get("memo"): _t(ax,xs[i],dn[i]-4.0,str(p["memo"]),size=7.5,color="#666",ha="center")
    _t(ax,x1,sc[-1]+2.2,"総スコープ",size=8.5,color=THEME["navy"],ha="right")
    _t(ax,x1,dn[-1]+2.2,"完了SP累計",size=8.5,color="#548235",ha="right")
    if spec.get("forecast"):
        _t(ax,x0,y1+3.0,"予測: "+str(spec["forecast"]),size=9,color="#7a5c00")
    if spec.get("note"): _t(ax,x0,2.5,"※ "+str(spec["note"]),size=8,color="#666")

RENDERERS={"flow":render_flow,"er":render_er,"sequence":render_sequence,"wireframe":render_wireframe,"burnup":render_burnup}

def render_one(spec,path):
    w=spec.get("w",9.8); h=spec.get("h",5.6)
    fig,ax,Y=_fig(w,h,spec.get("name",""))
    RENDERERS[spec["type"]](ax,Y,spec)
    _save(fig,path)

def build_from_yaml(spec_path,out):
    data=yaml.safe_load(open(spec_path,encoding="utf-8"))
    ddir=os.path.join(out,"図面"); os.makedirs(ddir,exist_ok=True)
    result=[]
    for d in data.get("diagrams",[]):
        p=os.path.join(ddir,d["name"]+".png"); render_one(d,p); result.append((d["name"],p,d.get("trace","")))
    return result
