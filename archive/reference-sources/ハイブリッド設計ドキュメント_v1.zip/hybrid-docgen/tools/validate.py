# -*- coding: utf-8 -*-
"""ID参照の整合チェック。定義(spec.defines/agent.defines/定義表)と参照(本文)を突き合わせ、
未定義参照・未使用定義を報告する。"""
import os, glob, yaml
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import id_utils as IU


def _iter_docs(docs_dir):
    files=sorted(glob.glob(os.path.join(docs_dir,"[0-9][0-9]*_*.yaml")))
    try:
        import scope as _scope; files=_scope.filter_files(files)   # スコープ活性時のみ
    except Exception: pass
    for f in files:
        yield f, yaml.safe_load(open(f,encoding="utf-8")) or {}


def run(docs_dir):
    files=[]
    for f,_ in _iter_docs(docs_dir):
        files.append(f)
    docs, defmap, defall, refs_by_doc, dep = IU.extract_from_files(files)
    defined=set(defmap)
    referenced={}
    for name, ids in refs_by_doc.items():
        for iid in ids:
            referenced.setdefault(iid,set()).add(name + ".yaml")
    # トレーサビリティ俯瞰も参照源に含める
    tf=os.path.join(docs_dir,"traceability.yaml")
    if os.path.exists(tf):
        tr=yaml.safe_load(open(tf,encoding="utf-8")) or {}
        for iid in IU.scan_ids(tr.get("sample",[])) | IU.scan_ids(tr.get("template",[])):
            referenced.setdefault(iid,set()).add("traceability.yaml")
    # テストID・外部実装IDは、定義表を持たない運用を許容。
    ALLOW_PREFIX=("UT-","IT-","ST-","AT-","US-","MSG-","GA-","OT-","D-NF-","MOD-","CMN-")
    try:
        import scope as _scope; EXT=_scope.external_ids()   # 対象外書面のIDは外部扱い
    except Exception: EXT=set()
    missing=[]
    for rid,files in sorted(referenced.items()):
        if rid in defined: continue
        if rid in EXT: continue
        if rid.startswith(ALLOW_PREFIX): continue
        missing.append((rid,sorted(files)))
    unused=sorted(d for d in defined if d not in referenced and d not in EXT)
    print(f"[validate] 定義ID {len(defined)} / 参照ID {len(referenced)}")
    ok=True
    if missing:
        ok=False; print("  ✗ 未定義の参照:")
        for rid,files in missing: print(f"     - {rid}  (参照元: {', '.join(files)})")
    else:
        print("  ✓ 未定義参照なし")
    if unused:
        print("  △ 未参照の定義(トレース漏れの可能性):")
        for u in unused: print(f"     - {u}")
    else:
        print("  ✓ 未参照定義なし")
    return ok
