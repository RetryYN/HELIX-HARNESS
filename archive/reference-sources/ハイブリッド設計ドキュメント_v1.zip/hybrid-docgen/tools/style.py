# -*- coding: utf-8 -*-
"""共通スタイル基盤 : Vモデル ドキュメントテンプレート"""
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.utils.cell import range_boundaries

NAVY="1F3864"; BLUE="2E5496"; BAND="D9E1F2"; BAND2="E9EDF7"; LABEL="F2F2F2"
HEADER="44546A"; ACCENT="4472C4"; WHITE="FFFFFF"; BLACK="000000"; GRAY="808080"; LIGHT="FBFBFD"
FONT="Meiryo"

def F(sz=10,bold=False,color=BLACK,italic=False):
    return Font(name=FONT,size=sz,bold=bold,color=color,italic=italic)

_thin=Side(style="thin",color="BFBFBF"); _med=Side(style="medium",color="7F7F7F")
BORDER=Border(left=_thin,right=_thin,top=_thin,bottom=_thin)
BOX=Border(left=_med,right=_med,top=_med,bottom=_med)

def fill(c): return PatternFill("solid",fgColor=c)
L =Alignment(horizontal="left",vertical="center",wrap_text=True)
LT=Alignment(horizontal="left",vertical="top",wrap_text=True)
C =Alignment(horizontal="center",vertical="center",wrap_text=True)
R =Alignment(horizontal="right",vertical="center",wrap_text=True)

def widths(ws,m):
    for col,w in m.items(): ws.column_dimensions[col].width=w

def merge(ws,rng,value=None,f=None,al=None,fl=None,border=True):
    ws.merge_cells(rng); first=rng.split(":")[0]; c=ws[first]
    if value is not None: c.value=value
    if f: c.font=f
    if al: c.alignment=al
    if fl: c.fill=fill(fl)
    if border:
        a,b,d,e=range_boundaries(rng)
        for rr in range(b,e+1):
            for cc in range(a,d+1):
                ws.cell(row=rr,column=cc).border=BORDER
    return c

def cell(ws,ref,value=None,f=None,al=None,fl=None,border=True):
    c=ws[ref]
    if value is not None: c.value=value
    c.font=f or F(); c.alignment=al or L
    if fl: c.fill=fill(fl)
    if border: c.border=BORDER
    return c

def add_cover(wb,doc_title,meta,sample=False):
    ws=wb.create_sheet("表紙"); ws.sheet_view.showGridLines=False
    widths(ws,{"A":2.5,"B":6,"C":6,"D":14,"E":14,"F":6,"G":14,"H":14,"I":14,"J":6,"K":4})
    for r in range(1,42): ws.row_dimensions[r].height=20
    merge(ws,"B2:J2",None,fl=NAVY,border=False); ws.row_dimensions[2].height=8
    merge(ws,"B6:J9",doc_title,F(24,True,WHITE),C,NAVY)
    for r in range(6,10):
        for c in range(2,11): ws.cell(row=r,column=c).border=BOX
    merge(ws,"B10:J10","System Development Document",F(11,False,WHITE,True),C,BLUE)
    start=14
    for i,(label,val) in enumerate(meta):
        r=start+i*2
        merge(ws,f"C{r}:E{r+1}",label,F(11,True,WHITE),C,HEADER)
        merge(ws,f"F{r}:J{r+1}",(val if sample else ""),F(11),L,WHITE)
    foot=start+len(meta)*2+2
    merge(ws,f"C{foot}:J{foot+1}","株式会社 ○○○○",F(12,True,NAVY),R,WHITE,border=False)
    return ws

def add_history(wb,doc_label,rows=None,sample=False):
    ws=wb.create_sheet("更新履歴"); ws.sheet_view.showGridLines=False
    widths(ws,{"A":3,"B":6,"C":14,"D":12,"E":22,"F":40,"G":3})
    merge(ws,"B2:F2",f"{doc_label}　更新履歴",F(16,True,NAVY),L,WHITE,border=False)
    ws.row_dimensions[2].height=26
    for j,h in enumerate(["No","更新日","更新者","更新箇所","更新内容"]):
        cell(ws,f"{get_column_letter(2+j)}4",h,F(10,True,WHITE),C,HEADER)
    ws.row_dimensions[4].height=22
    data=rows or []
    for i in range(18):
        r=5+i; ws.row_dimensions[r].height=20
        vals=list(data[i]) if (sample and i<len(data)) else [i+1,"","","",""]
        for j,v in enumerate(vals):
            al=C if j in (0,1,2) else LT
            cell(ws,f"{get_column_letter(2+j)}{r}",v if v!="" else None,F(10),al,WHITE if i%2==0 else LIGHT)
    return ws

def add_toc(wb,doc_title,chapters,sample=False):
    ws=wb.create_sheet("目次"); ws.sheet_view.showGridLines=False
    widths(ws,{"A":3,"B":10,"C":50,"D":10,"E":3})
    merge(ws,"B2:D2",f"{doc_title}　目次",F(16,True,NAVY),L,WHITE,border=False)
    ws.row_dimensions[2].height=26
    cell(ws,"B4","章",F(10,True,WHITE),C,HEADER)
    cell(ws,"C4","タイトル",F(10,True,WHITE),C,HEADER)
    cell(ws,"D4","ページ",F(10,True,WHITE),C,HEADER)
    ws.row_dimensions[4].height=20
    for i,(ch,title,pg) in enumerate(chapters):
        r=5+i; ws.row_dimensions[r].height=19; top=ch.startswith("第")
        cell(ws,f"B{r}",ch,F(10,top),C,BAND if top else WHITE)
        cell(ws,f"C{r}",title,F(10,top),L,BAND if top else WHITE)
        cell(ws,f"D{r}",(pg if sample else ""),F(10),C,WHITE)
    return ws

def content_sheet(wb,sheet_name,doc_title,chap_no,chap_title,ncols,meta_author="",meta_date="",sample=False):
    ws=wb.create_sheet(sheet_name[:31]); ws.sheet_view.showGridLines=False
    last=get_column_letter(ncols)
    merge(ws,f"A1:{get_column_letter(max(2,ncols-4))}1",doc_title,F(12,True,WHITE),L,NAVY)
    merge(ws,f"A2:{get_column_letter(max(2,ncols-4))}2",f"{chap_no}　{chap_title}",F(13,True,WHITE),L,BLUE)
    c1=ncols-3
    merge(ws,f"{get_column_letter(c1)}1:{get_column_letter(c1)}1","作成者",F(9,True,WHITE),C,HEADER)
    merge(ws,f"{get_column_letter(c1+1)}1:{last}1",(meta_author if sample else ""),F(9),C,WHITE)
    merge(ws,f"{get_column_letter(c1)}2:{get_column_letter(c1)}2","作成日",F(9,True,WHITE),C,HEADER)
    merge(ws,f"{get_column_letter(c1+1)}2:{last}2",(meta_date if sample else ""),F(9),C,WHITE)
    ws.row_dimensions[1].height=20; ws.row_dimensions[2].height=22; ws.row_dimensions[3].height=6
    return ws

def section(ws,row,span_last_col,no,title):
    merge(ws,f"A{row}:{span_last_col}{row}",f"{no}　{title}",F(11,True,NAVY),L,BAND)
    ws.row_dimensions[row].height=22
    return row+1

def table_header(ws,row,cols):
    for col,title,w in cols:
        ws.column_dimensions[col].width=w
        cell(ws,f"{col}{row}",title,F(10,True,WHITE),C,HEADER)
    ws.row_dimensions[row].height=22
    return row+1

def note(ws,row,last_col,text):
    merge(ws,f"A{row}:{last_col}{row}",text,F(9,False,GRAY),LT,WHITE,border=False)
    return row+1
