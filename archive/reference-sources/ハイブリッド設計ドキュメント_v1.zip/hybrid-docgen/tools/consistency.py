# -*- coding: utf-8 -*-
"""consistency: 用語の表記ゆれ と ADR⇔14台帳 の突合。

  python tools/consistency.py [--check]   # detect/CI 組込み。違反で exit 1

1) 用語ゲート: 30_用語集の「略語・表記ルール」表の禁止表記列に列挙された語が、
   他文書の本文・表セルに出現したら違反（正式表記への統一を促す）。
   30自身と、41_表示名・翻訳カタログ(表示用語は内部用語と意図的に異なりうる。表示文言の正本は41)は除外。
2) ADR突合: docs/adr/ADR-*.md の各ファイルが 14 の「意思決定記録(ADR)一覧」に登録され、
   逆に一覧・各文書が参照する ADR-xxxx にファイル実体があること（宣言↔実態の双方向）。
"""
import os, sys, re, glob
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import util  # 副作用: cp932コンソールでの記号出力ガード
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
ADR_RE = re.compile(r"ADR-\d{4}")


def _docs():
    for fp in sorted(glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml"))):
        yield os.path.basename(fp)[:-5], yaml.safe_load(open(fp, encoding="utf-8")) or {}


def banned_terms():
    """30から (禁止語, 正式表記) を列挙。"""
    p = glob.glob(os.path.join(DOCS, "30_*.yaml"))
    if not p:
        return []
    d = yaml.safe_load(open(p[0], encoding="utf-8")) or {}
    out = []
    for ch in d.get("chapters", []):
        for b in ch.get("blocks", []):
            if b.get("t") != "table":
                continue
            heads = [c[1] for c in b.get("cols", [])]
            if "禁止表記(検出対象)" not in heads:
                continue
            bi = heads.index("禁止表記(検出対象)")
            fi = heads.index("正式") if "正式" in heads else 1
            for r in b.get("rows", []):
                if len(r) > bi and str(r[bi]).strip():
                    formal = str(r[fi]).strip() if len(r) > fi else ""
                    for t in re.split(r"[、,]", str(r[bi])):
                        t = t.strip()
                        if t:
                            out.append((t, formal))
    return out


def iter_text(d):
    for ch in d.get("chapters", []):
        title = ch.get("title", "")
        for b in ch.get("blocks", []):
            for k in ("text", "title"):
                if b.get(k):
                    yield title, str(b[k])
            for r in b.get("rows", []) or []:
                for c in (r if isinstance(r, list) else []):
                    yield title, str(c)
            for it in b.get("items", []) or []:
                yield title, str(it)


def check_terms():
    terms = banned_terms()
    issues = []
    if not terms:
        return issues, 0
    for name, d in _docs():
        if name.startswith(("30_", "41_")):
            continue
        for chap, s in iter_text(d):
            for t, formal in terms:
                if t in s:
                    issues.append(("表記ゆれ", name,
                                   f"「{t}」→ 正式表記「{formal}」（{chap} / …{s[max(0,s.find(t)-8):s.find(t)+len(t)+10]}…）"))
    return issues, len(terms)


def check_adr():
    issues = []
    files = {os.path.basename(p)[:8] for p in glob.glob(os.path.join(DOCS, "adr", "ADR-*.md"))}
    files.discard("ADR-0000")   # テンプレ番号は突合対象外
    listed, referenced = set(), set()
    for name, d in _docs():
        for chap, s in iter_text(d):
            for m in ADR_RE.findall(s):
                referenced.add(m)
                if name.startswith("14_"):
                    listed.add(m)
    for f in sorted(files - listed):
        issues.append(("ADR未登録", f, "docs/adr/ にファイルがあるが 14 のADR一覧に行が無い"))
    for r in sorted(referenced - files - {"ADR-0000"}):   # 0000はテンプレ番号
        issues.append(("ADR実体なし", r, "文書中で参照されているが docs/adr/ にファイルが無い"))
    return issues, len(files)


STOP = {"システム","データ","サービス","ユーザー","ファイル","テスト","エラー","バージョン",
        "リリース","プロジェクト","レビュー","チェック","レベル","フェーズ","カテゴリ","ステータス",
        "パフォーマンス","セキュリティ","アクセス","ログイン","メッセージ","イベント","プロセス",
        "インデックス","キャッシュ","トランザクション","フレームワーク","ライブラリ","コンポーネント",
        "インターフェース","アーキテクチャ","ドキュメント","テンプレート","フォーマット","タイミング"}

def unregistered_terms(min_docs=6):
    """頻出カタカナ語のうち30_用語集に未登録の候補を列挙する(抽出漏れの検出・情報のみ)。
    正しさの判定はできない——「多くの文書で使われているのに定義がない語」を人に見せるまで。"""
    p = glob.glob(os.path.join(DOCS, "30_*.yaml"))
    reg = set()
    if p:
        d = yaml.safe_load(open(p[0], encoding="utf-8")) or {}
        for _, s in iter_text(d):
            reg.add(s.strip())
        for ch in d.get("chapters", []):
            for b in ch.get("blocks", []):
                for r in b.get("rows", []) or []:
                    for c in (r if isinstance(r, list) else []):
                        reg.add(str(c).strip())
    kat = re.compile(r"[ァ-ヶー]{4,}")
    seen = {}
    for name, d in _docs():
        if name.startswith(("30_", "41_")):
            continue
        terms = set()
        for _, s in iter_text(d):
            terms |= set(kat.findall(s))
        for t in terms:
            seen.setdefault(t, set()).add(name)
    out = [(t, len(ds)) for t, ds in seen.items()
           if len(ds) >= min_docs and t not in reg and t not in STOP
           and not any(t in r for r in reg)]
    return sorted(out, key=lambda x: -x[1])


def main():
    ti, nterms = check_terms()
    ai, nadr = check_adr()
    issues = ti + ai
    cand = unregistered_terms()
    print(f"[consistency] 禁止表記 {nterms} 語 / ADRファイル {nadr} 件を突合 / 用語集未登録の頻出語候補 {len(cand)} 件")
    has_glossary = bool(glob.glob(os.path.join(DOCS, "30_*.yaml")))
    for t, n in cand[:8]:
        hint = ("30_用語集への登録を検討(表記統一の対象にできる)" if has_glossary
                else "用語集文書(30_*.yaml)を追加すれば表記統一ゲートに載せられる")
        print(f"   △ [用語未登録(情報)] 「{t}」が {n} 文書で使用 — {hint}")
    if not issues:
        print("  ✓ 表記ゆれなし・ADR宣言↔実態一致")
        return 0
    print(f"  ✗ 不整合 {len(issues)} 件:")
    for kind, tgt, msg in issues[:30]:
        print(f"     - [{kind}] {tgt}: {msg}")
    if len(issues) > 30:
        print(f"     … 他 {len(issues)-30} 件")
    return 1


if __name__ == "__main__":
    sys.exit(main())
