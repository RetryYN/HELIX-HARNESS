# -*- coding: utf-8 -*-
"""工程表連携エンジン（自動検出つき）。

00_実装工程管理表(WBS/ガント) を、Vモデルのレベル対(107)・要求要件台帳(43)・
トレースメッシュRAG(spec_check)・設計書カバレッジ(catalog) と機械的に連携させ、
  (1) 各工程(L)に「対応設計書 / 要件 / RAG / 採用状況 / 整合進捗」をロールアップ
  (2) 工程表そのものの矛盾を自動検出（先行循環/日程逆転/進捗単調性/V字対欠落/
      月範囲外/採用-工程齟齬/RAG乖離）
既存エンジン(build.py)は変更せず、追加の検査・出力として動作する。

  python3 tools/schedule.py                 連携ロールアップ + 自動検出（exit 0=赤なし / 1=赤あり）
  python3 tools/schedule.py --live [PATH]   signals.json を適用して実行時進捗で判定
  python3 tools/schedule.py --xlsx          build/00_工程表連携_見本(自案件は現況).xlsx を生成
"""
import os, sys, re, argparse
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
import sys as _sys; _sys.path.insert(0, HERE)
from util import load_tool
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
OUT  = os.path.join(ROOT, "build")

# ── Vモデルのレベル対（doc 107 の定義を機械可読に固定）──────────────
# 下降(設計)L → 上昇(検証)L の 1対1 対
VPAIR = {"L1": "L12", "L2": "L11", "L3": "L10", "L4": "L9", "L5": "L8"}
UP2DOWN = {v: k for k, v in VPAIR.items()}
# 設計フェーズ(build._PHASE の列値) → 主担当の下降L
PHASE2LEVEL = {0: "L2", 1: "L3", 2: "L4", 3: "L5", 4: "L5", 5: "L12", 6: "L4"}
# 企画(01)は L1 に寄せる（フェーズ0内の例外）
DOC_LEVEL_OVERRIDE = {"01": "L1"}
GREEN_STATES = {"設計済", "完了", "done", "実装済", "テスト済"}




def load_all(live_path=None):
    b  = load_tool("build")
    sc = load_tool("spec_check")
    docs, defmap, defall, refs, dep = b._extract_ids()
    req, ken = sc.load_ledger()
    dids = {i for i in defmap if i.startswith(("F-", "NF-"))}
    ragmap = sc.rag(req, ken, dids)
    sig = None
    if live_path is not None:
        sig = sc.load_signals(live_path)
        if sig is not None:
            ragmap = sc.apply_live(ragmap, ken, sig)
    wbs = yaml.safe_load(open(os.path.join(DOCS, "wbs.yaml"), encoding="utf-8"))
    cat = yaml.safe_load(open(os.path.join(DOCS, "catalog.yaml"), encoding="utf-8"))
    return b, sc, docs, defmap, refs, req, ken, ragmap, sig, wbs, cat


def doc_num(name): return name.split("_")[0]


def doc_to_level(b, name):
    n = doc_num(name)
    if n in DOC_LEVEL_OVERRIDE: return DOC_LEVEL_OVERRIDE[n]
    ph = b._PHASE.get(n)
    if ph is None: return None
    return PHASE2LEVEL.get(ph)


def build_rollup(b, sc, docs, defmap, refs, req, ken, ragmap, cat):
    """各 L レベルに 設計書 / 要件ID / RAG / 採用状況 をロールアップ。"""
    # 設計書 → レベル
    level_docs = {}
    for name in docs:
        lv = doc_to_level(b, name)
        if lv: level_docs.setdefault(lv, []).append(name)
    # 要件(F-/NF-) → 定義元doc → レベル
    level_reqids = {}
    for rid, name in defmap.items():
        if not rid.startswith(("F-", "NF-")): continue
        lv = doc_to_level(b, name)
        if lv: level_reqids.setdefault(lv, set()).add(rid)
    # 台帳の要件IDも定義元docのレベルに合流（台帳=定義元と一致する想定）
    for kid in ken:
        name = defmap.get(kid)
        if name:
            lv = doc_to_level(b, name)
            if lv: level_reqids.setdefault(lv, set()).add(kid)
    # カバレッジ: file(doc) → 採用状況
    file_status = {}
    for it in cat.get("items", []):
        f = it.get("file", "")
        if f and f[0:2].isdigit():
            file_status.setdefault(doc_num(f), []).append(it.get("status", ""))
    return level_docs, level_reqids, file_status


def rag_of_reqids(ragmap, ken, ids):
    """要件ID集合の RAG をロールアップ。赤>黄>緑。"""
    colors = [ragmap.get(i, ("緑", []))[0] for i in ids if i in ragmap]
    if not colors: return None, 0, 0, 0
    r = colors.count("赤"); y = colors.count("黄"); g = colors.count("緑")
    agg = "赤" if r else ("黄" if y else "緑")
    return agg, r, y, g


def coverage_of_level(file_status, level_docs, lv):
    """レベルの採用状況を集計 → (done, todo, na)。"""
    d = t = n = 0
    for name in level_docs.get(lv, []):
        for s in file_status.get(doc_num(name), []):
            if s == "done": d += 1
            elif s == "todo": t += 1
            elif s == "na": n += 1
    return d, t, n


def pct(s):
    m = re.search(r"(\d+)", str(s)); return int(m.group(1)) if m else 0


def analyze(data, live_path=None):
    b, sc, docs, defmap, refs, req, ken, ragmap, sig, wbs, cat = data
    level_docs, level_reqids, file_status = build_rollup(b, sc, docs, defmap, refs, req, ken, ragmap, cat)

    tasks = wbs.get("tasks", [])
    months = wbs.get("months", [])
    # No → task, 先行参照用
    byno = {}
    rows = []
    for t in tasks:
        No, wbs_, name, who, sdt, edt, eff, prog, pre, ph = (list(t) + [""] * 10)[:10]
        rec = dict(No=str(No), wbs=str(wbs_), name=str(name), who=str(who),
                   sdt=str(sdt), edt=str(edt), eff=str(eff), prog=str(prog),
                   pre=str(pre), ph=str(ph), level=str(wbs_).strip())
        byno[str(No)] = rec; rows.append(rec)

    # レベルごとの連携（設計側 / 検証側）
    # 検証Lは対の設計Lの「成熟度(readiness)」を見る。テスト完了は signals がある時のみ導出。
    def test_pass_ratio(ids):
        if sig is None: return None
        tests = sig.get("tests", {})
        allt = []
        for kid in ids:
            for tid in re.findall(r"(?:UT|IT|ST|AT)-\d+[a-z]?", ken.get(kid, {}).get("tst", "")):
                allt.append(tid)
        if not allt: return None
        passed = sum(1 for t in allt if tests.get(t) == "pass")
        return round(passed / len(allt) * 100)

    for rec in rows:
        lv = rec["level"]
        is_design = lv in VPAIR
        design_lv = lv if is_design else UP2DOWN.get(lv)         # 検証Lは対の設計Lを参照
        ids = level_reqids.get(design_lv, set()) if design_lv else set()
        agg, r, y, g = rag_of_reqids(ragmap, ken, ids)
        d, tdo, na = coverage_of_level(file_status, level_docs, design_lv) if design_lv else (0, 0, 0)
        # 設計成熟度(readiness): 自前の要件があれば緑率、無ければカバレッジ(done率)で代替
        tot = r + y + g
        if tot:
            readiness = round(g / tot * 100)
            rag = agg
        elif (d + tdo) > 0:
            readiness = round(d / (d + tdo) * 100)
            rag = "緑" if tdo == 0 else ("黄" if d else "赤")
        else:
            readiness = None; rag = None
        rec["design_lv"] = design_lv
        rec["docs"] = [doc_num(x) for x in level_docs.get(design_lv, [])] if design_lv else []
        rec["reqids"] = sorted(ids)
        rec["rag"] = rag; rec["r"] = r; rec["y"] = y; rec["g"] = g
        rec["cov"] = (d, tdo, na)
        rec["readiness"] = readiness
        rec["is_design"] = is_design
        if is_design:
            # 設計工程: 整合進捗 = 設計成熟度(緑率/done率)
            rec["derived"] = readiness
            rec["derived_kind"] = "設計成熟"
        else:
            # 検証工程: 整合進捗 = 実テスト合格率(signalsが有る時のみ)。無ければ導出せず readiness を別掲。
            rec["derived"] = test_pass_ratio(ids)
            rec["derived_kind"] = "テスト合格"

    # WBSがVモデルL体系(L1..L12)を使っているか。使っていなければV字連携はスキップ。
    uses_levels = any((rec["level"] in VPAIR or rec["level"] in UP2DOWN) for rec in rows)

    # ── 自動検出 ─────────────────────────────────────────────
    issues = []

    # E1 先行循環
    def has_cycle():
        color = {r["No"]: 0 for r in rows}; found = []
        def dfs(u, stack):
            color[u] = 1
            p = byno.get(u, {}).get("pre", "").strip()
            for v in [x.strip() for x in re.split(r"[,\s]+", p) if x.strip()]:
                if v not in byno: continue
                if color.get(v, 0) == 1 and v in stack:
                    found.append(stack[stack.index(v):] + [v])
                elif color.get(v, 0) == 0:
                    dfs(v, stack + [v])
            color[u] = 2
        for r in rows:
            if color[r["No"]] == 0: dfs(r["No"], [r["No"]])
        return found
    for c in has_cycle():
        issues.append(("先行循環", "→".join(c), "先行(依存)が循環している"))

    # E2 日程逆転（先行の“開始”より前に始まる真の順序逆転。終了前の並行=オーバーラップは許容）
    # E3 進捗逆行（依存先=先行より自分の進捗が上回る。先行より先に完成しているのは不整合）
    for rec in rows:
        for pv in [x.strip() for x in re.split(r"[,\s]+", rec["pre"]) if x.strip()]:
            p = byno.get(pv)
            if not p: continue
            if rec["sdt"] and p["sdt"] and rec["sdt"] < p["sdt"]:
                issues.append(("日程逆転", f'{rec["No"]}:{rec["name"]}',
                               f'開始 {rec["sdt"]} が先行 {pv}:{p["name"]} の開始 {p["sdt"]} より前'))
            rp, pp = pct(rec["prog"]), pct(p["prog"])
            if rp > pp:
                issues.append(("進捗逆行", f'{rec["No"]}:{rec["name"]}',
                               f'進捗 {rec["prog"]} が先行 {pv} の {p["prog"]} を上回る（先行より先行して進捗）'))

    # E4 V字対欠落（Vモデルレベルを使う工程表のみ・実設計内容がある対象に限定）
    if uses_levels:
        have_levels = {r["level"] for r in rows}
        try:
            import scope as _scope
            _sc_on = _scope.active() is not None
            VDOC = {"L8": "06_単体テスト設計書", "L9": "07_結合テスト設計書",
                    "L10": "08_総合テスト設計書", "L11": "09_受入テスト設計書"}
            def _lv_in(lv, verify):
                if not _sc_on: return True
                if verify:
                    doc = VDOC.get(lv); return _scope.file_in_scope(doc) if doc else True
                ds = level_docs.get(lv, []); return (not ds) or any(_scope.file_in_scope(x) for x in ds)
        except Exception:
            def _lv_in(lv, verify): return True
        for dlv, ulv in VPAIR.items():
            if not _lv_in(dlv, False):          # 設計側が対象外なら V字対自体を対象外
                continue
            d0, t0, _ = coverage_of_level(file_status, level_docs, dlv)
            has_design = bool(level_reqids.get(dlv)) or d0 > 0     # 要件定義済 or 採用done がある
            if has_design and dlv not in have_levels:
                issues.append(("V字対欠落", dlv, f"設計工程 {dlv} が工程表に無い"))
            if has_design and ulv not in have_levels and _lv_in(ulv, True):
                issues.append(("V字対欠落", ulv, f"検証工程 {ulv}（{dlv} の対）が工程表に無い"))

    # E5 月範囲外
    if months:
        lo = "20" + months[0].replace("/", "-") + "-01"
        hi_y, hi_m = ("20" + months[-1].split("/")[0]), months[-1].split("/")[1]
        hi = f"{hi_y}-{hi_m}-31"
        for rec in rows:
            for d, lab in [(rec["sdt"], "開始"), (rec["edt"], "終了")]:
                if d and not (lo <= d <= hi):
                    issues.append(("月範囲外", f'{rec["No"]}:{rec["name"]}',
                                   f'{lab} {d} が months 範囲 [{months[0]}〜{months[-1]}] 外'))

    # E6 採用-工程齟齬 / E7 進捗-実態乖離（Vモデルレベル使用時のみ）
    if uses_levels:
        for rec in rows:
            if rec["level"] not in VPAIR: continue
            d, tdo, na = rec["cov"]
            if d > 0 and pct(rec["prog"]) == 0:
                issues.append(("採用-工程齟齬", f'{rec["level"]}:{rec["name"]}',
                               f'採用設計 {d}件(done) だが工程進捗 0%'))
            if d == 0 and tdo == 0 and na > 0 and pct(rec["prog"]) > 0:
                issues.append(("採用-工程齟齬", f'{rec["level"]}:{rec["name"]}',
                               f'対象外(na {na}件)の設計工程が進捗 {rec["prog"]}'))
        for rec in rows:
            hp = pct(rec["prog"])
            if rec["is_design"]:
                if rec["rag"] in ("赤", "黄") and hp >= 100:
                    issues.append(("進捗-実態乖離", f'{rec["level"]}:{rec["name"]}',
                                   f'設計100%申告だが要件RAG={rec["rag"]}（赤{rec["r"]}/黄{rec["y"]}/緑{rec["g"]}）'))
                if rec["derived"] is not None and abs(rec["derived"] - hp) >= 50:
                    issues.append(("進捗-実態乖離", f'{rec["level"]}:{rec["name"]}',
                                   f'手入力 {rec["prog"]} vs 設計成熟 {rec["derived"]}%（乖離≥50pt）'))
            else:
                if rec["derived"] is not None and abs(rec["derived"] - hp) >= 50:
                    issues.append(("進捗-実態乖離", f'{rec["level"]}:{rec["name"]}',
                                   f'手入力 {rec["prog"]} vs 実テスト合格 {rec["derived"]}%（乖離≥50pt）'))
                if hp >= 100 and rec["readiness"] is not None and rec["readiness"] < 100:
                    issues.append(("進捗-実態乖離", f'{rec["level"]}:{rec["name"]}',
                                   f'検証100%申告だが対の設計成熟 {rec["readiness"]}%（検証対象が未成熟）'))

    return rows, issues, (sig is not None), uses_levels


def report(rows, issues, live, uses_levels=True):
    from collections import Counter
    tag = " (ライブ信号)" if live else " (構造)"
    print(f"[schedule] 工程 {len(rows)} 件 / 連携ロールアップ完了{tag}")
    if not uses_levels:
        print("  ※ 工程表がVモデルL体系(L1..L12)を使用していないため、V字連携ロールアップは省略。"
              "（工程衛生チェックのみ実施：先行循環/日程逆転/進捗逆行/月範囲外）")
    else:
        for rec in rows:
            if rec["design_lv"] is None: continue          # 実装(L6/L7)等はスキップ
            rag = rec["rag"] or "-"; d, t, n = rec["cov"]
            if rec["is_design"]:
                dv = f'成熟{rec["derived"]}%' if rec["derived"] is not None else "成熟-"
                link = f'設計{",".join(rec["docs"]) or "-"}'
            else:
                rd = f'{rec["readiness"]}%' if rec["readiness"] is not None else "-"
                tp = f'合格{rec["derived"]}%' if rec["derived"] is not None else "合格-(信号なし)"
                dv = f'着手可{rd}/{tp}'
                link = f'検証←{rec["design_lv"]}'
            print(f'   {rec["level"]:<3} {rec["name"][:20]:<20} {link:<20} '
                  f'要件{len(rec["reqids"])} RAG={rag} 採用{d}/{t}/{n} 進捗{rec["prog"]}→{dv}')
    if not issues:
        print("  ✓ 工程表の構造・連携に矛盾なし（先行/日程/進捗/V字対/採用/RAG 整合）")
        return 0
    c = Counter(x[0] for x in issues)
    print("  ✗ 検出 " + " / ".join(f"{k}={v}" for k, v in c.items()))
    for kind, tgt, msg in issues:
        print(f"     - [{kind}] {tgt}: {msg}")
    # 赤系(構造破綻)があれば非0。乖離/齟齬系は警告(0)。
    hard = {"先行循環", "日程逆転", "V字対欠落"}
    return 1 if any(k in hard for k, _, _ in issues) else 0


def emit_xlsx(rows, issues, live):
    import style as S
    from openpyxl import Workbook
    from openpyxl.utils import get_column_letter
    os.makedirs(OUT, exist_ok=True)
    wb = Workbook(); ws = wb.active; ws.title = "工程表連携"; ws.sheet_view.showGridLines = False
    heads = [("工程", 6), ("タスク", 30), ("担当", 10), ("開始", 11), ("終了", 11),
             ("進捗", 7), ("整合進捗", 9), ("要件RAG", 10), ("対応設計", 16),
             ("要件数", 7), ("採用(done/todo/na)", 16)]
    S.widths(ws, {get_column_letter(i + 1): w for i, (_, w) in enumerate(heads)})
    last = get_column_letter(len(heads))
    S.merge(ws, f"A1:{last}1", "工程表連携（WBS × Vモデル対 × 台帳RAG × カバレッジ）"
            + (" ライブ" if live else ""), S.F(15, True, S.WHITE), S.L, S.NAVY)
    ws.row_dimensions[1].height = 26
    for i, (h, _) in enumerate(heads):
        S.cell(ws, f"{get_column_letter(i+1)}3", h, S.F(9, True, S.WHITE), S.C, S.HEADER)
    ws.row_dimensions[3].height = 22
    RC = {"赤": "F8CBAD", "黄": "FFF2CC", "緑": "C6EFCE"}
    r = 4
    for rec in rows:
        is_design = rec["level"] in VPAIR
        d, t, n = rec["cov"]
        dv = f'{rec["derived"]}%' if rec["derived"] is not None else "-"
        rag = rec["rag"] or "-"
        vals = [rec["level"], rec["name"], rec["who"], rec["sdt"], rec["edt"], rec["prog"],
                dv, rag, ",".join(rec["docs"]) or "-", len(rec["reqids"]) or "-",
                (f"{d}/{t}/{n}" if is_design else "-")]
        base = S.BAND if is_design else S.WHITE
        for k, v in enumerate(vals):
            fl = RC.get(rag, base) if k == 7 else base
            al = S.L if k in (1,) else S.C
            S.cell(ws, f"{get_column_letter(k+1)}{r}", v, S.F(9, is_design and k == 0), al, fl)
        ws.row_dimensions[r].height = 17; r += 1
    # 検出シート
    ws2 = wb.create_sheet("工程表・検出"); ws2.sheet_view.showGridLines = False
    S.widths(ws2, {"A": 3, "B": 18, "C": 34, "D": 52})
    S.merge(ws2, "B2:D2", "工程表 自動検出（先行/日程/進捗/V字対/月範囲/採用/RAG）",
            S.F(14, True, S.WHITE), S.L, S.NAVY); ws2.row_dimensions[2].height = 24
    S.merge(ws2, "B3:D3", f"検出 {len(issues)} 件", S.F(10, True, S.BLUE), S.L, S.WHITE, border=False)
    for j, h in enumerate(["種別", "対象", "内容"]):
        S.cell(ws2, f"{get_column_letter(2+j)}5", h, S.F(10, True, S.WHITE), S.C, S.HEADER)
    COL = {"先行循環": "F8CBAD", "日程逆転": "F8CBAD", "V字対欠落": "F8CBAD",
           "進捗逆行": "FFF2CC", "月範囲外": "FFF2CC", "採用-工程齟齬": "FFF2CC", "進捗-RAG乖離": "FFF2CC"}
    rr = 6
    if not issues:
        S.merge(ws2, "B6:D6", "✓ 工程表の構造・連携に矛盾は検出されませんでした。",
                S.F(11, True, "548235"), S.L, "E2EFDA")
    for kind, tgt, msg in issues:
        S.cell(ws2, f"B{rr}", kind, S.F(9, True), S.C, COL.get(kind, "FFFFFF"))
        S.cell(ws2, f"C{rr}", tgt, S.F(9), S.LT, S.WHITE)
        S.cell(ws2, f"D{rr}", msg, S.F(9), S.LT, S.WHITE); ws2.row_dimensions[rr].height = 16; rr += 1
    for w in (ws, ws2):
        w.page_setup.orientation = "landscape"; w.sheet_properties.pageSetUpPr = None
    from util import out_label
    out = os.path.join(OUT, f"00_工程表連携_{out_label()}.xlsx"); wb.save(out)
    print(f"[schedule] → {os.path.relpath(out, ROOT)}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", nargs="?", const="", metavar="PATH", help="signals.json 適用で実行時進捗判定")
    ap.add_argument("--xlsx", action="store_true", help="build/00_工程表連携_見本(自案件は現況).xlsx を生成")
    args = ap.parse_args()
    data = load_all(args.live)
    rows, issues, live, uses = analyze(data, args.live)
    code = report(rows, issues, live, uses)
    if args.xlsx:
        emit_xlsx(rows, issues, live)
    return code


if __name__ == "__main__":
    sys.exit(main())
