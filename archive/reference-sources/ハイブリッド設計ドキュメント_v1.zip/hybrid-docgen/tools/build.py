# -*- coding: utf-8 -*-
"""Vモデル・ドキュメント汎用ジェネレータ CLI。
  python tools/build.py init "<プロジェクト名>" [--force]   # templates/ から docs/ を雛形生成
  python tools/build.py build [--mode both|sample|blank]    # docs/*.yaml → build/ に xlsx
  python tools/build.py validate                            # ID参照の整合チェック
  python tools/build.py diagrams                            # docs/diagrams.yaml から図(PNG)+図面集
  python tools/build.py sheets --credentials sa.json        # Googleスプレッドシートへ掃き出し
"""
import os, sys, glob, argparse, yaml, shutil
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
import style as S
from render import render
from openpyxl import Workbook
from openpyxl.utils import get_column_letter
import openpyxl

ROOT=os.path.abspath(os.path.join(HERE,".."))
DOCS=os.path.join(ROOT,"docs")
TPL=os.path.join(ROOT,"templates")
OUT=os.path.join(ROOT,"build")

def load(name):
    with open(os.path.join(DOCS,name),encoding="utf-8") as f: return yaml.safe_load(f)

from util import out_label
import id_utils as IU
LBL=out_label()
def load_docs():
    return [yaml.safe_load(open(f,encoding="utf-8")) for f in sorted(glob.glob(os.path.join(DOCS,"[0-9][0-9]*_*.yaml")))]

def pagesetup(ws,landscape=False):
    ws.page_setup.orientation="landscape" if landscape else "portrait"
    ws.page_setup.fitToWidth=1; ws.page_setup.fitToHeight=0
    ws.sheet_properties.pageSetUpPr=openpyxl.worksheet.properties.PageSetupProperties(fitToPage=True)
    ws.page_margins=openpyxl.worksheet.page.PageMargins(left=0.3,right=0.3,top=0.4,bottom=0.4)
    ws.print_options.horizontalCentered=True

def build_doc(doc,sample):
    wb=Workbook(); wb.remove(wb.active)
    S.add_cover(wb,doc["title"],doc["meta"],sample)
    S.add_history(wb,doc["label"],doc.get("history",[]),sample)
    if doc.get("toc"): S.add_toc(wb,doc["title"],doc["toc"],sample)
    author=date=""
    for k,v in doc["meta"]:
        if k=="作成者": author=v
        if k in ("作成日","起案日"): date=v
    for ch in doc["chapters"]:
        ws=S.content_sheet(wb,ch["sheet"],doc["title"],ch["num"],ch["title"],ch["ncols"],author,date,sample)
        render(ws,4,ch["ncols"],ch["blocks"],sample)
    for ws in wb.worksheets: pagesetup(ws,False)
    return wb

def build_trace(sample):
    tr=load("traceability.yaml"); cols=tr["cols"]; NC=len(cols)
    rows=tr["sample"] if sample else tr["template"]
    wb=Workbook(); ws=wb.active; ws.title="俯瞰図"; ws.sheet_view.showGridLines=False
    last=get_column_letter(NC)
    S.merge(ws,f"A1:{last}1",("全体トレーサビリティ俯瞰図" if sample else "全体トレーサビリティ俯瞰図（テンプレート）"),S.F(16,True,S.WHITE),S.L,S.NAVY)
    S.merge(ws,f"A2:{last}2","Vモデル 全体トレーサビリティ（左：上流設計 → 右：対応テスト・本番・運用）",S.F(9,False,S.WHITE,True),S.L,S.BLUE)
    ws.row_dimensions[1].height=28; ws.row_dimensions[2].height=18
    for i,(t,w) in enumerate(cols):
        c=get_column_letter(i+1); ws.column_dimensions[c].width=w
        S.cell(ws,f"{c}4",t,S.F(9,True,S.WHITE),S.C,S.HEADER)
    ws.row_dimensions[4].height=24
    top=5; n=len(rows)
    for r in range(top,top+n): ws.row_dimensions[r].height=26
    for c in range(NC):
        i=0
        while i<n:
            v=rows[i][c]; j=i+1
            while j<n and rows[j][c]==v and all(rows[j][k]==rows[i][k] for k in range(c)): j+=1
            col=get_column_letter(c+1); r0=top+i; r1=top+j-1
            fl=S.BAND if c==0 else (S.WHITE if c<=4 else S.LIGHT); val=v if v else None
            if r1>r0: S.merge(ws,f"{col}{r0}:{col}{r1}",val,S.F(9,c<=4),S.C,fl)
            else: S.cell(ws,f"{col}{r0}",val,S.F(9,c<=4),S.C,fl)
            i=j
    lg=top+n+1
    S.merge(ws,f"A{lg}:{last}{lg}","凡例）左→右で1つの企画がどの要求・要件・設計・実装・テストに展開されるかを追跡。縦結合=親子(1対多)。",S.F(9,False,S.GRAY),S.LT,S.WHITE,border=False)
    ws.freeze_panes="A5"; pagesetup(ws,True); return wb

def build_wbs(sample):
    w=load("wbs.yaml"); info=w["info"]; months=w["months"]; tasks=w["tasks"]
    NI=len(info); MN=len(months); NCOL=NI+MN
    wb=Workbook(); ws=wb.active; ws.title="工程管理"; ws.sheet_view.showGridLines=False
    last=get_column_letter(NCOL)
    S.merge(ws,f"A1:{last}1",("実装工程管理表（L単位・WBS＋ガント）" if sample else "実装工程管理表（L単位）テンプレート"),S.F(16,True,S.WHITE),S.L,S.NAVY)
    S.merge(ws,f"A2:{last}2","実装工程 L1〜L7 ｜ 進捗＝現在のL（担当 人/AI）",S.F(9,False,S.WHITE,True),S.L,S.BLUE)
    ws.row_dimensions[1].height=28; ws.row_dimensions[2].height=18
    hr=4
    for i,(t,wd) in enumerate(info):
        c=get_column_letter(i+1); ws.column_dimensions[c].width=wd
        S.merge(ws,f"{c}{hr}:{c}{hr+1}",t,S.F(9,True,S.WHITE),S.C,S.HEADER)
    S.merge(ws,f"{get_column_letter(NI+1)}{hr}:{last}{hr}","スケジュール",S.F(9,True,S.WHITE),S.C,S.HEADER)
    for j,ml in enumerate(months):
        c=get_column_letter(NI+1+j); ws.column_dimensions[c].width=5.2
        S.cell(ws,f"{c}{hr+1}",ml.split('/')[1]+"月",S.F(8,True,S.WHITE),S.C,S.HEADER)
    ws.row_dimensions[hr].height=18; ws.row_dimensions[hr+1].height=18
    top=hr+2
    def mi(iso):
        p=iso.split("-"); return int(p[0])*12+(int(p[1])-1)
    m0=int("20"+months[0].split('/')[0])*12+(int(months[0].split('/')[1])-1)
    data=tasks if sample else []; n=max(len(data),6)
    for i in range(n):
        r=top+i; ws.row_dimensions[r].height=19
        if i<len(data):
            No,wbs_,name,who,sdt,edt,eff,prog,pre,ph=data[i]; phase=(ph=="P")
            for k,v in enumerate([No,wbs_,name,who,sdt,edt,eff,prog,pre]):
                S.cell(ws,f"{get_column_letter(k+1)}{r}",v,S.F(9,phase),(S.L if k==2 else S.C),S.BAND if phase else (S.WHITE if i%2==0 else S.LIGHT))
            s=mi(sdt)-m0; e=mi(edt)-m0; bar=S.NAVY if phase else S.ACCENT
            for j in range(MN):
                col=get_column_letter(NI+1+j)
                if ph=="M": S.cell(ws,f"{col}{r}","◆" if j==s else None,S.F(10,True,"C00000"),S.C,S.WHITE)
                elif s<=j<=e: S.cell(ws,f"{col}{r}",None,S.F(9),S.C,bar)
                else: S.cell(ws,f"{col}{r}",None,S.F(9),S.C,S.WHITE)
        else:
            for k in range(NI): S.cell(ws,f"{get_column_letter(k+1)}{r}",None,S.F(9),S.C,S.WHITE if i%2==0 else S.LIGHT)
            for j in range(MN): S.cell(ws,f"{get_column_letter(NI+1+j)}{r}",None,S.F(9),S.C,S.WHITE)
    ws.freeze_panes=f"{get_column_letter(NI+1)}{top}"; pagesetup(ws,True); return wb

def _emit_openapi():
    src=os.path.join(ROOT,"api","openapi.yaml")
    if not os.path.exists(src): return
    d=yaml.safe_load(open(src,encoding="utf-8"))
    assert str(d.get("openapi","")).startswith("3."), "openapi版不正"
    paths=d.get("paths")
    assert isinstance(paths,dict) and paths, "paths無し"
    methods={"get","put","post","delete","options","head","patch","trace"}
    schemes=(d.get("components",{}) or {}).get("securitySchemes",{}) or {}
    for path,item in paths.items():
        assert str(path).startswith("/"), f"path形式不正: {path}"
        assert isinstance(item,dict), f"path item不正: {path}"
        for m,op in item.items():
            if m not in methods: continue
            assert isinstance(op,dict), f"operation不正: {path} {m}"
            assert op.get("operationId"), f"operationId無し: {path} {m}"
            res=op.get("responses")
            assert isinstance(res,dict) and res, f"responses無し: {path} {m}"
            for code,body in res.items():
                if isinstance(body,dict) and "$ref" not in body:
                    assert body.get("description") is not None, f"response description無し: {path} {m} {code}"
            for sec in op.get("security",[]) or []:
                for scheme, scopes in (sec or {}).items():
                    if schemes.get(scheme,{}).get("type") == "apiKey":
                        assert scopes in ([], None), f"apiKey securityにscope指定があります: {path} {m} {scheme}"
    strict = False
    try:
        import openapi_spec_validator as _oasv
        (_oasv.validate if hasattr(_oasv, "validate") else _oasv.validate_spec)(d)
        strict = True
    except ImportError:
        pass
    shutil.copy(src,os.path.join(OUT,"api_openapi.yaml"))
    print(f"[openapi] {len(paths)} パスを{'厳密' if strict else '簡易'}検証・コピー")

def cmd_build(args):
    os.makedirs(OUT,exist_ok=True)
    modes=[(f"_{LBL}",True),("_テンプレート",False)] if args.mode=="both" else ([(f"_{LBL}",True)] if args.mode=="sample" else [("_テンプレート",False)])
    for suf,smp in modes: build_trace(smp).save(os.path.join(OUT,f"00_全体トレーサビリティ俯瞰図{suf}.xlsx"))
    for doc in load_docs():
        for suf,smp in modes: build_doc(doc,smp).save(os.path.join(OUT,f"{doc['file']}{suf}.xlsx"))
    for suf,smp in modes: build_wbs(smp).save(os.path.join(OUT,f"00_実装工程管理表(L単位){suf}.xlsx"))
    try:
        import schedule as SCH
        _d=SCH.load_all(None); _rows,_iss,_lv,_ul=SCH.analyze(_d,None); SCH.emit_xlsx(_rows,_iss,_lv)
    except Exception as _e:
        print("[schedule] スキップ:",_e)
    _emit_openapi()
    try:
        import importlib.util
        _s=importlib.util.spec_from_file_location("md_export",os.path.join(os.path.dirname(os.path.abspath(__file__)),"md_export.py"))
        _m=importlib.util.module_from_spec(_s); _s.loader.exec_module(_m); _m.main()
    except Exception as _e:
        print("[md] スキップ:",_e)
    try:
        import importlib.util as _iu
        _s2=_iu.spec_from_file_location("agent_docs",os.path.join(HERE,"agent_docs.py"))
        _m2=_iu.module_from_spec(_s2); _s2.loader.exec_module(_m2); _m2.main()
    except Exception as _e:
        print("[agentdocs] スキップ:",_e)
    print(f"[build] {OUT} に生成しました。")

def cmd_validate(args):
    from validate import run
    sys.exit(0 if run(DOCS) else 1)

def cmd_diagrams(args):
    from diagram_dsl import build_from_yaml
    spec=os.path.join(DOCS,"diagrams.yaml")
    if not os.path.exists(spec):
        print("[diagrams] docs/diagrams.yaml が無いのでスキップ"); return
    imgs=build_from_yaml(spec,OUT)
    # 図面集xlsx
    from openpyxl.drawing.image import Image as XLImage
    for sample,suf in [(True,LBL),(False,"テンプレート")]:
        wb=Workbook(); wb.remove(wb.active)
        for name,pth,src in imgs:
            ws=wb.create_sheet(name[:31]); ws.sheet_view.showGridLines=False
            S.merge(ws,"A1:H1","図面集",S.F(12,True,S.WHITE),S.L,S.NAVY)
            S.merge(ws,"A2:H2",name,S.F(13,True,S.WHITE),S.L,S.BLUE)
            S.merge(ws,"A3:H3","トレース元："+str(src),S.F(9,False,S.GRAY),S.L,S.WHITE,border=False)
            ws.row_dimensions[1].height=20; ws.row_dimensions[2].height=22
            if sample:
                im=XLImage(pth); im.anchor="A5"; ws.add_image(im)
            else:
                S.merge(ws,"A5:H24","［図を差替／diagrams.yamlを編集して再生成］",S.F(11,False,S.GRAY),S.C,S.WHITE)
            pagesetup(ws,True)
        wb.save(os.path.join(OUT,f"00_図面集_{suf}.xlsx"))
    print(f"[diagrams] {len(imgs)} 図を生成しました。")


def _fill_stats():
    """docs各文書の中身充足度: (表セル記入率%, プレースホルダ数TBD/TODO/{{}})。
    coverage の done宣言と突合する(宣言はメタデータ・実態はツールが測る)。"""
    import glob as _g
    out={}
    for fp in sorted(_g.glob(os.path.join(DOCS,"[0-9][0-9]*_*.yaml"))):
        name=os.path.basename(fp)[:-5]
        try: d=yaml.safe_load(open(fp,encoding="utf-8")) or {}
        except Exception: continue
        tot=emp=ph=0
        for ch in d.get("chapters",[]):
            tbd_ok=("TBD" in ch.get("title","")) or ("未確定" in ch.get("title",""))  # TBD管理章は適用除外
            for b in ch.get("blocks",[]):
                if b.get("t")!="table": continue
                for r in b.get("rows",[]) or []:
                    for c in (r if isinstance(r,list) else []):
                        tot+=1; sv=str(c).strip()
                        if not sv: emp+=1
                        elif "{{PRODUCT}}" in sv: ph+=1          # init置換漏れのみ(i18nの{{var}}は正当)
                        elif sv in ("TBD","TODO") and not tbd_ok: ph+=1
        from util import nfc as _nfc
        out[_nfc(name)]=(round((tot-emp)/tot*100) if tot else 100, ph, tot)
    return out

FILL_MIN=50   # done文書の記入率下限(見本最低66%より下・意図的空欄のチェックリストを誤検出しない)

def cmd_coverage(args):
    os.makedirs(OUT,exist_ok=True)
    cat=load("catalog.yaml")
    cats={c["id"]:c["name"] for c in cat["categories"]}
    items=cat["items"]
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title="カバレッジ"; ws.sheet_view.showGridLines=False
    S.widths(ws,{"A":3,"B":20,"C":30,"D":12,"E":10,"F":24,"G":24,"H":10})
    fills=_fill_stats(); lowfill=[]
    done=sum(1 for i in items if i["status"]=="done")
    todo=sum(1 for i in items if i["status"]=="todo")
    na=sum(1 for i in items if i["status"]=="na")
    cov=round(done/max(done+todo,1)*100,1)
    S.merge(ws,"B2:F2","設計書カバレッジ",S.F(16,True,S.WHITE),S.L,S.NAVY); ws.row_dimensions[2].height=28
    dcnt={}
    for i in items: dcnt[i.get("detail","標準")]=dcnt.get(i.get("detail","標準"),0)+1
    S.merge(ws,"B3:G3",f"総合カバレッジ {cov}%（作成済 {done} / 未作成 {todo} / 対象外 {na} / 合計 {len(items)}）　粒度: 詳細{dcnt.get('詳細',0)}/標準{dcnt.get('標準',0)}/簡易{dcnt.get('簡易',0)}",S.F(11,True,S.BLUE),S.L,S.WHITE,border=False)
    ws.row_dimensions[3].height=22
    r=5
    for hdr,c in [("カテゴリ","B"),("成果物","C"),("状態","D"),("粒度","E"),("参照ファイル","F"),("備考","G"),("記入率","H")]:
        S.cell(ws,f"{c}{r}",hdr,S.F(10,True,S.WHITE),S.C,S.HEADER)
    ws.row_dimensions[r].height=20; r+=1
    order=[c["id"] for c in cat["categories"]]
    STAT={"done":("○ 作成済","E2EFDA"),"todo":("△ 未作成","FFF3D6"),"na":("− 対象外","F2F2F2")}
    for cid in order:
        cit=[i for i in items if i["category"]==cid]
        if not cit: continue
        d=sum(1 for i in cit if i["status"]=="done"); t=sum(1 for i in cit if i["status"]=="todo")
        ccov=round(d/max(d+t,1)*100)
        S.merge(ws,f"B{r}:H{r}",f"■ {cats[cid]}　（{ccov}%）",S.F(10,True,S.NAVY),S.L,S.BAND); ws.row_dimensions[r].height=20; r+=1
        LVC={"詳細":"D9E1F2","標準":"FFFFFF","簡易":"F2F2F2"}
        for i in cit:
            lbl,fill=STAT[i["status"]]
            S.cell(ws,f"B{r}","",S.F(9),S.L,S.WHITE)
            S.cell(ws,f"C{r}",i["name"],S.F(9),S.L,S.WHITE)
            S.cell(ws,f"D{r}",lbl,S.F(9,True),S.C,fill)
            dv=i.get("detail","標準")
            S.cell(ws,f"E{r}",dv,S.F(9),S.C,LVC.get(dv,"FFFFFF"))
            S.cell(ws,f"F{r}",i.get("file",""),S.F(9),S.L,S.WHITE)
            S.cell(ws,f"G{r}",i.get("note",""),S.F(9),S.LT,S.WHITE)
            from util import nfc as _nfc
            fr,fph,_ft=fills.get(_nfc(i.get("file","")),(None,0,0))
            if i["status"]=="done" and fr is not None:
                bad = fr<FILL_MIN or fph>0
                S.cell(ws,f"H{r}",f"{fr}%"+(f" PH{fph}" if fph else ""),S.F(9,bad),S.C,
                       ("FFC7CE" if bad else ("FFF3D6" if fr<80 else "E2EFDA")))
                if bad: lowfill.append((i.get("file",""), fr, fph))
            else:
                S.cell(ws,f"H{r}","−",S.F(9,False,S.GRAY),S.C,S.WHITE)
            ws.row_dimensions[r].height=18; r+=1
    pagesetup(ws,False)
    wb.save(os.path.join(OUT,f"00_ドキュメントカバレッジ_{LBL}.xlsx"))
    # 整合チェック(コンソール)
    miss=[]
    for i in items:
        if i["status"]=="done" and i.get("file","").endswith("設計書") or (i["status"]=="done" and i.get("file","") and i["file"][0].isdigit()):
            p=os.path.join(DOCS, i["file"]+".yaml")
            if not os.path.exists(p): miss.append(i["file"])
    # 粒度(濃淡)と実態の乖離: 52章の目安(詳細>=28行/簡易<=12行)との突合。情報表示のみ(判断は52に従い人が行う)
    import glob as _g
    _rows={}
    for _fp in _g.glob(os.path.join(DOCS,"[0-9][0-9]*_*.yaml")):
        try:
            _d=yaml.safe_load(open(_fp,encoding="utf-8")) or {}
            _rows[os.path.basename(_fp)[:-5]]=sum(len(b.get("rows",[]) or []) for ch in _d.get("chapters",[]) for b in ch.get("blocks",[]))
        except Exception: pass
    _mis=[]
    for i in items:
        if i["status"]!="done": continue
        _r=_rows.get(i.get("file",""))
        if _r is None: continue
        if i.get("detail")=="詳細" and _r<20: _mis.append((i["file"],"詳細宣言だが薄い",_r))
        if i.get("detail")=="簡易" and _r>40: _mis.append((i["file"],"簡易宣言だが厚い",_r))
    lowfill=sorted(set(lowfill))
    print(f"[coverage] 総合 {cov}%（作成済{done}/未作成{todo}/対象外{na}）"
          f" / 中身充足: done文書のうち記入率{FILL_MIN}%未満またはプレースホルダ残={len(lowfill)}"
          f" → build/00_ドキュメントカバレッジ_{LBL}.xlsx")
    for f,fr,fph in lowfill:
        print(f"   ✗ [done宣言と実態乖離] {f}: 記入率{fr}%"+(f" / TBD・TODO・プレースホルダ {fph}件" if fph else "")
              +"（記入するか status を todo に戻す）")
    for f,why,r in sorted(set(_mis)):
        print(f"   △ [粒度乖離(情報)] {f}: {why}({r}行) — 52章の目安に照らし detail か中身を見直す")
    if getattr(args,"strict",False) and lowfill: sys.exit(1)
    if miss: print("  ! done指定だがdocs未検出:", sorted(set(miss)))




def _is_scrum_mode():
    """docs の実体からスクラム文書層の有無を判定する（番号非依存）。"""
    import glob as _g
    return bool(_g.glob(os.path.join(DOCS, "*_プロダクトバックログ.yaml")))


def _find_ids(value):
    """任意のYAMLノードからIDを再帰抽出する。activation/impact系の共通入口。"""
    return IU.scan_ids(value)


def _id_prefix(idv):
    return IU.contract_token(idv)

def _extract_ids():
    import glob
    files=sorted(glob.glob(os.path.join(DOCS,"[0-9][0-9]*_*.yaml")))
    try:
        import scope as _scope; files=_scope.filter_files(files)   # スコープ活性時のみ絞り込み
    except Exception: pass
    return IU.extract_from_files(files)

_PHASE={ "01":0,"02":0,"43":0,"03":1,"04":2,"22":2,"25":2,"26":2,"27":2,"42":2,
  "05":3,"16":3,"17":3,"23":3,"24":3,"31":3,"32":3,"39":3,"41":3,
  "06":4,"07":4,"08":4,"09":4,"12":4,"28":4,"29":4,
  "10":5,"11":5,"20":5,"21":5,"34":5,"35":5,"36":5,"38":5,
  # 検証・診断系の割付: 53=PoC/プロト(L2で要求を引き出す道具) / 51・102・109・49=検証設計の
  # シフトレフト(L5で整備。実行はV字対の上昇側: 51→L9-L10, 102→L10, 109のGo/No-Go→L11-L12間) /
  # 108=完全化保守(L12群)。実行タイミングの正本は107のレベル定義。
  "53":0,"51":4,"102":4,"109":4,"49":4,"108":5 }
def _render_dep_graph(docs, dep, focus, path):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
    import matplotlib.font_manager as fm, os as _os
    fp=None
    for c in ["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"]:
        if _os.path.exists(c): fp=c
    JF=fm.FontProperties(fname=fp) if fp else fm.FontProperties()
    num=lambda n:n.split("_")[0]
    if focus:
        outs=sorted(dep.get(focus,{}).items(), key=lambda x:-x[1])
        ins=sorted([(a,dep[a][focus]) for a in docs if focus in dep.get(a,{})], key=lambda x:-x[1])
        H=max(len(outs),len(ins),1)*0.8+2
        fig,ax=plt.subplots(figsize=(11,H),dpi=140); ax.axis("off")
        ax.set_xlim(0,10); ax.set_ylim(0,H)
        cy=H/2
        def box(x,y,text,fc):
            ax.add_patch(FancyBboxPatch((x-1.5,y-0.35),3.0,0.7,boxstyle="round,pad=0.02,rounding_size=0.1",fc=fc,ec="#1F3864",lw=1.4))
            ax.text(x,y,text,ha="center",va="center",fontproperties=JF,fontsize=8.5,color="#1F3864")
        box(5,cy,focus,"#FFF3D6")
        for i,(b,c) in enumerate(outs):
            y=cy+ (len(outs)-1)/2*0.9 - i*0.9
            box(8.4,y,b,"#D9E1F2")
            ax.add_patch(FancyArrowPatch((6.5,cy),(6.9,y),arrowstyle="-|>",mutation_scale=12,color="#555",lw=1.2))
            ax.text(7.0,(cy+y)/2+0.12,str(c),ha="center",fontproperties=JF,fontsize=7,color="#888")
        for i,(a,c) in enumerate(ins):
            y=cy+ (len(ins)-1)/2*0.9 - i*0.9
            box(1.6,y,a,"#E2EFDA")
            ax.add_patch(FancyArrowPatch((3.1,y),(3.5,cy),arrowstyle="-|>",mutation_scale=12,color="#548235",lw=1.2))
        ax.text(8.4,cy+ (len(outs)/2)*0.9+0.6,"◀ この設計が依存する先",ha="center",fontproperties=JF,fontsize=9,color="#1F3864")
        ax.text(1.6,cy+ (len(ins)/2)*0.9+0.6,"この設計に依存する元 ▶",ha="center",fontproperties=JF,fontsize=9,color="#548235")
        ax.set_title(f"設計間 依存グラフ（focus: {focus}）",fontproperties=JF,fontsize=13,color="#1F3864",loc="left")
    else:
        # 全体: フェーズ列でレイアウト
        cols={}
        for n in docs: cols.setdefault(_PHASE.get(num(n),6),[]).append(n)
        ncol=7; fig,ax=plt.subplots(figsize=(13,8),dpi=130); ax.axis("off")
        maxrow=max(len(v) for v in cols.values()); ax.set_xlim(0,ncol); ax.set_ylim(0,maxrow+1)
        pos={}
        labels=["要求","要件","基本/基盤","詳細","テスト/検証","品質/運用","標準/管理"]
        for cx in range(ncol):
            ax.text(cx+0.5,maxrow+0.6,labels[cx],ha="center",fontproperties=JF,fontsize=9,color="#888")
            items=cols.get(cx,[])
            for i,n in enumerate(items):
                y=maxrow-0.5-i*(maxrow/max(len(items),1)); pos[n]=(cx+0.5,y)
                ax.add_patch(FancyBboxPatch((cx+0.5-0.34,y-0.16),0.68,0.32,boxstyle="round,pad=0.01,rounding_size=0.05",fc="#D9E1F2",ec="#1F3864",lw=0.9))
                ax.text(cx+0.5,y,num(n),ha="center",va="center",fontproperties=JF,fontsize=7,color="#1F3864")
        for a in docs:
            for b in dep.get(a,{}):
                if a in pos and b in pos:
                    ax.add_patch(FancyArrowPatch(pos[a],pos[b],arrowstyle="-|>",mutation_scale=7,color="#B0B8C8",lw=0.6,connectionstyle="arc3,rad=0.1"))
        ax.set_title("設計間 依存グラフ（全体・矢印=参照元→定義元）",fontproperties=JF,fontsize=13,color="#1F3864",loc="left")
    plt.tight_layout(); fig.savefig(path,dpi=140,bbox_inches="tight"); plt.close(fig)

def cmd_deps(args):
    docs, defmap, defall, refs, dep = _extract_ids()
    os.makedirs(OUT,exist_ok=True)
    from openpyxl import Workbook
    focus=getattr(args,"focus",None)
    if focus:
        # 番号指定を実名へ
        match=[d for d in docs if d.split("_")[0]==focus or d==focus]
        if not match: print(f"[deps] focus '{focus}' が見つかりません"); return
        fdoc=match[0]; ddir=os.path.join(OUT,"図面"); os.makedirs(ddir,exist_ok=True)
        p=os.path.join(ddir,f"依存グラフ_focus_{fdoc.split('_')[0]}.png")
        _render_dep_graph(docs, dep, fdoc, p)
        print(f"[deps] focus {fdoc}: 依存先 {len(dep.get(fdoc,{}))} / 依存元 {sum(1 for a in docs if fdoc in dep.get(a,{}))} → {os.path.relpath(p,ROOT)}")
        return
    if getattr(args,"graph",False):
        ddir=os.path.join(OUT,"図面"); os.makedirs(ddir,exist_ok=True)
        p=os.path.join(ddir,"設計間依存グラフ.png"); _render_dep_graph(docs, dep, None, p)
        print(f"[deps] 全体グラフ → {os.path.relpath(p,ROOT)}")
    # マトリクス+一覧(既存)
    wb=Workbook(); ws=wb.active; ws.title="依存マトリクス"; ws.sheet_view.showGridLines=False
    n=len(docs); nums=[d.split("_")[0] for d in docs]
    S.merge(ws,f"A1:{get_column_letter(n+2)}1","設計間 依存マトリクス（行=参照元 → 列=定義元、数値=共有ID数）",S.F(14,True,S.WHITE),S.L,S.NAVY); ws.row_dimensions[1].height=24
    S.cell(ws,"A3","No",S.F(9,True,S.WHITE),S.C,S.HEADER); S.cell(ws,"B3","設計書 ＼ 依存先→",S.F(9,True,S.WHITE),S.L,S.HEADER)
    for j,x in enumerate(nums):
        c=get_column_letter(3+j); ws.column_dimensions[c].width=3.6; S.cell(ws,f"{c}3",x,S.F(8,True,S.WHITE),S.C,S.HEADER)
    ws.column_dimensions["A"].width=5; ws.column_dimensions["B"].width=34
    for i,a in enumerate(docs):
        r=4+i; S.cell(ws,f"A{r}",nums[i],S.F(8),S.C,S.WHITE); S.cell(ws,f"B{r}",a,S.F(8),S.L,S.WHITE if i%2==0 else S.LIGHT)
        for j,b in enumerate(docs):
            c=get_column_letter(3+j); v=dep[a].get(b,0)
            if i==j: S.cell(ws,f"{c}{r}","-",S.F(8,False,S.GRAY),S.C,"E9EDF7")
            elif v: S.cell(ws,f"{c}{r}",v,S.F(8,True,"1F3864"),S.C,"D9E1F2")
            else: S.cell(ws,f"{c}{r}",None,S.F(8),S.C,S.WHITE)
        ws.row_dimensions[r].height=15
    ws.freeze_panes="C4"; pagesetup(ws,True)
    ws2=wb.create_sheet("依存一覧"); ws2.sheet_view.showGridLines=False
    S.widths(ws2,{"A":3,"B":34,"C":34,"D":10,"E":30})
    S.merge(ws2,"B2:E2","設計間 依存一覧（参照元 → 依存先）",S.F(14,True,S.WHITE),S.L,S.NAVY); ws2.row_dimensions[2].height=24
    for j,h in enumerate(["参照元(設計書)","依存先(定義元)","共有ID数","主なID"]):
        S.cell(ws2,f"{get_column_letter(2+j)}4",h,S.F(10,True,S.WHITE),S.C,S.HEADER)
    r=5
    for a in docs:
        for b,c in sorted(dep[a].items(), key=lambda x:-x[1]):
            ids=sorted([rid for rid in refs[a] if defmap.get(rid)==b])[:6]
            S.cell(ws2,f"B{r}",a,S.F(9),S.L,S.WHITE); S.cell(ws2,f"C{r}",b,S.F(9),S.L,S.WHITE)
            S.cell(ws2,f"D{r}",c,S.F(9),S.C,S.WHITE); S.cell(ws2,f"E{r}",", ".join(ids),S.F(9),S.LT,S.WHITE); ws2.row_dimensions[r].height=16; r+=1
    pagesetup(ws2,False)
    wb.save(os.path.join(OUT,f"00_設計間依存関係_{LBL}.xlsx"))
    edges=sum(len(v) for v in dep.values())
    print(f"[deps] 依存エッジ {edges} 件 → build/00_設計間依存関係_{LBL}.xlsx")

def cmd_check(args):
    docs, defmap, defall, refs, dep = _extract_ids()
    issues=[]
    # 0) 文書番号プレフィクスの重複(情報): 番号でファイルを引くツール(agentdocs/impact --doc)が曖昧になる
    _bynum={}
    for a in docs: _bynum.setdefault(a.split("_")[0], []).append(a)
    for _n, _fs in sorted(_bynum.items()):
        if len(_fs) > 1:
            print(f"   △ [番号重複(情報)] {_n}_ が {len(_fs)} 文書: {', '.join(_fs)} — 片方を未使用番号へリネーム推奨(番号解決が曖昧になります)")
    try:
        import scope as _scope; EXT=_scope.external_ids()   # 対象外書面のIDは参照許容
    except Exception: EXT=set()
    # 1) 参照切れ(未定義参照)
    # Vモデルでは、テストIDや外部ユーザーストーリーIDを定義表無しで許容する運用を残す。
    # スクラムではGoal/Epic/Story/AC/Sprint/Increment/Releaseを定義対象として厳格に見る。
    ALLOW = ("UT-", "IT-", "ST-", "AT-") if _is_scrum_mode() else ("UT-", "IT-", "ST-", "AT-", "US-")
    for a in docs:
        for rid in sorted(refs[a]):
            if rid not in defmap and rid not in EXT and not rid.startswith(ALLOW):
                issues.append(("参照切れ", a, f"{rid} が未定義"))
    # 2) 重複定義ID
    for rid,who in sorted(defall.items()):
        if len(who)>1: issues.append(("重複定義", " / ".join(sorted(who)), f"{rid} が複数で定義"))
    # 3) 孤立(定義されたが未参照)
    allref=set().union(*refs.values()) if refs else set()
    for rid,who in sorted(defmap.items()):
        if rid not in allref: issues.append(("孤立(未参照)", who, f"{rid} がどこからも参照されない"))
    # 4) 循環依存(DFS)
    color={a:0 for a in docs}; cyc=[]
    def dfs(u,stack):
        color[u]=1
        for v in dep.get(u,{}):
            if color.get(v,0)==1:
                if v in stack:
                    i=stack.index(v); cyc.append(stack[i:]+[v])
            elif color.get(v,0)==0: dfs(v,stack+[v])
        color[u]=2
    if not _is_scrum_mode():
        for a in docs:
            if color[a]==0: dfs(a,[a])
        for c in cyc: issues.append(("循環依存", " → ".join(x.split("_")[0] for x in c), "依存が循環"))
    # 5) 表の列定義と行の列数不一致（黙って捨てられるセルを検出）
    import glob as _glob
    _wf=sorted(_glob.glob(os.path.join(DOCS,"[0-9][0-9]*_*.yaml")))
    try:
        import scope as _scope; _wf=_scope.filter_files(_wf)
    except Exception: pass
    for fp in _wf:
        dd=yaml.safe_load(open(fp,encoding="utf-8")) or {}
        nm=os.path.basename(fp)[:-5]
        for ch in dd.get("chapters",[]):
            for blk in ch.get("blocks",[]):
                if blk.get("t")=="table":
                    nc=len(blk.get("cols",[]))
                    for row in blk.get("rows",[]):
                        if nc and len(row)!=nc:
                            issues.append(("列数不一致", f"{nm.split('_')[0]} / {ch.get('title','')}",
                                           f"列定義{nc} ≠ 行{len(row)}: {row}"))
    # 出力
    os.makedirs(OUT,exist_ok=True)
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title="整合性チェック"; ws.sheet_view.showGridLines=False
    S.widths(ws,{"A":3,"B":18,"C":40,"D":40})
    S.merge(ws,"B2:D2","整合性チェック（構造的な矛盾の自動検出）",S.F(14,True,S.WHITE),S.L,S.NAVY); ws.row_dimensions[2].height=24
    S.merge(ws,"B3:D3",f"検出 {len(issues)} 件（種別: 参照切れ/重複定義/孤立/循環依存/列数不一致）",S.F(10,True,S.BLUE),S.L,S.WHITE,border=False)
    for j,h in enumerate(["種別","対象(設計書)","内容"]):
        S.cell(ws,f"{get_column_letter(2+j)}5",h,S.F(10,True,S.WHITE),S.C,S.HEADER)
    COL={"参照切れ":"F2DCDB","重複定義":"FFF3D6","孤立(未参照)":"E9EDF7","循環依存":"F2DCDB","列数不一致":"FFF3D6"}
    r=6
    for kind,tgt,msg in issues:
        S.cell(ws,f"B{r}",kind,S.F(9,True),S.C,COL.get(kind,"FFFFFF"))
        S.cell(ws,f"C{r}",tgt,S.F(9),S.LT,S.WHITE); S.cell(ws,f"D{r}",msg,S.F(9),S.LT,S.WHITE); ws.row_dimensions[r].height=16; r+=1
    if not issues:
        S.merge(ws,"B6:D6","✓ 構造的な矛盾は検出されませんでした。",S.F(11,True,"548235"),S.L,"E2EFDA"); 
    pagesetup(ws,False)
    wb.save(os.path.join(OUT,f"00_整合性チェック_{LBL}.xlsx"))
    bykind={}
    for k,_,_ in issues: bykind[k]=bykind.get(k,0)+1
    print(f"[check] 検出 {len(issues)} 件: "+(", ".join(f"{k}={v}" for k,v in bykind.items()) if issues else "なし(構造的矛盾なし)")+f" → build/00_整合性チェック_{LBL}.xlsx")
    if issues: sys.exit(1)


def cmd_profile(args):
    cat=load("catalog.yaml")
    pfpath=os.path.join(DOCS,"profiles.yaml")
    if not os.path.exists(pfpath):
        print("[profile] docs/profiles.yaml がありません。templates/profiles.yaml を docs/ にコピーするか、"
              "`init` で雛形を再生成してください。"); return
    profs=load("profiles.yaml").get("profiles",{})
    name=args.name
    if name not in profs:
        print("[profile] 利用可能:", ", ".join(profs.keys())); return
    pf=profs[name]; adopt=pf.get("adopt",{}); dstat=pf.get("default_status","keep")
    ddet=pf.get("default_detail",None); dover=pf.get("detail_override",{})
    cats={c["id"]:c["name"] for c in cat["categories"]}
    order=[c["id"] for c in cat["categories"]]
    items=[]
    for it in cat["items"]:
        e=dict(it); iid=it["id"]
        if iid in adopt:
            if it["status"]=="na": e["status"]="todo"
            e["detail"]=adopt[iid]
        else:
            if dstat=="na": e["status"]="na"
            elif dstat=="done": e["status"]="done" if it["status"]!="na" else "na"
            if iid in dover: e["detail"]=dover[iid]
            elif ddet and it["status"]!="na": e["detail"]=ddet
            elif dstat=="done" and iid in dover: e["detail"]=dover[iid]
        items.append(e)
    done=sum(1 for i in items if i["status"]=="done"); todo=sum(1 for i in items if i["status"]=="todo"); na=sum(1 for i in items if i["status"]=="na")
    cov=round(done/max(done+todo,1)*100,1)
    os.makedirs(OUT,exist_ok=True)
    from openpyxl import Workbook
    wb=Workbook(); ws=wb.active; ws.title="カバレッジ"; ws.sheet_view.showGridLines=False
    S.widths(ws,{"A":3,"B":20,"C":30,"D":12,"E":10,"F":24,"G":24,"H":10})
    fills=_fill_stats(); lowfill=[]
    S.merge(ws,"B2:G2",f"設計書カバレッジ（プロファイル: {name}）",S.F(16,True,S.WHITE),S.L,S.NAVY); ws.row_dimensions[2].height=26
    dcnt={}
    for i in items:
        if i["status"]!="na": dcnt[i.get("detail","標準")]=dcnt.get(i.get("detail","標準"),0)+1
    S.merge(ws,"B3:G3",f"{pf.get('description','')}  ／ カバレッジ {cov}%（作成済{done}/未作成{todo}/対象外{na}）粒度 詳細{dcnt.get('詳細',0)}/標準{dcnt.get('標準',0)}/簡易{dcnt.get('簡易',0)}",S.F(10,True,S.BLUE),S.L,S.WHITE,border=False); ws.row_dimensions[3].height=20
    r=5
    for h,c in [("カテゴリ","B"),("成果物","C"),("状態","D"),("粒度","E"),("参照ファイル","F"),("備考","G")]:
        S.cell(ws,f"{c}{r}",h,S.F(10,True,S.WHITE),S.C,S.HEADER)
    ws.row_dimensions[r].height=20; r+=1
    STAT={"done":("○ 作成済","E2EFDA"),"todo":("△ 未作成","FFF3D6"),"na":("− 対象外","F2F2F2")}
    LVC={"詳細":"D9E1F2","標準":"FFFFFF","簡易":"F2F2F2"}
    for cid in order:
        cit=[i for i in items if i["category"]==cid]
        if not cit: continue
        d=sum(1 for i in cit if i["status"]=="done"); t=sum(1 for i in cit if i["status"]=="todo")
        ccov=round(d/max(d+t,1)*100) if (d+t) else 0
        S.merge(ws,f"B{r}:H{r}",f"■ {cats[cid]}　（{ccov}%）",S.F(10,True,S.NAVY),S.L,S.BAND); ws.row_dimensions[r].height=20; r+=1
        for i in cit:
            lbl,fl=STAT[i["status"]]; dv=i.get("detail","標準")
            S.cell(ws,f"B{r}","",S.F(9),S.L,S.WHITE); S.cell(ws,f"C{r}",i["name"],S.F(9),S.L,S.WHITE)
            S.cell(ws,f"D{r}",lbl,S.F(9,True),S.C,fl)
            S.cell(ws,f"E{r}",(dv if i["status"]!="na" else "-"),S.F(9),S.C,LVC.get(dv,"FFFFFF") if i["status"]!="na" else "F2F2F2")
            S.cell(ws,f"F{r}",i.get("file",""),S.F(9),S.L,S.WHITE); S.cell(ws,f"G{r}",i.get("note",""),S.F(9),S.LT,S.WHITE)
            ws.row_dimensions[r].height=18; r+=1
    pagesetup(ws,False)
    out=os.path.join(OUT,f"00_カバレッジ_{name}_{LBL}.xlsx"); wb.save(out)
    print(f"[profile] {name}: カバレッジ {cov}%（作成済{done}/未作成{todo}/対象外{na}）→ {os.path.relpath(out,ROOT)}")

def cmd_schedule(args):
    import schedule as SCH
    live = getattr(args,"live",None)
    data = SCH.load_all(live)
    rows, issues, islive, uses = SCH.analyze(data, live)
    code = SCH.report(rows, issues, islive, uses)
    SCH.emit_xlsx(rows, issues, islive)
    sys.exit(code)

def cmd_sheets(args):
    from export_sheets import push
    push(OUT,args.credentials,args.folder)

def cmd_init(args):
    name=args.name
    if os.path.exists(DOCS) and os.listdir(DOCS) and not args.force:
        print("docs/ が空ではありません。--force で上書きします。"); sys.exit(1)
    # --force 時: 既存 docs/ を退避してから空スケルトンで作り直す。
    # （templates に対応物が無い文書のサンプルが docs に残留し、
    #   新規案件に旧案件のIDが混入して validate/CI が赤になる事故を防ぐ）
    if os.path.exists(DOCS) and os.listdir(DOCS):
        import shutil, datetime
        bak = DOCS + ".bak-" + datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        shutil.move(DOCS, bak)
        print(f"[init] 既存の docs/ を {os.path.basename(bak)}/ へ退避しました（不要なら削除してください）。")
    os.makedirs(DOCS,exist_ok=True)
    # templates/ を docs/ へコピーし {{PRODUCT}} を置換
    for dp,dirs,fs in os.walk(os.path.join(TPL)):
        rel=os.path.relpath(dp,TPL); dst=os.path.join(DOCS,rel) if rel!="." else DOCS
        os.makedirs(dst,exist_ok=True)
        for f in fs:
            src=os.path.join(dp,f); txt=open(src,encoding="utf-8").read().replace("{{PRODUCT}}",name)
            open(os.path.join(dst,f),"w",encoding="utf-8").write(txt)
    print(f"[init] '{name}' の雛形を docs/ に生成しました。docs/*.yaml を編集して build してください。")

def cmd_activation(args):
    import subprocess
    cmd=[sys.executable, os.path.join(HERE,"activation.py")]
    if getattr(args,"map",False): cmd.append("--map")
    if getattr(args,"doc",None): cmd += ["--doc", args.doc]
    sys.exit(subprocess.run(cmd).returncode)

def cmd_detect(args):
    """案件(profile)×書面選択からスコープを解決し、各検出器を条件分岐で実行する。"""
    import subprocess
    sys.path.insert(0, HERE)
    import scope as SCOPE
    only=[x for x in args.only.split(",") if x] if args.only else None
    exclude=[x for x in args.exclude.split(",") if x] if args.exclude else None
    caps=[x for x in args.caps.split(",") if x] if getattr(args,"caps",None) else None
    sc=SCOPE.resolve(args.profile, only, exclude, caps)
    path=SCOPE.write_active(sc)
    print("="*56)
    SCOPE.describe(sc)
    print("="*56)
    # 検証工程(06-09)が対象内か＝テスト系検出の活性/抑制を表示
    vfiles=["06_単体テスト設計書","07_結合テスト設計書","08_総合テスト設計書","09_受入テスト設計書"]
    vin=[v.split("_")[0] for v in vfiles if v in sc["in_files"]]
    vout=[v.split("_")[0] for v in vfiles if v in sc["out_files"]]
    if vout:
        print(f"  検証工程: 対象内={','.join(vin) or 'なし'} / 対象外={','.join(vout)}"
              f" → 対象外のテスト欠落・V字対欠落は指摘しない")
    env=dict(os.environ, VMODEL_SCOPE=path)
    # 活性化サマリ（対象スコープ内で、型網に接続済みの書面を提示）
    from util import run_tool
    _act=run_tool([sys.executable,os.path.join(HERE,"activation.py")],env=env,timeout=120)
    _al=[l for l in (_act.stdout or "").splitlines() if l.startswith("[activation]")]
    if _al: print("  " + _al[0].replace("[activation] ",""))
    checks=[("schema","schema_check.py",[sys.executable,os.path.join(HERE,"schema_check.py")]),
            ("check","build.py check",[sys.executable,os.path.join(HERE,"build.py"),"check"]),
            ("validate","build.py validate",[sys.executable,os.path.join(HERE,"build.py"),"validate"]),
            ("mesh","spec_check.py",[sys.executable,os.path.join(HERE,"spec_check.py")]),
            ("types","spec_types.py",[sys.executable,os.path.join(HERE,"spec_types.py")]),
            ("trace","spec_trace.py",[sys.executable,os.path.join(HERE,"spec_trace.py")]),
            ("agent","agent_meta.py --check",[sys.executable,os.path.join(HERE,"agent_meta.py"),"--check"]),
            ("signals","assign.py --check",[sys.executable,os.path.join(HERE,"assign.py"),"--check"]),
            ("terms","consistency.py",[sys.executable,os.path.join(HERE,"consistency.py")]),
            ("fill","coverage --strict",[sys.executable,os.path.join(HERE,"build.py"),"coverage","--strict"]),
            ("schedule","schedule.py",[sys.executable,os.path.join(HERE,"schedule.py")])]
    print("  ── 検出（対象スコープで実行） ──")
    worst=0
    for tag,label,cmd in checks:
        from util import run_tool
        try:
            r=run_tool(cmd,env=env,timeout=120)
            rc=r.returncode
            tail=[l for l in (r.stdout or "").splitlines() if l.strip()]
            last=tail[-1] if tail else ""
        except Exception as e:
            rc=1; last=f"timeout/error: {e}"
        mark="✓" if rc==0 else "✗"
        worst=max(worst,rc)
        print(f"   {mark} {tag:<9} {last.strip()[:90]}")
    print("="*56)
    print(f"[detect] スコープ検出 完了（profile={sc['profile'] or '全書面'} / 対象書面 {len(sc['in_files'])}）"
          + ("  ✗ 対象内に指摘あり" if worst else "  ✓ 対象内は矛盾なし"))
    try: os.remove(path)
    except OSError: pass
    sys.exit(worst)

def main():
    p=argparse.ArgumentParser(prog="build.py"); sub=p.add_subparsers(dest="cmd",required=True)
    i=sub.add_parser("init"); i.add_argument("name"); i.add_argument("--force",action="store_true"); i.set_defaults(func=cmd_init)
    b=sub.add_parser("build"); b.add_argument("--mode",choices=["both","sample","blank"],default="both"); b.set_defaults(func=cmd_build)
    v=sub.add_parser("validate"); v.set_defaults(func=cmd_validate)
    d=sub.add_parser("diagrams"); d.set_defaults(func=cmd_diagrams)
    cv=sub.add_parser("coverage"); cv.add_argument("--strict",action="store_true"); cv.set_defaults(func=cmd_coverage)
    dp=sub.add_parser("deps"); dp.add_argument("--graph",action="store_true"); dp.add_argument("--focus",default=None); dp.set_defaults(func=cmd_deps)
    ck=sub.add_parser("check"); ck.set_defaults(func=cmd_check)
    sc=sub.add_parser("schedule"); sc.add_argument("--live",nargs="?",const="",default=None); sc.set_defaults(func=cmd_schedule)
    pr=sub.add_parser("profile"); pr.add_argument("name"); pr.set_defaults(func=cmd_profile)
    s=sub.add_parser("sheets"); s.add_argument("--credentials",default="service_account.json"); s.add_argument("--folder",default=None); s.set_defaults(func=cmd_sheets)
    dt=sub.add_parser("detect"); dt.add_argument("--profile",default=None); dt.add_argument("--only",default=None); dt.add_argument("--exclude",default=None); dt.add_argument("--caps",default=None); dt.set_defaults(func=cmd_detect)
    def _delegate(module, fn):
        """tools/<module>.py の関数へ委譲する退屈なラッパ(ラムダ+__import__の賢さを排除)。"""
        def run(a):
            from util import load_tool
            sys.exit(fn(load_tool(module), a))
        return run
    im=sub.add_parser("impact"); img=im.add_mutually_exclusive_group(required=True); img.add_argument("--id"); img.add_argument("--doc"); im.set_defaults(func=_delegate("impact", lambda m,a: m.impact_id(a.id) if a.id else m.impact_doc(a.doc)))
    df=sub.add_parser("diff"); df.add_argument("--base",required=True); df.set_defaults(func=_delegate("diff_report", lambda m,a: m.main("diff",a.base)))
    nt=sub.add_parser("notes"); nt.add_argument("--base",required=True); nt.set_defaults(func=_delegate("diff_report", lambda m,a: m.main("notes",a.base)))
    ad=sub.add_parser("agentdocs"); ad.set_defaults(func=_delegate("agent_docs", lambda m,a: m.main()))
    rv=sub.add_parser("review"); rv.add_argument("--n",type=int,default=5); rv.add_argument("--seed",type=int,default=None); rv.add_argument("--status",action="store_true"); rv.set_defaults(func=_delegate("review", lambda m,a: m.cmd_status() if a.status else m.cmd_review(a.n,a.seed)))
    asg=sub.add_parser("assign"); asg.set_defaults(func=_delegate("assign", lambda m,a: m.cmd_assign()))
    sg=sub.add_parser("signals"); sg.set_defaults(func=_delegate("assign", lambda m,a: m.cmd_signals()))
    ac=sub.add_parser("activation"); ac.add_argument("--map",action="store_true"); ac.add_argument("--doc",default=None); ac.set_defaults(func=cmd_activation)
    a=p.parse_args(); a.func(a)

if __name__=="__main__": main()
