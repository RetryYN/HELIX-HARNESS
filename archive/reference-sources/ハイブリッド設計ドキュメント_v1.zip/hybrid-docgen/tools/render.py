# -*- coding: utf-8 -*-
"""YAMLブロック(辞書)を章シートへ描画。template(空白)/sample(記入)を共有。"""
from openpyxl.utils import get_column_letter
import style as S

def render(ws, start_row, ncols, blocks, sample, blank_rows=5):
    last=get_column_letter(ncols); r=start_row
    for blk in blocks:
        t=blk.get("t")
        if t=="sec":
            r=S.section(ws,r,last,blk.get("num",""),blk.get("title",""))
        elif t=="sub":
            S.merge(ws,f"A{r}:{last}{r}",blk.get("text",""),S.F(10,True,S.BLUE),S.L,S.WHITE,border=False)
            ws.row_dimensions[r].height=18; r+=1
        elif t=="para":
            span=int(blk.get("span",3)); text=blk.get("text","") if sample else ""
            S.merge(ws,f"A{r}:{last}{r+span-1}",text,S.F(10),S.LT,S.WHITE)
            for rr in range(r,r+span): ws.row_dimensions[rr].height=18
            r+=span
        elif t=="bullets":
            items=blk.get("items",[]) if sample else [""]*blank_rows
            for it in items:
                S.merge(ws,f"A{r}:{last}{r}",("・ "+it) if it else "",S.F(10),S.LT,S.WHITE)
                ws.row_dimensions[r].height=18; r+=1
        elif t=="kv":
            pairs=blk.get("rows",[]); lw=int(blk.get("label_w",2))
            lc=get_column_letter(lw); vc=get_column_letter(lw+1)
            for label,val in pairs:
                S.merge(ws,f"A{r}:{lc}{r}",label,S.F(10,True),S.L,S.LABEL)
                S.merge(ws,f"{vc}{r}:{last}{r}",val if sample else "",S.F(10),S.LT,S.WHITE)
                ws.row_dimensions[r].height=20; r+=1
        elif t=="table":
            cols=blk.get("cols",[]); rows=blk.get("rows",[]) if sample else []
            minrows=int(blk.get("min",blank_rows))
            r=S.table_header(ws,r,[(c[0],c[1],c[2]) for c in cols])
            n=max(len(rows),minrows)
            for i in range(n):
                rowvals=rows[i] if i<len(rows) else [""]*len(cols)
                for c,v in zip(cols,rowvals):
                    al=S.C if c[0]=="A" else S.LT
                    S.cell(ws,f"{c[0]}{r}",v if v!="" else None,S.F(10),al,S.WHITE if i%2==0 else S.LIGHT)
                ws.row_dimensions[r].height=20; r+=1
        elif t=="note":
            S.merge(ws,f"A{r}:{last}{r}",blk.get("text",""),S.F(9,False,S.GRAY),S.LT,S.WHITE,border=False)
            ws.row_dimensions[r].height=16; r+=1
        elif t=="gap":
            ws.row_dimensions[r].height=6; r+=1
    return r
