# -*- coding: utf-8 -*-
"""fix_names: 解凍時に化けたファイル名と macOS の NFD 名を修復する。

  python tools/fix_names.py            # 検出のみ(dry-run)
  python tools/fix_names.py --apply    # 実際にリネーム

対象:
1. UTF-8バイト列を CP437/CP932 として誤解釈した名前(Windowsの旧解凍ツール由来) → 元のUTF-8へ復元
2. NFD(結合文字)の名前(macOSのファイルシステム由来) → NFC へ正規化
   ※ catalog の file: 値(NFC)と実ファイル名の突合が NFD だと全滅するため
"""
import os, sys, unicodedata
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import util  # 副作用: cp932コンソールでの記号出力ガード

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))


def repair(name):
    """化け名の復元候補を返す(直せなければNone)。"""
    # NFD → NFC
    nfc = unicodedata.normalize("NFC", name)
    if nfc != name:
        return nfc
    # CP437/CP932 誤解釈の往復復元: 誤名.encode(誤コーデック) == 元のUTF-8バイト列
    for enc in ("cp437", "cp932", "latin-1"):
        try:
            b = name.encode(enc)
            u = b.decode("utf-8")
            if u != name and any(ord(c) > 0x3000 for c in u):  # 日本語が現れたら復元成功とみなす
                return unicodedata.normalize("NFC", u)
        except (UnicodeEncodeError, UnicodeDecodeError):
            continue
    return None


def main(apply=False):
    fixes = []
    for dp, dns, fns in os.walk(ROOT, topdown=False):
        for name in list(fns) + list(dns):
            new = repair(name)
            if new and new != name:
                fixes.append((os.path.join(dp, name), os.path.join(dp, new)))
    if not fixes:
        print("[fix_names] 修復対象なし（ファイル名は健全）")
        return 0
    for src, dst in fixes:
        rel_s, rel_d = os.path.relpath(src, ROOT), os.path.relpath(dst, ROOT)
        if apply:
            os.rename(src, dst); print(f"  修復: {rel_s} → {rel_d}")
        else:
            print(f"  候補: {rel_s} → {rel_d}")
    if not apply:
        print(f"[fix_names] {len(fixes)} 件を検出（--apply で実行）")
    else:
        print(f"[fix_names] {len(fixes)} 件を修復しました。続けて python tools/build.py detect を実行してください")
    return 0


if __name__ == "__main__":
    sys.exit(main("--apply" in sys.argv))
