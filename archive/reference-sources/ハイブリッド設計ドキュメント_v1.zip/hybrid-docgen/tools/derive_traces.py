# -*- coding: utf-8 -*-
"""spec.defines のトレース宣言を、既存の“人手トレース”から機械導出して充足する。

正本ソース（いずれも既存・人手記入済み。ここでは新規に関係を創作しない）:
  - docs/traceability.yaml … Vモデル俯瞰図(要求→要件→設計→単体/結合/総合/受入)
  - 各テスト設計docの「トレース元」列（例: UT-004 → 詳細F-004）
  - 04基本設計の一覧表の要件参照列（例: BT-003 → F-007）
  - docs/43台帳 の要求一覧「展開先」列（R-→F-）

導出結果は、その doc の ID宇宙(定義∪参照)に存在するIDだけを採用（宙吊り防止）。
既存の traces_from/traces_to/tests は温存し、和集合でマージする（人手記入を壊さない）。

  python3 tools/derive_traces.py            # ドライラン（差分を表示するだけ）
  python3 tools/derive_traces.py --apply    # docs/*.yaml の spec: ブロックを書き換え
"""
import os, sys, re, glob, argparse
import yaml
import id_utils as IU

HERE = os.path.dirname(os.path.abspath(__file__))
import sys as _sys; _sys.path.insert(0, HERE)
from util import load_tool
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
RANGERE = re.compile(r"([A-Z]+)-0*(\d+)\.\.(?:[A-Z]+-)?0*(\d+)")


def parse_ids(s):
    """文字列からIDを抽出。'F-001..F-006' のような範囲も展開する。"""
    s = str(s)
    out = set()
    for pre, a, b in RANGERE.findall(s):
        for n in range(int(a), int(b) + 1):
            out.add(f"{pre}-{n:03d}")
    s2 = RANGERE.sub(" ", s)   # 範囲部分を除去してから単体IDを拾う
    out |= IU.find_ids(s2)
    return out




def universe():
    b = load_tool("build")
    docs, defmap, defall, refs, dep = b._extract_ids()
    allref = set().union(*refs.values()) if refs else set()
    return set(defmap) | allref, defmap


def load(name):
    return yaml.safe_load(open(os.path.join(DOCS, name), encoding="utf-8"))


def trace_matrix():
    """traceability.yaml → F/NF-ID: {'from':set(R-), 'tests':set(UT/IT/ST/AT-)}"""
    t = load("traceability.yaml")
    # 列: 0企画 1要求 2要件 3基本 4詳細 5実装 6単体 7結合 8総合 9受入 ...
    m = {}
    for row in t.get("sample", []):
        reqids = parse_ids(row[2]) if len(row) > 2 else set()   # 要件(F-/NF-)
        rids = parse_ids(row[1]) if len(row) > 1 else set()     # 要求(R-)
        tests = set()
        for ci in (6, 7, 8, 9):
            if len(row) > ci:
                tests |= {x for x in parse_ids(row[ci]) if x.startswith(("UT-", "IT-", "ST-", "AT-"))}
        for f in reqids:
            e = m.setdefault(f, {"from": set(), "tests": set()})
            e["from"] |= {r for r in rids if r.startswith(("R-", "RS-", "NR-", "BR-"))}
            e["tests"] |= tests
    return m


def testdoc_sources(fname):
    """テスト設計doc → test-ID: set(トレース元ID)（範囲展開込み）。"""
    d = load(fname); out = {}
    for ch in d.get("chapters", []):
        for b in ch.get("blocks", []):
            if b.get("t") != "table":
                continue
            cols = [c[1] for c in b.get("cols", [])]
            if "テストID" not in cols or not any("トレース元" in c for c in cols):
                continue
            ii = cols.index("テストID"); ti = [i for i, c in enumerate(cols) if "トレース元" in c][0]
            for r in b.get("rows", []):
                if len(r) > ti and str(r[ii]).strip():
                    out.setdefault(str(r[ii]).strip(), set()).update(parse_ids(r[ti]))
    return out


def basic_design_sources():
    """04基本設計 → 設計ID(API/BT/SC/T-): set(実現する要件 F-/NF-)。一覧表の末尾要件列から。"""
    d = load("04_基本設計書.yaml"); out = {}
    for ch in d.get("chapters", []):
        for b in ch.get("blocks", []):
            if b.get("t") != "table":
                continue
            for r in b.get("rows", []):
                if not r:
                    continue
                head = parse_ids(str(r[0]))
                hid = next((x for x in head if x.startswith(("API-", "BT-", "SC-", "T-", "IF-"))), None)
                if not hid:
                    continue
                reqs = set()
                for cell in r[1:]:
                    reqs |= {x for x in parse_ids(cell) if x.startswith(("F-", "NF-"))}
                if reqs:
                    out.setdefault(hid, set()).update(reqs)
    return out


def req_expand():
    """43台帳 要求一覧 → 要求ID(R-/RS-/NR-): set(展開先 F-/NF-)。"""
    d = load("43_要求・要件一覧(管理台帳).yaml"); out = {}
    for ch in d.get("chapters", []):
        if "要求一覧" not in ch.get("title", ""):
            continue
        for b in ch.get("blocks", []):
            if b.get("t") != "table":
                continue
            for r in b.get("rows", []):
                if not r:
                    continue
                rid = str(r[0]).strip()
                if not rid.startswith(("R-", "RS-", "NR-", "BR-")):
                    continue
                fs = set()
                for cell in r[1:]:
                    fs |= {x for x in parse_ids(cell) if x.startswith(("F-", "NF-"))}
                if fs:
                    out.setdefault(rid, set()).update(fs)
    return out


def enrich():
    uni, defmap = universe()
    tm = trace_matrix()
    bd = basic_design_sources()
    rx = req_expand()
    td = {f: testdoc_sources(f) for f in
          ["06_単体テスト設計書.yaml", "07_結合テスト設計書.yaml",
           "08_総合テスト設計書.yaml", "09_受入テスト設計書.yaml"]}

    def keep(ids):
        return sorted(x for x in ids if x in uni)

    # ── 要件↔テストの統一リンク(pairs)を全ソースから構築し、両方向を対称に書く ──
    # ソース1: 俯瞰図(要件行→単体/結合/総合/受入)
    # ソース2: 各テストdocのトレース元列
    # ソース3: 既存の spec.defines 宣言(要件.tests / テスト.traces_from) ← 人手記入を温存し対称化
    pairs = set()   # (要件F-/NF-, テストUT/IT/ST/AT)
    for f, e in tm.items():
        for t in e.get("tests", set()):
            pairs.add((f, t))
    for fname, mp in td.items():
        for t, srcs in mp.items():
            for r in srcs:
                if r.startswith(("F-", "NF-")):
                    pairs.add((r, t))
    # ソース3: 現行の宣言を読む
    for f in glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml")):
        dd = yaml.safe_load(open(f, encoding="utf-8")) or {}
        for e in dd.get("spec", {}).get("defines", []) or []:
            i = e.get("id")
            if not i:
                continue
            if i.startswith(("F-", "NF-")):
                for t in e.get("tests", []) or []:
                    if t.split("-")[0] in ("UT", "IT", "ST", "AT"):
                        pairs.add((i, t))
            if i.split("-")[0] in ("UT", "IT", "ST", "AT"):
                for r in e.get("traces_from", []) or []:
                    if r.startswith(("F-", "NF-")):
                        pairs.add((r, i))
    # 宇宙に存在する両端のみ採用（宙吊り防止）
    pairs = {(r, t) for (r, t) in pairs if r in uni and t in uni}
    req_tests = {}   # 要件 → tests
    test_reqs = {}   # テスト → 要件(from)
    for r, t in pairs:
        req_tests.setdefault(r, set()).add(t)
        test_reqs.setdefault(t, set()).add(r)

    plan = {}   # fname -> {id -> {'from':[], 'to':[], 'tests':[]}}

    # 03 要件: tests を統一リンクから（traces_from/to は温存してマージ）
    add03 = {}
    for i in defmap:
        if defmap[i] == "03_要件定義書" and i.startswith(("F-", "NF-")):
            add03[i] = {"tests": keep(req_tests.get(i, set()))}
    plan["03_要件定義書.yaml"] = add03

    # 02 要求: traces_to を展開先(台帳)＋俯瞰図から補完
    add02 = {}
    r2f = {}
    for f, e in tm.items():
        for r in e["from"]:
            r2f.setdefault(r, set()).add(f)
    for i in defmap:
        if defmap[i] == "02_要求定義書" and i.startswith(("R-", "RS-", "NR-")):
            tos = set(rx.get(i, set())) | set(r2f.get(i, set()))
            add02[i] = {"to": keep(tos)}
    plan["02_要求定義書.yaml"] = add02

    # 04 基本設計: traces_from = 実現する要件（一覧表の要件参照列）
    add04 = {}
    for i in defmap:
        if defmap[i] == "04_基本設計書" and i.startswith(("API-", "BT-", "SC-", "T-")):
            add04[i] = {"from": keep(bd.get(i, set()))}
    plan["04_基本設計書.yaml"] = add04

    # 06-09 テスト: traces_from = 統一リンクの要件(対称) ＋ doc列の非要件上流(IF/BT/API/R)
    for fname in td:
        addt = {}; docname = fname[:-5]
        for i in defmap:
            if defmap[i] != docname:
                continue
            src = set(test_reqs.get(i, set()))                        # 要件(対称)
            for r in td[fname].get(i, set()):                        # doc列の非要件上流
                if r.startswith(("IF-", "BT-", "API-", "SC-", "R-", "RS-", "NR-")):
                    src.add(r)
            addt[i] = {"from": keep(src)}
        plan[fname] = addt
    return plan


def regen_spec_block(fname, plan_for_doc):
    """既存 spec.defines を読み、plan をマージして spec: ブロック文字列を再生成。"""
    path = os.path.join(DOCS, fname)
    raw = open(path, encoding="utf-8").read()
    d = yaml.safe_load(raw)
    defs = d.get("spec", {}).get("defines", [])
    changed = 0
    for e in defs:
        i = e.get("id")
        add = plan_for_doc.get(i)
        if not add:
            continue
        for key, field in (("from", "traces_from"), ("to", "traces_to"), ("tests", "tests")):
            newv = add.get(key)
            if not newv:
                continue
            cur = list(e.get(field, []) or [])
            merged = cur + [x for x in newv if x not in cur]
            if merged != cur:
                e[field] = merged; changed += 1
    # spec ブロックのみを整形出力（spec は各docの最終トップレベルキー）
    block = "spec:\n  defines:\n"
    for e in defs:
        block += f"  - id: {e['id']}\n    kind: {e.get('kind','')}\n"
        for field in ("traces_from", "traces_to", "tests"):
            if e.get(field):
                block += f"    {field}:\n" + "".join(f"    - {x}\n" for x in e[field])
    return raw, block, changed


def apply_all(plan, do_write):
    total = 0; touched = []; skipped = []
    for fname, pdoc in plan.items():
        if not any(pdoc.values()):
            continue
        raw, block, changed = regen_spec_block(fname, pdoc)
        if changed == 0:
            continue
        # spec: 行(トップレベル)を特定。spec が最終キーであることを保証してから置換する。
        m = re.search(r"^spec:[ \t]*$", raw, re.M)
        if not m:
            skipped.append((fname, "spec:行なし")); continue
        after = raw[m.end():]
        # spec 以降に別のトップレベルキー(^\w+:)があれば安全のため中止
        if re.search(r"^[A-Za-z_][\w]*:", after, re.M):
            skipped.append((fname, "spec が最終キーでない")); continue
        total += changed; touched.append((fname, changed))
        if do_write:
            newraw = raw[:m.start()] + block
            if not newraw.endswith("\n"):
                newraw += "\n"
            open(os.path.join(DOCS, fname), "w", encoding="utf-8").write(newraw)
    if skipped:
        for f, why in skipped:
            print(f"  ! スキップ {f}: {why}")
    return total, touched


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="docs を実際に書き換える")
    args = ap.parse_args()
    # 本ツールは Vモデル文書体系（02要求/03要件/04基本設計…）の spec.defines を前提とする。
    # スクラム版などVモデル文書を持たない配布では対象外（クラッシュせず正常終了）。
    if not os.path.exists(os.path.join(DOCS, "04_基本設計書.yaml")):
        print("[derive] Vモデル文書(04_基本設計書 等)が無い配布のため対象外。"
              "スクラム版のトレースは定義表の行内共起で管理されます（spec_check が閉包を検証）。")
        return 0
    plan = enrich()
    print("=== 導出トレース（ドライラン） ===" if not args.apply else "=== 適用 ===")
    for fname, pdoc in plan.items():
        lines = []
        for i, add in sorted(pdoc.items()):
            parts = []
            if add.get("from"): parts.append("from=" + ",".join(add["from"]))
            if add.get("to"): parts.append("to=" + ",".join(add["to"]))
            if add.get("tests"): parts.append("tests=" + ",".join(add["tests"]))
            if parts:
                lines.append(f"    {i:<8} " + " / ".join(parts))
        if lines:
            print(f"  [{fname}]")
            print("\n".join(lines))
    total, touched = apply_all(plan, args.apply)
    print("---")
    if args.apply:
        print(f"[derive] 適用: {total} フィールド更新 / 対象 " +
              ", ".join(f"{f.split('_')[0]}({c})" for f, c in touched))
    else:
        print(f"[derive] ドライラン: {total} フィールド更新予定 / 対象 " +
              ", ".join(f"{f.split('_')[0]}({c})" for f, c in touched))
        print("  → 反映するには: python3 tools/derive_traces.py --apply")


if __name__ == "__main__":
    main()
