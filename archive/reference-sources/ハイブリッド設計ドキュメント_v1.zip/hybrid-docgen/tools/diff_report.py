# -*- coding: utf-8 -*-
"""diff/notes: 2時点の docs/ を比較し、PM・顧客が読める日本語の差分レポートとリリースノートを生成する。

  python tools/build.py diff  --base <旧docsのパス | gitリビジョン>   # → build/00_変更差分レポート_*.md
  python tools/build.py notes --base <同上>                          # → build/リリースノート_*.md

比較の観点(git diffの行差分ではなく、設計の意味単位):
- 文書ごとの 追加/削除/変更IDと定義名(一覧先頭列＋spec.defines)
- 章ごとの表行数・本文の増減(どの章が動いたか)
- history(改版履歴)に追加された行 ← リリースノートの本文になる
- 「記録なき変更」: 内容が変わったのに history が増えていない文書(変更管理の穴として警告)
- catalog の採用状況(status)変化 / assign台帳の done/pass 化
基準側の指定: ディレクトリ(旧版を展開した docs/ の親 or docs/ 自体)、または gitリビジョン(リポジトリ運用時)。
"""
import os, sys, glob, subprocess, tempfile, datetime, hashlib
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
OUT = os.path.join(ROOT, "build")


from util import out_label as _lbl


def resolve_base(base):
    """--base をディレクトリに解決する。dir(docs直下 or 親) / gitリビジョン対応。"""
    if os.path.isdir(base):
        return base if os.path.isdir(os.path.join(base, "01_企画書.yaml")) or \
                       glob.glob(os.path.join(base, "[0-9]*_*.yaml")) else os.path.join(base, "docs")
    if os.path.isdir(os.path.join(ROOT, ".git")):
        tmp = tempfile.mkdtemp(prefix="vmodel_base_")
        r = subprocess.run(["git", "-C", ROOT, "archive", base, "docs"], capture_output=True)
        if r.returncode == 0:
            subprocess.run(["tar", "-x", "-C", tmp], input=r.stdout)
            return os.path.join(tmp, "docs")
    raise SystemExit(f"[diff] --base を解決できません: '{base}'（旧docsのディレクトリか、gitリビジョンを指定）")


def snapshot(docdir):
    """docs/ を意味単位に読み取る: {doc: {ids:{id:名称}, hist:[行], chap:{章:行数}, hash}}"""
    out = {}
    for fp in sorted(glob.glob(os.path.join(docdir, "[0-9][0-9]*_*.yaml"))):
        name = os.path.basename(fp)[:-5]
        raw = open(fp, encoding="utf-8").read()
        try:
            d = yaml.safe_load(raw) or {}
        except Exception:
            continue
        ids = {}
        for e in (d.get("spec", {}) or {}).get("defines", []) or []:
            if e.get("id"):
                ids[e["id"]] = e.get("kind", "")
        import re
        RE = re.compile(r"^(?:RS|R|NR|F|NF|SC|T|API|IF|BT|UT|IT|ST|AT|US)-\d+[a-z]?$")
        chap = {}
        for ch in d.get("chapters", []):
            n = 0
            for blk in ch.get("blocks", []):
                rows = blk.get("rows") or []
                n += len(rows)
                if blk.get("t") == "table":
                    for row in rows:
                        c0 = str(row[0]).strip() if row else ""
                        if RE.match(c0) and c0 not in ids:
                            nm = str(row[1]).strip() if len(row) > 1 else ""
                            ids[c0] = nm
            chap[ch.get("title", "")] = n
        out[name] = {"ids": ids, "hist": [tuple(map(str, h)) for h in d.get("history", [])],
                     "chap": chap, "hash": hashlib.sha1(raw.encode()).hexdigest()}
    return out


def compare(old, new):
    res = {"docs": {}, "new_docs": sorted(set(new) - set(old)), "gone_docs": sorted(set(old) - set(new)),
           "no_record": []}
    for name in sorted(set(old) & set(new)):
        o, n = old[name], new[name]
        if o["hash"] == n["hash"]:
            continue
        added = {i: k for i, k in n["ids"].items() if i not in o["ids"]}
        removed = {i: k for i, k in o["ids"].items() if i not in n["ids"]}
        chg_ch = sorted(t for t in set(o["chap"]) | set(n["chap"])
                        if o["chap"].get(t) != n["chap"].get(t))
        new_hist = [h for h in n["hist"] if h not in o["hist"]]
        res["docs"][name] = {"added": added, "removed": removed, "chapters": chg_ch, "hist": new_hist}
        if not new_hist:
            res["no_record"].append(name)
    return res


def emit_diff(res, base_desc):
    lbl = _lbl(); ts = datetime.date.today().isoformat()
    L = [f"# 変更差分レポート", f"- 基準: {base_desc} / 現在: docs/ ({ts})", ""]
    if res["new_docs"]:
        L.append("## 新規文書\n" + "\n".join(f"- {d}" for d in res["new_docs"]) + "\n")
    if res["gone_docs"]:
        L.append("## 削除された文書\n" + "\n".join(f"- {d}" for d in res["gone_docs"]) + "\n")
    if res["no_record"]:
        L.append("## ⚠ 記録なき変更（内容が変わったのに改版履歴が追加されていない）\n"
                 + "\n".join(f"- {d}" for d in res["no_record"])
                 + "\n\n> 変更管理の穴。history に版を追記すること。\n")
    L.append("## 文書別の変更\n")
    if not res["docs"]:
        L.append("(変更なし)\n")
    for name, c in res["docs"].items():
        L.append(f"### {name}")
        for i, k in sorted(c["added"].items()):
            L.append(f"- ＋ 追加ID: **{i}** {k}")
        for i, k in sorted(c["removed"].items()):
            L.append(f"- － 削除ID: **{i}** {k}")
        if c["chapters"]:
            L.append(f"- 変更のあった章: {', '.join(c['chapters'])}")
        for h in c["hist"]:
            L.append(f"- 改版: 版{h[0]} {h[1]} {h[2]} — {h[4] if len(h) > 4 else ''}")
        L.append("")
    p = os.path.join(OUT, f"00_変更差分レポート_{lbl}.md")
    os.makedirs(OUT, exist_ok=True)
    open(p, "w", encoding="utf-8").write("\n".join(L))
    n = len(res["docs"])
    print(f"[diff] 変更 {n} 文書 / 新規 {len(res['new_docs'])} / 記録なき変更 {len(res['no_record'])}"
          f" → build/00_変更差分レポート_{lbl}.md")
    return 1 if res["no_record"] else 0


def emit_notes(res, base_desc):
    lbl = _lbl(); ts = datetime.date.today().isoformat()
    L = [f"# リリースノート ({ts})", f"- 対象: {base_desc} 以降の変更", ""]
    feats, fixes, others = [], [], []
    for name, c in res["docs"].items():
        for h in c["hist"]:
            msg = h[4] if len(h) > 4 else ""
            line = f"- {msg}（{name.split('_',1)[1] if '_' in name else name} 版{h[0]}）"
            (fixes if any(w in msg for w in ("修正", "不具合", "是正")) else
             feats if any(w in msg for w in ("追加", "新規", "対応", "強化")) else others).append(line)
        for i, k in sorted(c["added"].items()):
            if i.split("-")[0] in ("F", "NF"):
                feats.append(f"- 新しい要件: {i} {k}（{name}）")
    # assign台帳から完了実績
    asg_p = os.path.join(DOCS, "assign.yaml")
    done = []
    if os.path.exists(asg_p):
        asg = yaml.safe_load(open(asg_p, encoding="utf-8")) or {}
        done = [f"- {r['id']} 実装完了（{r.get('date','')}）" for r in asg.get("impl", [])
                if r.get("status") == "done"]
    for title, items in (("## 追加・強化", feats), ("## 修正", fixes),
                          ("## その他の変更", others), ("## 実装完了（実行割当台帳より）", done)):
        if items:
            L.append(title); L.extend(items); L.append("")
    if len(L) <= 3:
        L.append("(記録された変更はありません)")
    p = os.path.join(OUT, f"リリースノート_{lbl}.md")
    open(p, "w", encoding="utf-8").write("\n".join(L))
    print(f"[notes] 追加{len(feats)}/修正{len(fixes)}/他{len(others)}/実装完了{len(done)}"
          f" → build/リリースノート_{lbl}.md")
    return 0


def main(mode, base):
    bdir = resolve_base(base)
    res = compare(snapshot(bdir), snapshot(DOCS))
    return emit_notes(res, base) if mode == "notes" else emit_diff(res, base)


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["diff", "notes"])
    ap.add_argument("--base", required=True)
    a = ap.parse_args()
    sys.exit(main(a.mode, a.base))
