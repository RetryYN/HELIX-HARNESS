# -*- coding: utf-8 -*-
"""ID抽出の共通ユーティリティ。

build/validate/activation/impact が別々の正規表現を持つと、文書体系を増やした時に
検査が空振りする。ここを単一の入口にして、表・kv・bullets・note等を再帰走査する。
"""
import os, re, yaml

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")


def scrum_mode():
    """Vモデル側の SG-01/G01 等をスクラムIDとして誤検出しないため、実体で切り替える。
    プロダクトバックログ文書の存在で判定する（番号非依存。ハイブリッド配布は110番台に置く）。"""
    import glob as _g
    return bool(_g.glob(os.path.join(DOCS, "*_プロダクトバックログ.yaml")))


BASE_ID_PATTERNS = [
    # Vモデル系
    r"BR-\d+", r"BR-\d+", r"RS-\d+", r"R-\d+", r"NR-\d+", r"F-\d+", r"NF-\d+",
    r"SC-\d+", r"T-\d+", r"API-\d+", r"IF-\d+", r"BT-\d+",
    r"UT-\d+[A-Za-z]?", r"IT-\d+", r"ST-\d+", r"AT-\d+", r"US-\d+",
]
SCRUM_ID_PATTERNS = [
    r"EP-\d+", r"AC-\d+(?:-\d+)?", r"SP-\d+", r"SG-\d+",
    r"INC-\d+", r"REV-\d+", r"R\d+(?:\.\d+)?", r"G[1-9]\d*(?:\.\d+)?",
]
ID_PATTERNS = BASE_ID_PATTERNS + (SCRUM_ID_PATTERNS if scrum_mode() else [])
ID_RE = re.compile(r"(?<![A-Za-z0-9])(?:" + "|".join(ID_PATTERNS) + r")(?![A-Za-z0-9._-])")
COMPRESSED_RE = re.compile(r"\b([A-Z]{1,6})-(\d+)((?:/\d+)+)\b")

BASE_DEF_TABLE_TITLES = [
    "業務ルール", "機能一覧", "画面一覧", "テーブル一覧", "API設計", "機能要求一覧",
    "非機能要求", "非機能要件", "ユースケース", "バッチ", "外部インターフェース", "テストケース",
]
SCRUM_DEF_TABLE_TITLES = [
    "プロダクトゴール", "エピック一覧", "プロダクトバックログ", "受入基準一覧", "AC一覧",
    "リリース目標",
]
DEF_TABLE_TITLES = BASE_DEF_TABLE_TITLES + (SCRUM_DEF_TABLE_TITLES if scrum_mode() else [])


def find_ids(value):
    """文字列・数値などからID集合を抽出する。US-01/02/03 の短縮表記も展開する。"""
    if value is None:
        return set()
    s = str(value)
    out = set(ID_RE.findall(s))
    for m in COMPRESSED_RE.finditer(s):
        prefix, first, rest = m.group(1), m.group(2), m.group(3)
        for part in rest.split('/')[1:]:
            cand = f"{prefix}-{part.zfill(len(first))}"
            if ID_RE.fullmatch(cand):
                out.add(cand)
    return out


def is_id(value):
    return bool(ID_RE.fullmatch(str(value).strip())) if value is not None else False


def iter_scalars(obj):
    if obj is None:
        return
    if isinstance(obj, dict):
        for v in obj.values():
            yield from iter_scalars(v)
    elif isinstance(obj, (list, tuple, set)):
        for v in obj:
            yield from iter_scalars(v)
    else:
        yield obj


def scan_ids(obj):
    out = set()
    for v in iter_scalars(obj):
        out |= find_ids(v)
    return out


def spec_defines(doc):
    out = []
    for e in ((doc or {}).get("spec", {}) or {}).get("defines", []) or []:
        if isinstance(e, dict) and e.get("id") and is_id(e.get("id")):
            out.append(e)
    return out


def agent_defined_ids(doc):
    """agent.defines は、スクラム版では実ID、Vモデル版では主に接頭辞契約として扱う。"""
    if not scrum_mode():
        return []
    out = []
    for x in ((doc or {}).get("agent", {}) or {}).get("defines", []) or []:
        sx = str(x).strip()
        if is_id(sx):
            out.append(sx)
    return out


def declared_ids(doc):
    """spec.defines を正本にし、specが無いスクラム文書だけ agent.defines を定義IDとして扱う。"""
    ids = [e["id"] for e in spec_defines(doc)]
    if not ids:
        ids.extend(agent_defined_ids(doc))
    return ids


def declared_items(doc):
    """spec_types/spec_trace用。specが無いスクラム文書はagent.definesを軽量宣言として扱う。"""
    sp = spec_defines(doc)
    if sp:
        return sp
    return [{"id": i, "kind": "agent", "traces_from": [], "traces_to": [], "tests": []}
            for i in agent_defined_ids(doc)]


def is_def_table_title(title):
    return any(k in str(title or "") for k in DEF_TABLE_TITLES)


def table_defined_ids(doc, suppress_when_spec=True):
    """定義表の先頭列からIDを拾う。spec.defines がある文書では従来通りspecを正本にする。"""
    if suppress_when_spec and spec_defines(doc):
        return set()
    out = set()
    for ch in (doc or {}).get("chapters", []) or []:
        if not is_def_table_title(ch.get("title", "")):
            continue
        for blk in ch.get("blocks", []) or []:
            if blk.get("t") != "table":
                continue
            for row in blk.get("rows", []) or []:
                if row:
                    out |= find_ids(row[0])
    return out


def add_definition(defmap, defall, iid, doc_name):
    if not iid or not is_id(iid):
        return
    defmap.setdefault(iid, doc_name)
    defall.setdefault(iid, set()).add(doc_name)


def extract_from_files(files):
    docs, defmap, defall, refs = [], {}, {}, {}
    for fp in files:
        d = yaml.safe_load(open(fp, encoding="utf-8")) or {}
        name = os.path.basename(fp)[:-5]
        docs.append(name)
        # 参照はchapters本文だけを再帰走査。spec/agent宣言は「参照」に混ぜない。
        refs[name] = scan_ids(d.get("chapters", []))
        for iid in declared_ids(d):
            add_definition(defmap, defall, iid, name)
        for iid in table_defined_ids(d, suppress_when_spec=True):
            add_definition(defmap, defall, iid, name)
    dep = {a: {} for a in docs}
    for a in docs:
        for rid in refs.get(a, set()):
            b = defmap.get(rid)
            if b and b != a:
                dep[a][b] = dep[a].get(b, 0) + 1
    return docs, defmap, defall, refs, dep


def contract_token(iid):
    """agent.defines突合用。ハイフンIDは接頭辞、G1/R0.9のようなIDは英字部を返す。"""
    s = str(iid)
    if '-' in s:
        return s.split('-')[0] + '-'
    m = re.match(r"[A-Za-z]+", s)
    return (m.group(0) if m else s)


# ---- スクラム行内共起（定義表の同一行からGoal→Epic→Story→ACの親子を導出） ----

def scrum_rank(iid):
    """スクラムIDの階層順位。G=1 → EP=2 → US=3 → AC=4 → SG/SP=5 → INC=6 → R=7。対象外は None。"""
    s = str(iid).strip()
    if s.startswith("EP-"):
        return 2
    if s.startswith("US-"):
        return 3
    if s.startswith("AC-"):
        return 4
    if s.startswith(("SG-", "SP-")):
        return 5
    if s.startswith("INC-"):
        return 6
    if re.fullmatch(r"G[1-9]\d*(?:\.\d+)?", s):
        return 1
    if re.fullmatch(r"R\d+(?:\.\d+)?(?:\s.*)?", s):
        return 7
    return None


NOTE_COL_WORDS = ("備考", "メモ", "注記", "補足", "コメント", "状態", "状況", "ステータス")


def def_row_companions(files):
    """定義表の各行について {行頭ID: 同伴ID集合} を返す。
    行頭に一度も現れないID（agent.defines のみの集約ID等）はキーに含まれない。
    spec.defines を持つ文書は従来通り spec が正本のため対象外。
    備考・メモ等の説明列(NOTE_COL_WORDS)は同伴から除外する——備考に書かれた
    親IDで閉包検証が偽充足しないようにするため。紐付けは宣言的な列に書くこと。"""
    out = {}
    for fp in files:
        try:
            d = yaml.safe_load(open(fp, encoding="utf-8")) or {}
        except (yaml.YAMLError, OSError, UnicodeDecodeError):
            continue   # 壊れたYAML等は schema_check / verify_files が exit=1 で止める(多層防御)
        if spec_defines(d):
            continue
        for ch in (d or {}).get("chapters", []) or []:
            if not is_def_table_title(ch.get("title", "")):
                continue
            for blk in ch.get("blocks", []) or []:
                if blk.get("t") != "table":
                    continue
                # 列ヘッダから「説明列」の位置を特定(cols: [[列記号, ヘッダ名, 幅], ...])
                skip_idx = set()
                for ci, col in enumerate(blk.get("cols", []) or []):
                    try:
                        head = str(col[1])
                    except (IndexError, TypeError):
                        continue
                    if any(w in head for w in NOTE_COL_WORDS):
                        skip_idx.add(ci)
                for row in blk.get("rows", []) or []:
                    if not row:
                        continue
                    heads = find_ids(row[0])
                    rest = set()
                    for ci, c in enumerate(row[1:], start=1):
                        if ci in skip_idx:
                            continue
                        rest |= find_ids(c)
                    for h in heads:
                        out.setdefault(h, set()).update(rest - heads)
    return out
