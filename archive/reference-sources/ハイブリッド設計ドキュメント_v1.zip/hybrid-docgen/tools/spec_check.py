# -*- coding: utf-8 -*-
"""編み目式Vモデル: トレース閉包 + RAG(赤黄緑) + 変更インパクト分析。
  python3 tools/spec_check.py              閉包検査 + 要件のRAG集計 (exit 0=赤なし)
  python3 tools/spec_check.py --impact ID  そのIDを変更したとき要レビューになる依存先を列挙
既存エンジン(build.py)は変更せず、追加の検査として動作する。
"""
import os, sys, re, json, argparse, importlib.util
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import util  # 副作用: cp932コンソールでの記号出力ガード
import yaml
import id_utils as IU

HERE = os.path.dirname(os.path.abspath(__file__))
DOCS = os.path.join(HERE, "..", "docs")
LEDGER = os.path.join(DOCS, "43_要求・要件一覧(管理台帳).yaml")
GREEN_STATES = {"設計済", "完了", "done", "実装済", "テスト済"}

def ids(s): return IU.find_ids(s)
def is_empty(s):
    s = str(s).strip(); return s == "" or s == "-"

def load_ledger():
    req, ken = {}, {}
    if not os.path.exists(LEDGER):
        return req, ken   # 台帳(要求・要件一覧)が無い運用(例: スクラム版)では台帳RAGをスキップ
    d = yaml.safe_load(open(LEDGER, encoding="utf-8"))
    for ch in d.get("chapters", []):
        title = ch.get("title", "")
        for b in ch.get("blocks", []):
            if b.get("t") != "table": continue
            for r in b.get("rows", []):
                if not r: continue
                if "要求一覧" in title:
                    req[str(r[0]).strip()] = {
                        "exp": str(r[5]).strip() if len(r) > 5 else "",
                        "state": str(r[6]).strip() if len(r) > 6 else "",
                        "expids": ids(r[5]) if len(r) > 5 else set()}
                elif "要件一覧" in title:
                    ken[str(r[0]).strip()] = {
                        "src": str(r[3]).strip() if len(r) > 3 else "",
                        "des": str(r[4]).strip() if len(r) > 4 else "",
                        "tst": str(r[5]).strip() if len(r) > 5 else "",
                        "state": str(r[6]).strip() if len(r) > 6 else "",
                        "srcids": ids(r[3]) if len(r) > 3 else set()}
    return req, ken

def load_design():
    spec = importlib.util.spec_from_file_location("b", os.path.join(HERE, "build.py"))
    b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
    docs, defmap, defall, refs, dep = b._extract_ids()
    return docs, defmap, refs

def rag(req, ken, design_reqids):
    out = {}
    for kid, v in ken.items():
        reasons = []
        if is_empty(v["src"]): reasons.append("トレース元(要求)なし")
        if is_empty(v["des"]): reasons.append("対応設計なし")
        if is_empty(v["tst"]): reasons.append("対応テストなし")
        for r in v["srcids"]:
            if r.startswith(("BR-", "RS-", "R-", "NR-")) and r not in req:
                reasons.append(f"トレース元{r}が要求一覧に無い")
        color = "赤" if reasons else ("緑" if v["state"] in GREEN_STATES else "黄")
        out[kid] = (color, reasons or ([f"状態={v['state']}(未同期)"] if color == "黄" else []))
    for k in sorted(design_reqids - set(ken)):
        out[k] = ("赤", ["設計docに定義があるが台帳の要件一覧に未登録"])
    return out

def load_signals(path):
    cand = path or os.path.join(HERE, "..", "build", "signals.json")
    if cand and os.path.exists(cand):
        try: return json.load(open(cand, encoding="utf-8"))
        except Exception: return None
    return None

def apply_live(r, ken, sig):
    tests = sig.get("tests", {}); impl = sig.get("impl", {}); upd = sig.get("updated", {})
    for kid in list(r.keys()):
        col, why = r[kid]
        tids = ids(ken.get(kid, {}).get("tst", ""))
        failing = [t for t in tids if tests.get(t) == "fail"]
        if failing:
            r[kid] = ("赤", [f"テスト失敗:{','.join(failing)}"]); continue
        if impl.get(kid) is False and col == "緑":
            r[kid] = ("黄", ["未実装"]); continue
        up = ken.get(kid, {}).get("srcids", set())
        if kid in upd:
            stale = [u for u in up if u in upd and upd[u] > upd[kid]]
            if stale and col == "緑":
                r[kid] = ("黄", [f"上流変更で陳腐化:{','.join(sorted(stale))}"])
    return r

def scrum_link_check():
    """定義表の行内共起から Goal→Epic→Story→AC の親子リンクを検証（scrum文書層がある場合のみ）。
    行頭に現れないID（他文書がspec正本で定義するUS等）は自動的に対象外。戻り値: 不整合数。"""
    if not IU.scrum_mode():
        return 0
    import glob as _glob
    files = sorted(_glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml")))
    comp = IU.def_row_companions(files)
    NEED_PARENT = {2: (1, "G(プロダクトゴール)"), 3: (2, "EP(エピック)"), 4: (3, "US(ストーリー)")}
    orphans, infos = [], []
    for i in sorted(comp):
        rk = IU.scrum_rank(i)
        if rk in NEED_PARENT:
            prk, label = NEED_PARENT[rk]
            if not any(IU.scrum_rank(x) == prk for x in comp[i]):
                orphans.append(f"{i}: 定義行に親{label}が同伴していない（トレース切れ）")
    us_heads = {i for i in comp if IU.scrum_rank(i) == 3}
    us_with_ac = {i for i in us_heads if any(IU.scrum_rank(x) == 4 for x in comp[i])}
    us_with_ac |= {x for i in comp if IU.scrum_rank(i) == 4
                   for x in comp[i] if IU.scrum_rank(x) == 3}
    for i in sorted(us_heads - us_with_ac):
        infos.append(f"{i}: 受入基準(AC)が未定義（未着手PBIなら正常。Ready にする前に追加）")
    for m in infos:
        print(f"   △ [情報] {m}")
    if orphans:
        print("  ✗ 親子トレース切れ:")
        for m in orphans:
            print(f"     - {m}")
    return len(orphans)


def cmd_summary(live_path=None):
    req, ken = load_ledger()
    docs, defmap, refs = load_design()
    if not req and not ken:
        # Scrum版など、Vモデル台帳を持たない配布では、0件RAGで通すのではなく
        # build._extract_ids が認識したID宇宙を明示して閉包を確認する。
        allids = set(defmap)
        def cnt(prefix):
            if prefix == "G":
                return len([i for i in allids if i.startswith("G") and "-" not in i])
            if prefix == "R":
                return len([i for i in allids if i.startswith("R") and "-" not in i])
            return len([i for i in allids if i.startswith(prefix)])
        refids = set().union(*refs.values()) if refs else set()
        allowed = ("UT-", "IT-", "ST-", "AT-", "MSG-", "GA-", "OT-", "D-NF-", "MOD-", "CMN-")
        missing = sorted(i for i in refids if i not in allids and not i.startswith(allowed))
        if IU.scrum_mode():
            print(f"[mesh] Scrum定義 Goal {cnt('G')} / Epic {cnt('EP-')} / Story {cnt('US-')} / AC {cnt('AC-')} / Sprint {cnt('SP-')} / SG {cnt('SG-')} / Increment {cnt('INC-')} / Release {cnt('R')} / ID宇宙 {len(allids | refids)}")
        else:
            print(f"[mesh] 台帳(43)が空/未記入のため要件RAGは未評価（記入後に再実行） / ID宇宙 {len(allids | refids)}")
        if missing:
            print("  ✗ 未定義参照:")
            for i in missing:
                print(f"     - {i}")
            return 1
        # 親子リンクの閉包検証: 定義表の行内共起から Goal→Epic→Story→AC を機械検証する。
        if not IU.scrum_mode():
            print("  ✓ 未定義参照なし（要件RAGは台帳記入後に評価されます）")
            return 0
        if scrum_link_check():
            return 1
        print("  ✓ Scrum ID閉包OK: 参照切れなし・G→EP→US→AC の親子リンク欠落なし")
        return 0
    # スコープ活性時は、対象内(定義 or 参照)の要件だけを評価対象にする
    try:
        import scope as _scope
        if _scope.active() is not None:
            uni = set(defmap) | (set().union(*refs.values()) if refs else set())
            ken = {k: v for k, v in ken.items() if k in uni}
            req = {k: v for k, v in req.items() if k in uni or any(x in uni for x in v.get("expids", set()))}
    except Exception:
        pass
    dids = {i for i in defmap if i.startswith(("F-", "NF-"))}
    r = rag(req, ken, dids)
    sig = load_signals(live_path) if live_path is not None else None
    live = ""
    if sig is not None:
        r = apply_live(r, ken, sig); live = " (ライブ信号適用)"
    from collections import Counter
    c = Counter(v[0] for v in r.values())
    print(f"[mesh] 要求 {len(req)} / 要件 {len(ken)} / 設計定義 {len(dids)}{live}")
    print(f"  RAG: 緑={c.get('緑',0)} 黄={c.get('黄',0)} 赤={c.get('赤',0)}")
    bad_links = scrum_link_check()   # ハイブリッド構成: スクラム文書層があれば G→EP 等の親子も検査
    non_green = {k: v for k, v in r.items() if v[0] != "緑"}
    if not non_green:
        if bad_links:
            return 1
        msg = "要求→要件→設計→テストの閉包・同期に漏れなし"
        if IU.scrum_mode():
            msg = "G→EP→US(要求)→要件→設計→テストの閉包・同期に漏れなし"
        print(f"  ✓ 全要件が緑: {msg}")
        return 0
    for k, (col, why) in sorted(non_green.items()):
        print(f"     - [{col}] {k}: {', '.join(why)}")
    return 1 if (c.get("赤", 0) or bad_links) else 0

def cmd_impact(target):
    req, ken = load_ledger()
    docs, defmap, refs = load_design()
    print(f"[impact] {target} を変更した場合に要レビュー(黄)となる依存先:")
    hit = False
    ref_docs = sorted(d.split("_")[0] for d in docs if target in refs.get(d, set()))
    if ref_docs:
        hit = True; print("  \u25bc 参照している設計doc:", ", ".join(ref_docs))
    if target in ken:
        v = ken[target]; hit = True
        print(f"  \u25bc 上流(要求): {v['src'] or '-'}")
        print(f"  \u25bc 下流(対応設計): {v['des'] or '-'}")
        print(f"  \u25bc 下流(対応テスト): {v['tst'] or '-'}")
    if target in req:
        hit = True; print(f"  \u25bc 展開先(要件): {req[target]['exp'] or '-'}")
    back = [k for k, v in ken.items() if target in v["srcids"]] + \
           [k for k, v in req.items() if target in v["expids"]]
    if back:
        hit = True; print("  \u25bc このIDを指す台帳項目:", ", ".join(sorted(set(back))))
    if not hit:
        print("  (依存先は検出されませんでした)")
    print("  \u2192 上記を黄(要レビュー)として、変更整合を確認・再テストする。")
    return 0


def cmd_graph(live_path=None, out=None):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyBboxPatch
    import matplotlib.font_manager as fm
    fp = None
    for c in ["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"]:
        if os.path.exists(c): fp = c
    JF = fm.FontProperties(fname=fp) if fp else fm.FontProperties()
    req, ken = load_ledger()
    _, defmap, _ = load_design()
    dids = {i for i in defmap if i.startswith(("F-", "NF-"))}
    r = rag(req, ken, dids)
    sig = load_signals(live_path) if live_path is not None else None
    if sig is not None: r = apply_live(r, ken, sig)
    COLOR = {"緑": "#C6EFCE", "黄": "#FFF2CC", "赤": "#F8CBAD"}
    EC = {"緑": "#548235", "黄": "#BF9000", "赤": "#C00000"}
    keys = sorted(ken.keys())
    n = len(keys)
    fig, ax = plt.subplots(figsize=(12, max(3, n * 0.5 + 1)), dpi=140); ax.axis("off")
    ax.set_xlim(0, 12); ax.set_ylim(0, n + 1)
    ax.text(0.3, n + 0.5, "上流(要求)", fontproperties=JF, fontsize=9, color="#888")
    ax.text(3.2, n + 0.5, "要件(RAG)", fontproperties=JF, fontsize=9, color="#888")
    ax.text(6.7, n + 0.5, "対応設計", fontproperties=JF, fontsize=9, color="#888")
    ax.text(9.5, n + 0.5, "対応テスト", fontproperties=JF, fontsize=9, color="#888")
    for i, kid in enumerate(keys):
        y = n - i
        col = r[kid][0]; v = ken[kid]
        ax.text(0.3, y, v.get("src", "-") or "-", fontproperties=JF, fontsize=8, va="center", color="#444")
        ax.annotate("", xy=(3.15, y), xytext=(2.7, y), arrowprops=dict(arrowstyle="-|>", color="#999", lw=0.8))
        ax.add_patch(FancyBboxPatch((3.2, y - 0.28), 3.0, 0.56, boxstyle="round,pad=0.02,rounding_size=0.08",
                                     fc=COLOR[col], ec=EC[col], lw=1.4))
        ax.text(4.7, y, f"{kid}  [{col}]", ha="center", va="center", fontproperties=JF, fontsize=8.5, color="#222")
        ax.annotate("", xy=(6.6, y), xytext=(6.25, y), arrowprops=dict(arrowstyle="-|>", color="#999", lw=0.8))
        ax.text(6.7, y, v.get("des", "-") or "-", fontproperties=JF, fontsize=8, va="center", color="#444")
        ax.annotate("", xy=(9.45, y), xytext=(9.1, y), arrowprops=dict(arrowstyle="-|>", color="#999", lw=0.8))
        ax.text(9.5, y, v.get("tst", "-") or "-", fontproperties=JF, fontsize=8, va="center", color="#444")
    live = " (ライブ)" if sig is not None else " (構造)"
    ax.set_title("トレースメッシュ RAG: 要求 → 要件 → 設計 → テスト" + live, fontproperties=JF, fontsize=13, color="#1F3864", loc="left")
    out = out or os.path.join(HERE, "..", "build", "図面", "トレースメッシュRAG.png")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    plt.tight_layout(); fig.savefig(out, dpi=140, bbox_inches="tight"); plt.close(fig)
    print(f"[graph] トレースメッシュRAG → {os.path.relpath(out, os.path.join(HERE, '..'))}")
    return 0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--impact", metavar="ID", help="変更インパクト分析")
    ap.add_argument("--live", nargs="?", const="", metavar="PATH", help="CI/VCS信号(signals.json)で実行時RAG")
    ap.add_argument("--graph", action="store_true", help="RAG色付きトレースメッシュ図を生成")
    args = ap.parse_args()
    if args.impact: return cmd_impact(args.impact)
    if args.graph: return cmd_graph(args.live)
    return cmd_summary(args.live)

if __name__ == "__main__":
    sys.exit(main())
