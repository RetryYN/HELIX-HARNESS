# -*- coding: utf-8 -*-
"""Markdown出力: 設計doc(YAML)と工程表を、VSCodeで“Excel風”に見えるGFMテーブルへ変換する。
  - 各doc → build/md/<name>.md (見出し/注記/箇条書き/表 を Markdown化。表はGFMテーブル)
  - wbs.yaml → build/md/00_実装工程管理表(L単位).md
VSCodeの Markdown Preview は GFMテーブルを罫線付きグリッドで描画するため、拡張なしでExcel風に閲覧できる。
  使い方: python3 tools/md_export.py
"""
import os, glob
import os as _os, sys as _sys; _sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
import util  # 副作用: cp932コンソールでの記号出力ガード
import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
DOCS = os.path.join(HERE, "..", "docs")
OUT = os.path.join(HERE, "..", "build", "md")

def esc(v):
    s = "" if v is None else str(v)
    return s.replace("|", "\\|").replace("\n", "<br>")

def md_table(headers, rows):
    out = ["| " + " | ".join(esc(h) for h in headers) + " |",
           "| " + " | ".join("---" for _ in headers) + " |"]
    for r in rows:
        cells = list(r) + [""] * (len(headers) - len(r))
        out.append("| " + " | ".join(esc(c) for c in cells[:len(headers)]) + " |")
    return "\n".join(out)

def render_doc(d):
    L = []
    L.append(f"# {d.get('title', d.get('file',''))}\n")
    if d.get("meta"):
        L.append(md_table(["項目", "値"], d["meta"]) + "\n")
    for ch in d.get("chapters", []):
        L.append(f"## {ch.get('num','')} {ch.get('title','')}\n")
        for b in ch.get("blocks", []):
            t = b.get("t")
            if t == "sec":
                L.append(f"### {b.get('num','')} {b.get('title','')}\n")
            elif t == "sub":
                L.append(f"#### {esc(b.get('text',''))}\n")
            elif t == "para":
                L.append(esc(b.get("text", "")) + "\n")
            elif t == "note":
                L.append("> " + esc(b.get("text", "")).replace("<br>", "\n> ") + "\n")
            elif t == "bullets":
                L.append("\n".join(f"- {esc(i)}" for i in b.get("items", [])) + "\n")
            elif t == "kv":
                L.append(md_table(["項目", "内容"], b.get("rows", [])) + "\n")
            elif t == "table":
                headers = [c[1] for c in b.get("cols", [])]
                L.append(md_table(headers, b.get("rows", [])) + "\n")
            elif t == "gap":
                L.append("")
    return "\n".join(L)

def render_wbs(w):
    L = ["# 実装工程管理表（L単位）\n",
         "> 実装工程 L1〜L7 ｜ 進捗＝現在のL（担当 人/AI）。太字(**)は工程(L)行。\n"]
    headers = [c[0] for c in w["info"]]
    rows = []
    for t in w["tasks"]:
        No, wbs_, name, who, sdt, edt, eff, prog, pre, ph = (list(t) + [""] * 10)[:10]
        nm = f"**{name}**" if ph == "P" else name
        wl = f"**{wbs_}**" if ph == "P" else wbs_
        rows.append([No, wl, nm, who, sdt, edt, eff, prog, pre])
    L.append(md_table(headers, rows))
    return "\n".join(L)

def main():
    os.makedirs(OUT, exist_ok=True)
    n = 0
    for f in sorted(glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml"))):
        d = yaml.safe_load(open(f, encoding="utf-8"))
        name = os.path.basename(f)[:-5]
        open(os.path.join(OUT, name + ".md"), "w", encoding="utf-8").write(render_doc(d))
        n += 1
    wp = os.path.join(DOCS, "wbs.yaml")
    if os.path.exists(wp):
        w = yaml.safe_load(open(wp, encoding="utf-8"))
        open(os.path.join(OUT, "00_実装工程管理表(L単位).md"), "w", encoding="utf-8").write(render_wbs(w))
        n += 1
    print(f"[md] {n} 本を build/md/ に出力(GFMテーブル=VSCodeでExcel風)")

if __name__ == "__main__":
    main()
