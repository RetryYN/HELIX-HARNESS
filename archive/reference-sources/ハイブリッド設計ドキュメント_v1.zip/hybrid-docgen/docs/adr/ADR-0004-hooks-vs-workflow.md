# ADR-0004: エージェント規律の実装方式 — hookとワークフローの役割分担

- 状態: 採用 / 日付: 2026-07-08 / 関連: AGENTS.md, .claude/settings.json, scripts/hooks/, vmodel-workflow

## 文脈
「変更後にdetectを回す」「見直し範囲はimpactで列挙」等のエージェント規律を、
文書規約(ワークフロー)として維持するか、機構(hook)として強制するかの選択。

## 決定
二者択一にせず、性質で分担する。
- **hook(機構で強制)** = 文脈判断を要しない不変条件のみ:
  1. docs/*.yaml 変更後の detect(Claude Code PostToolUse → tools/hook_gate.py。赤はstderrで即時返す)
  2. コミット前の 秘密情報/整合/全ゲート(scripts/hooks/pre-commit。有効化: `git config core.hooksPath scripts/hooks`)
  3. push後の 全ゲート×両OS(既設CI spec-gate.yml)
- **ワークフロー(スキルで規約)** = 判断を伴う手順: impactの上下左右(上流は「読む」のか「直す」のか)、
  粒度・用語の最終判断、プロト合意、敵対検証の役割割当。これらをhookで強制すると誤動作が規律を殺す。

## 根拠
hookの強みは「忘れられない」、弱みは「文脈が読めない」。最小コードの原則(96)に従い
自作フレームワークは作らず、既存のフック点(Claude Code hooks / git hooksPath / CI)に薄い門番
(hook_gate.py 約30行)のみを載せる。フックは失敗時もエージェントの作業自体を壊さない(黙って通す側に倒す)。

## 帰結
- 三重の網: 編集時(hook) → コミット時(pre-commit) → push時(CI)。すり抜けは人間レビューと敵対検証が拾う。
- hookを外して作業することは可能(強制は絶対ではない)。外した状態の変更もCIが最終的に検出する。
