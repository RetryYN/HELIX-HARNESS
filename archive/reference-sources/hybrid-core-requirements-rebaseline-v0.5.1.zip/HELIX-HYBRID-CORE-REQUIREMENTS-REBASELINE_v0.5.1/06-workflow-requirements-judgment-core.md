# 6. Workflow Requirements Judgment Core

## 中核式

```text
対象 × 現在状態 × 発火 × 条件 × 権限 × 利用可能資源
→ switching
→ routing
→ allocation
→ action
→ data update
→ next state
→ reassessment / loop / terminal / exception
```

## 既存Pythonとの接続

Workflow Requirements Engine v1.1.0はvendor pinし、既存Python sourceへ直接mergeしません。adapterが次を行います。

- engineの質問・workflow modelを既存YAML/typed IDへ変換
- 既存`schema_check/spec_check/spec_trace`へ検証を委譲
- 既存`build/schedule/assign/review`へ入力を渡す
- vendor schema差異をadapter metadataで可視化

adapterの実行はNode CLI側（D-009参照）が担い、既存Python資産（`schema_check`/`spec_check`/`spec_trace`/`build`/`schedule`/`assign`/`review`）へは検証・入力受け渡しの委譲のみで、Python側にcommand実行権限は与えない（ADR-009準拠）。実行形態（Node CLI主体・Python非実行）はD-009で確定し、本節はその適用を示す。

L3契約からL4-L6設計契約への降下は`templates/L4-L6-workflow-judgment-design.template.yaml`へswitching/routing/resource_pools/allocation_policiesを1件ずつtraceする。

## 要求ヒアリング

- 共通質問: 対象、actor、開始、状態、分岐、処理、戻り、終了、例外
- signal質問: 承認、金額、期限、外部API、個人情報、AI判断、resource制約
- AI権限: read-only gap surfacing
- 人権限: L1/L2採否・freeze・収束
- L3: AI draft、PO approve

workflow transitionからFR、GWT AC、screen、API、data、permission、notification、audit、testを同じIDで生成します。

## 成果物マッピング

| vendorファイル | 本文の対応概念 |
|---|---|
| `vendor/workflow-requirements-engine-v1.1.0/catalogs/base-question-catalog.md` | 『共通質問』（対象・actor・開始・状態・分岐・処理・戻り・終了・例外） |
| `vendor/workflow-requirements-engine-v1.1.0/catalogs/conditional-question-catalog.yaml` | 『signal質問』（承認・金額・期限・外部API・個人情報・AI判断・resource制約） |
| `vendor/workflow-requirements-engine-v1.1.0/catalogs/runtime-orchestration-question-catalog.md` | 『要求ヒアリング』のRuntime observation関連質問 |
| `vendor/workflow-requirements-engine-v1.1.0/contracts/derived-mapping.md` | 『workflow transitionからFR、GWT AC、screen、API、data、permission、notification、audit、testを同じIDで生成』の変換規則 |
| `vendor/workflow-requirements-engine-v1.1.0/contracts/workflow-to-requirement-contract.md` | 『L3: AI draft、PO approve』のL3契約コンパイル入出力仕様 |
| `vendor/workflow-requirements-engine-v1.1.0/contracts/runtime-orchestration-contract.md` | 『Runtime observation』（実績投影・confirmed requirement不変更） |
| `vendor/workflow-requirements-engine-v1.1.0/prompts/workflow-extraction-prompt.md` | 『既存Pythonとの接続』節のengine質問・workflow model変換の抽出プロンプト |
