# 7. Subagent HARNESS Capsule

「サブエージェントにHARNESSを保持させる」とは、長いpromptを複製することではありません。

- immutable capsule
- source/context digests（正本 docs/design/harness/L6-function-design/digest-canonicalization-authority.md、
  実装 src/runtime/digest.ts の canonicalJson/sha256Digest に従う）
- task/output/authority contract
- subagent_type/runtime（既存agent-guard allowlistとの対応）とis_fable_apex_subagent（advisor-fableのみtrue）
- resource budget
- checkpoint and resume
- parent-child trace
- retention and redaction
- independent verifier

を標準化することです。

Capsuleはagentの記憶ではなく、**実行可能な境界証明書**です。agent outputはclaimであり、trusted evidenceではありません。
