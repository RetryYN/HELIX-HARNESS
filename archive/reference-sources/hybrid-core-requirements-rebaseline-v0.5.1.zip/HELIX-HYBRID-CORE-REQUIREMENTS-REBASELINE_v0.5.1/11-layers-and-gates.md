# 11. L0-L14 / Gate統合

<!-- v0.5.1是正 LAYER-SCRUM-01: 各層責務からrequirements-catalog.yaml / acceptance-criteria.yamlの
     実在ID(HBR-*/HNFR-*/AC-*)へ逆引きできるよう「主要HBR/AC ID」列を追加した。全IDはpython3で
     requirements-catalog.yaml・acceptance-criteria.yamlに実在することを確認済み（self-check参照）。
     L8-L12は元表で1行に圧縮されていたため、golden parity/loop terminal/UX evidenceの3系統へ
     ID付きで分解した。既存文書に対応IDが見当たらない箇所は正直に『(未起票: v0.6で補完)』と記す。 -->

| Layer | Workflow/Hybrid Coreの責務 | Gate追加・強化 | 主要HBR/AC ID |
|---|---|---|---|
| L0 | 価値・自動化境界・Infinity Loop許容範囲 | value hypothesis / irreversible boundary | HBR-INF-004 (AC-INF-03), HBR-INF-005 (AC-INF-03), HBR-INF-006 (AC-INF-04), HBR-INF-016 (AC-INF-10) |
| L1 | 人が要求を作成、AI gap-check | chat/source trace、workflow候補、未決事項 | HBR-ELICIT-004 (AC-ELICIT-02), HBR-ELICIT-007 (AC-ELICIT-05), HBR-ELICIT-013 (AC-TRACE-01/AC-TRACE-02) |
| L2 | mock/操作から状態・異常・data要求を露出 | bounded 3 rounds、human convergence | HBR-ELICIT-005 (AC-ELICIT-03), HBR-DH-005 (AC-DH-05) |
| L3 | AIがFR/AC/workflow draft、PO承認 | transition completeness、GWT、test pair | HBR-ELICIT-008 (AC-ELICIT-06), HBR-ELICIT-009 (AC-ELICIT-06), HBR-WF-001 (AC-WF-01) |
| L4 | architecture、既存Python採用境界、Node責務、risk/allocation objective | original snapshot、disposition、no-big-bang-rewrite | HBR-CORE-009 (AC-PATCH-01), HBR-CORE-010 (AC-PATCH-02), HBR-INV-003 (AC-INV-03), HBR-ARCH-001 (AC-ARCH-01) |
| L5 | API/DB/event/protocol/capsule、staging/promotion詳細 | schema/transaction/idempotency/fallback | HBR-ARCH-005 (AC-ARCH-04), HBR-ARCH-013 (AC-PATCH-08), HBR-AGENT-001 (AC-AGENT-01) |
| L6 | file/function patch contract、task/resource/test oracle | golden parity、compat facade、Node/Python conformance、L8 unit design | HBR-CORE-011 (AC-PATCH-03), HBR-CORE-012 (AC-PATCH-04), HBR-CORE-014 (AC-PATCH-06) |
| L7 | 部分修正・adapter・Node実装 | Bun absence、patch scope、capsule/admission/evidence | HBR-CORE-013 (AC-PATCH-05), HBR-ARCH-002 (AC-ARCH-02), HBR-WF-014 (AC-INV-03) |
| L8 unit | file/function単位のoriginal-vs-patched parity | golden parity evidence | HBR-CORE-006 (AC-CORE-03), HBR-CORE-012 (AC-PATCH-04) |
| L9-L11 integration/system/UX | branch/loop/terminal状態の統合的parity | loop/terminal evidence、real-data UX evidence | HBR-WF-004 (AC-WF-03), HBR-WF-005 (AC-WF-04), HBR-DH-019 (AC-DH-17) |
| L12 acceptance | resource/crash耐性を含むacceptance evidence | resource/crash evidence | (未起票: v0.6で補完) |
| L13 | deployment smoke/monitoring | Linux primary、rollback to pinned source | HNFR-PLAT-001 (AC-PLAT-01), HBR-INV-009 (AC-INV-06), HBR-INF-008 (AC-INF-06) |
| L14 | operational/value/self-improvement feedback | Infinity Loop audit、patch effectiveness、L0 feedback | HBR-INF-001 (AC-INF-01), HBR-INF-003 (AC-INF-02), HBR-INF-016 (AC-INF-10) |

新gate番号を乱造せず、既存gateへtyped sub-checkを追加します。

## Scrum/PoCレーン バインド（v0.5.1是正 LAYER-SCRUM-02）

<!-- リポジトリ CLAUDE.md の Scrum / PoC ワークフロー（S0 backlog -> S1 plan -> S2 poc -> S3 verify ->
     S4 decide）を、Hybrid Core側の対応capability・要件・skill_packs/capability_familiesへ結線する。
     HBR-CORE-004（V-model 109文書 + Scrum 13文書 = 122文書カタログ保持）はこのレーンが載る文書集合の
     存在自体を保証するが、段階別のcapabilityバインドまでは検証しない（その限界はLAYER-SCRUM-03/
     minor findingとして別途記録済み、本節の対応範囲外）。inventory/hybrid-core-capability-map.yamlは
     design_document_families配下でV-model 109件・Scrum 13件の集計(vmodel_numbered/scrum_numbered)のみを
     保持し個別文書番号の台帳は持たないため、ここでは実在確認可能なcapability名(skill_packs/
     capability_families)とHBR/AC IDのみを結線対象とし、実在確認不能な個別文書番号は挙げない。 -->

| Scrumレーン | Hybrid Core責務 | 対応HBR/AC ID | 対応capability (inventory/hybrid-core-capability-map.yaml) |
|---|---|---|---|
| S0 backlog | 未収束事項をowner/decision layer/expiry/blocking impact付きで保存し、backlogの供給源とする | HBR-ELICIT-007 (AC-ELICIT-05) | skill_packs: scrum-authoring, scrum-story-splitting |
| S1 plan | 収束済みbacklogをUT-TDD由来のadmission tuple/receipt/atomic draftへ乗せてplanを確定する | HBR-WF-014 (AC-INV-03) | skill_packs: scrum-workflow, scrum-tailoring-judgement |
| S2 poc | human/agent/model/compute/budget/time/quota/licenseのresource poolとallocation policyでPoC実行枠を割り当てる | HBR-WF-009 (AC-ORCH-03), HBR-WF-010 (AC-ORCH-03) | capability_families.planning_and_execution: schedule, assign |
| S3 verify | golden behaviorとevidence-before-verdictでPoC結果を検証gateへ通す | HBR-CORE-006 (AC-CORE-03), HNFR-SEC-004 (AC-AUDIT-02) | skill_packs: scrum-acceptance-thinking, scrum-increment-review |
| S4 decide | 人が安全境界・破壊操作・cutoverの採否を決め、結果をL0価値仮説/Infinity Loopへfeedbackする | HBR-INF-006 (AC-INF-04), HBR-INF-016 (AC-INF-10) | skill_packs: scrum-tailoring-judgement |

対応する要件は`requirements/requirements-catalog.yaml`のHBR-SCRUM-001（priority: must）、検証は
`requirements/acceptance-criteria.yaml`のAC-SCRUM-01、traceabilityは`requirements/traceability.yaml`の
`HBR-SCRUM-001 -> AC-SCRUM-01`edge（type: verified_by）で機械追跡できる。
