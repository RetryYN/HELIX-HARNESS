# 17. HELIX Design HARNESS統合

## 17.1 目的

提示されたDesign HARNESS設計ベースを、Hybrid Python Coreの要件・設計・検出能力としてHELIX化する。
独立engine、独立V-model layer、UT adapter、別authoring DBは追加しない。

## 17.2 Continuity spine

```text
L1 Experience / Screen Requirement
  ↕ Workflow Requirements Skillで発火・状態・分岐を整理
L2 Prototype Agreement + Screen Ledger
  ↓ same semantic IDs
L3 Screen FR / AC / workflow transition
  ↓
L4 Pattern Contract + Product UI Profile
  ↓
L5 Frontend Binding
  ↓
L6 UI-M0..M7 Mission / Unit Oracle
  ↓
L7 Implementation + independently verified Mission Receipt
  ↓
L8-L9 Integration / System Verification
  ↓
L10 Real-data UX / Responsive / Motion / Accessibility Evidence
```

## 17.3 Core engine binding

Design HARNESS contractは`schemas/design-harness/`を機械契約として、既存Pythonへ直接bindingする。

- activation: UI/UX/FE/screen/browser signalを検出
- schema: Prototype、Ledger、Profile、Binding、Delta、Evidence
- spec: Region/Slot/Action/State/Binding/Mission ID
- trace: requirement→screen→binding→source/test→evidence
- impact: UI deltaのaffected requirement、binding、test
- schedule: L2/L4/L5/L6/L7/L10 obligation
- review: generic table、placeholder、false implemented claim、過剰motion
- build: ledger、diagram、coverage、agent digest

## 17.4 Hybrid document catalog binding

Design HARNESSは122文書catalogを置き換えず、既存slotへtyped contractを接続する。

| Design HARNESS contract | Hybrid document slot |
|---|---|
| Experience / Screen Requirement | 02 要求定義、43 要求・要件台帳 |
| Workflow / Screen transition | 19 ワークフロー定義 |
| Prototype Agreement / Screen Ledger | 04 基本設計、44 成果物index、33 trace規約 |
| Product UI Profile / Pattern | 72 フロントエンド、73 responsive、37 i18n/a11y |
| Frontend Binding | 72 frontend、23 I/O、39 event schema、21 logging |
| UI-M0..M7 / Unit Oracle | 06 unit test、24 logic、31 component/class |
| UX Evidence | 51 UI test、28 verification、49 AI artifact verification、109 QA |
| UI Change Delta | 14 issue/risk/decision、108 refactor |
| Typed spec / continuity | 97 trace closure、99 typed spec/detector |

typed contractは各文書のsidecarまたは`agent.defines`として登録し、別文書体系を並立させない。

## 17.5 Runtime boundary

Node runtimeが担当するのは、browser verification、screenshot/VRT、Git/GitHub、provider/subagent、
atomic promotion、DB transactionである。UX/FE contractの意味判定はPython Coreの単一正本を使う。

## 17.6 Completion

- `implemented`はUI-M0..M7のverified receiptから導出する。
- `ux_verified`はL10 real-data evidenceと人間reviewを必要とする。
- 画面数、route数、placeholder、generic tableは実装証拠にならない。
- G2合意、L1/L2収束、L3承認、L10 preference判断は人間のauthorityを維持する。

## 17.7 Charter対応表（v0.5.0是正、AUTH-003）

本パッケージの各章・`design-harness/`配下の要素が
`/home/tenni/HELIX-HARNESS/docs/design/helix/L0-charter/helix-charter_v0.1.md` §4の10本柱
（P0逸脱受け止め／P1自律走行エンジン／P2オーケストレーション／P3強い検証基盤／P4自動保守／
P5コンテキスト効率／P6 GitHub運用自動化／P7ハーネスメモリ／P8外部連携／P9 DB収束）の
どれに対応するかを明示する。対応が無い柱は「非対象」と明記し、無関係に同名ラベルを流用しない。

| charter柱 | 本パッケージ対応要素 | 対応関係 |
|---|---|---|
| P0 逸脱受け止め | 14-risks-and-open-decisions.md、decisions/decision-ledger.md | Design HARNESS内のcontradiction/riskをrisk ledgerへ受け止める経路として対応 |
| P1 自律走行エンジン | 12-migration-roadmap.md、source-material内PLAN-M（Phase-0..Phase-9） | Design HARNESS導入の段階実行フローとして部分対応（走行エンジン本体ではない） |
| P2 オーケストレーション | 07-subagent-harness-capsule.md、17.3 Core engine binding | Design HARNESS検出をsubagent capsuleへ接続する範囲で部分対応 |
| P3 強い検証基盤 | 17.6 Completion、schemas/design-harness/ux-evidence.schema.json | UI-M0..M7 verified receipt、L10 real-data evidenceとして対応 |
| P4 自動保守 | 非対象 | Design HARNESSは自動保守（doctor/自己修復)の対象範囲を持たない |
| P5 コンテキスト効率 | 非対象 | 本統合章はスキル注入・コンテキスト最適化を扱わない |
| P6 GitHub運用自動化 | 非対象 | Design HARNESS統合はGitHub運用自動化と直接の対応を持たない |
| P7 ハーネスメモリ | 非対象 | 本章はharness memoryへの直接書き込み契約を持たない |
| P8 外部連携 | 17.4 Hybrid document catalog binding | 既存122文書catalogとの接続という外部連携的側面で部分対応 |
| P9 DB収束 | 17.5 Runtime boundary、08-detection-system-database.md | Detection DBへのevidence集約という範囲でDB収束と部分対応 |

「非対象」と明記した柱について、本章の他ラベル（17.6 Completionの`implemented`/`ux_verified`等、
PLAN-M Phase-0..Phase-9）はcharter P0–P9と文字列衝突しない独自ラベルであり、上表に列挙した対応関係の
みがcharterとの結びつきを持つ。
