# 0. エグゼクティブ再基準化 — HELIX Design HARNESS統合

## 結論

（proposed、PO承認待ち）本ドキュメント内の暫定方針として、今回提示された二つの資産の関係を次のとおり提案する。
decision-ledger.md の対応する決定（D-001等）がstatus=confirmed/acceptedへ遷移するまでは確定事実として扱わない。

**ref enumeration gate実行済み・disposition未閉鎖**（是正UT-04）。`inventory/ut-tdd-ref-enumeration.json`へ
2026-07-18時点のbranch 8本、tag 0件、open/closed PR 89件を固定し、live branch 8/8を
`inventory/ut-tdd-ref-audit.yaml`へ結線した。authority statusがBLOCKEDでreview pending branchも残るため、
全資産の採用が確定したという完了断定は行わない（`coverage_boundary.is_disposition_closed: false`）。

```text
ハイブリッド設計ドキュメント v1 の既存Python
  = HELIXのコアエンジン基準実装

ut-tdd-design-harness-internalization-v0.1(2).zip
  = HELIX Design HARNESSへ変換する設計ベース

UNIVERSAL-WORKFLOW-REQUIREMENTS-SKILL v1.1.0
  = 要求ヒアリング・状態遷移化・設計判断補助

UT-TDD_AGENT-HARNESS
  = 抽出採用候補を得るための別製品・参考資産
```

Design HARNESSをUT-TDDからHELIXへ移植するのではない。提示されたDesign HARNESS設計を、
**HELIXのHybrid Python Coreが直接提供するネイティブ設計能力**へ変換・統合する。

## 正しい構造

```text
Human / PO Authority
        ↓
Workflow Requirements Skill v1.1
  発火・状態・分岐・ループ・終端・画面遷移を整理
        ↓
HELIX Hybrid Python Core
  ├─ Requirements / Typed Spec / Trace / Detection
  ├─ HELIX Design HARNESS
  │    ├ Prototype Agreement
  │    ├ Screen Ledger
  │    ├ Pattern / Product UI Profile
  │    ├ Frontend Binding
  │    ├ UI-M0..M7 Mission
  │    ├ UX Evidence
  │    └ UI Change Delta
  ├─ Schedule / Assignment / Review
  └─ Document / Diagram / Report Generation
        ↕ versioned contracts
TypeScript / Node Runtime
  CLI / Git / GitHub / browser verification / provider / subagent / atomic publish
        ↕
HELIX Detection System DB
  append-only event / evidence / finding / projection / Infinity Loop
```

Design HARNESSはPython Coreの前後に置く独立エンジンでも、UT固有のadapterでもない。
既存Pythonの`activation / schema / spec / trace / impact / schedule / review / build`を部分修正して実装する。

## v0.4.0からの訂正

- Design HARNESS ZIPを「HELIXの正本」ではなく**変換元設計ベース**と定義し直した。
- activeなHELIX要件からUTのCLI、DB、PLAN、role、path、製品境界を除外した。
- PR #65の未取得r27 parityをHELIX完成条件から除外し、参考証跡に降格した。
- Design HARNESSをHybrid Python Core内部のcapability familyとして再配置した。
- 122文書catalogの既存slotへDesign HARNESS契約をbindingした。
- Python 29ファイルのうち、Design HARNESSに関与する実装点を具体的に割り当てた。
