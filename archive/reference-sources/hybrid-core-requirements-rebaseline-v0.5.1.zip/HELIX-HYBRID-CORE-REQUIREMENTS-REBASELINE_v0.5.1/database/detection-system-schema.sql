PRAGMA foreign_keys = ON;

CREATE TABLE source_snapshots (
  source_snapshot_id TEXT PRIMARY KEY,
  source_kind TEXT NOT NULL CHECK(source_kind IN ('git_ref','pull_request','archive','conversation','library','generated_package')),
  locator TEXT NOT NULL,
  ref_name TEXT NOT NULL DEFAULT '',
  commit_sha TEXT,
  content_digest TEXT NOT NULL,
  observed_at TEXT NOT NULL,
  UNIQUE(source_kind, locator, ref_name, content_digest)
);

CREATE TABLE source_assets (
  source_asset_id TEXT PRIMARY KEY,
  source_snapshot_id TEXT NOT NULL REFERENCES source_snapshots(source_snapshot_id) ON DELETE RESTRICT,
  path TEXT NOT NULL,
  asset_kind TEXT NOT NULL,
  content_digest TEXT NOT NULL,
  size_bytes INTEGER NOT NULL CHECK(size_bytes >= 0),
  UNIQUE(source_snapshot_id, path)
);

CREATE TABLE asset_dispositions (
  disposition_id TEXT PRIMARY KEY,
  source_asset_id TEXT NOT NULL REFERENCES source_assets(source_asset_id) ON DELETE RESTRICT,
  decision TEXT NOT NULL CHECK(decision IN ('reuse_as_is','patch','wrap','split','replace','reject')),
  rationale TEXT NOT NULL,
  target_locator TEXT,
  decided_by TEXT NOT NULL,
  decided_at TEXT NOT NULL,
  evidence_digest TEXT NOT NULL,
  UNIQUE(source_asset_id)
);

CREATE TABLE authored_requirements (
  requirement_id TEXT PRIMARY KEY,
  source_asset_id TEXT REFERENCES source_assets(source_asset_id) ON DELETE RESTRICT,
  version TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('draft','confirmed','superseded','rejected')),
  statement TEXT NOT NULL,
  content_digest TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE workflow_events (
  workflow_event_id TEXT PRIMARY KEY,
  workflow_id TEXT NOT NULL,
  transition_id TEXT,
  event_type TEXT NOT NULL,
  previous_state TEXT,
  next_state TEXT,
  actor_id TEXT NOT NULL,
  input_digest TEXT NOT NULL,
  output_digest TEXT NOT NULL,
  occurred_at TEXT NOT NULL,
  sequence INTEGER NOT NULL,
  UNIQUE(workflow_id, sequence)
);

CREATE TABLE harness_capsule_events (
  capsule_event_id TEXT PRIMARY KEY,
  capsule_id TEXT NOT NULL,
  parent_capsule_id TEXT,
  event_type TEXT NOT NULL CHECK(event_type IN ('issued','checkpointed','resumed','completed','failed','expired','compacted')),
  capsule_digest TEXT NOT NULL,
  actor_id TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  occurred_at TEXT NOT NULL,
  sequence INTEGER NOT NULL,
  UNIQUE(capsule_id, sequence)
);

CREATE TABLE harness_capsule_current (
  capsule_id TEXT PRIMARY KEY,
  parent_capsule_id TEXT,
  state TEXT NOT NULL,
  capsule_digest TEXT NOT NULL,
  last_event_id TEXT NOT NULL REFERENCES harness_capsule_events(capsule_event_id) ON DELETE RESTRICT,
  updated_at TEXT NOT NULL
);

CREATE TABLE detection_findings (
  finding_id TEXT PRIMARY KEY,
  finding_type TEXT NOT NULL,
  severity TEXT NOT NULL CHECK(severity IN ('info','warning','important','critical')),
  status TEXT NOT NULL CHECK(status IN ('candidate','confirmed','routed','resolved','rejected','superseded')),
  source_snapshot_id TEXT NOT NULL REFERENCES source_snapshots(source_snapshot_id) ON DELETE RESTRICT,
  source_asset_id TEXT REFERENCES source_assets(source_asset_id) ON DELETE RESTRICT,
  detector_id TEXT NOT NULL,
  detector_version TEXT NOT NULL,
  detector_policy_digest TEXT NOT NULL,
  evidence_digest TEXT NOT NULL,
  route TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  resolved_by TEXT,
  residual_risk TEXT,
  CHECK(
    (status = 'candidate' AND resolved_by IS NULL AND residual_risk IS NULL)
    OR (status IN ('resolved','superseded') AND resolved_by IS NOT NULL AND residual_risk IS NOT NULL)
    OR (status IN ('confirmed','routed','rejected'))
  )
);

CREATE TABLE finding_events (
  finding_event_id TEXT PRIMARY KEY,
  finding_id TEXT NOT NULL REFERENCES detection_findings(finding_id) ON DELETE RESTRICT,
  sequence INTEGER NOT NULL,
  event_type TEXT NOT NULL,
  actor_id TEXT NOT NULL,
  payload_digest TEXT NOT NULL,
  occurred_at TEXT NOT NULL,
  UNIQUE(finding_id, sequence)
);

CREATE TABLE allocation_decisions (
  allocation_decision_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  policy_id TEXT NOT NULL,
  policy_version TEXT NOT NULL,
  input_snapshot_digest TEXT NOT NULL,
  candidates_json TEXT NOT NULL,
  selected_candidate TEXT,
  rejection_reasons_json TEXT NOT NULL,
  objective TEXT NOT NULL,
  verdict TEXT NOT NULL CHECK(verdict IN ('allocated','held','dead_letter','escalated')),
  decided_at TEXT NOT NULL
);

CREATE TABLE infinity_cycles (
  cycle_id TEXT PRIMARY KEY,
  level TEXT NOT NULL CHECK(level IN ('task','project','harness')),
  state TEXT NOT NULL,
  risk_class TEXT NOT NULL CHECK(risk_class IN ('observation','reversible_internal','semantic_contract','irreversible_high_impact')),
  worker_id TEXT NOT NULL,
  verifier_id TEXT NOT NULL,
  max_cycles INTEGER NOT NULL CHECK(max_cycles > 0),
  current_cycle INTEGER NOT NULL CHECK(current_cycle >= 0),
  terminal_reason TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  CHECK(worker_id <> verifier_id)
);

CREATE TABLE infinity_cycle_events (
  cycle_event_id TEXT PRIMARY KEY,
  cycle_id TEXT NOT NULL REFERENCES infinity_cycles(cycle_id) ON DELETE RESTRICT,
  sequence INTEGER NOT NULL,
  state TEXT NOT NULL,
  input_digest TEXT NOT NULL,
  output_digest TEXT NOT NULL,
  evidence_digest TEXT NOT NULL,
  verdict TEXT NOT NULL CHECK(verdict IN ('PASS','FAIL','UNCERTAIN','N/A')),
  occurred_at TEXT NOT NULL,
  UNIQUE(cycle_id, sequence)
);

CREATE TABLE improvement_candidates (
  improvement_id TEXT PRIMARY KEY,
  source_finding_id TEXT NOT NULL REFERENCES detection_findings(finding_id) ON DELETE RESTRICT,
  risk_class TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('candidate','observing','approved','rejected','implemented','verified','rolled_back')),
  proposed_change_digest TEXT NOT NULL,
  rollback_digest TEXT NOT NULL,
  human_approval_required INTEGER NOT NULL CHECK(human_approval_required IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE evidence_records (
  evidence_id TEXT PRIMARY KEY,
  subject_kind TEXT NOT NULL,
  subject_id TEXT NOT NULL,
  producer_id TEXT NOT NULL,
  verifier_id TEXT,
  evidence_kind TEXT NOT NULL,
  command TEXT,
  exit_code INTEGER,
  artifact_locator TEXT,
  artifact_digest TEXT NOT NULL,
  trusted INTEGER NOT NULL CHECK(trusted IN (0,1)),
  recorded_at TEXT NOT NULL
);

CREATE TRIGGER trg_evidence_records_detection_finding_fk
BEFORE INSERT ON evidence_records
WHEN NEW.subject_kind = 'detection_finding'
BEGIN
  SELECT RAISE(ABORT, 'evidence_records.subject_id must reference an existing detection_findings.finding_id when subject_kind=detection_finding')
  WHERE NOT EXISTS (SELECT 1 FROM detection_findings WHERE finding_id = NEW.subject_id);
END;

CREATE TRIGGER trg_evidence_records_detection_finding_fk_update
BEFORE UPDATE ON evidence_records
WHEN NEW.subject_kind = 'detection_finding'
BEGIN
  SELECT RAISE(ABORT, 'evidence_records.subject_id must reference an existing detection_findings.finding_id when subject_kind=detection_finding')
  WHERE NOT EXISTS (SELECT 1 FROM detection_findings WHERE finding_id = NEW.subject_id);
END;

CREATE TABLE audit_runs (
  audit_run_id TEXT PRIMARY KEY,
  audit_type TEXT NOT NULL,
  scope_digest TEXT NOT NULL,
  auditor_id TEXT NOT NULL,
  worker_id TEXT,
  verdict TEXT NOT NULL CHECK(verdict IN ('PASS','FAIL','UNCERTAIN')),
  findings_count INTEGER NOT NULL CHECK(findings_count >= 0),
  evidence_digest TEXT NOT NULL,
  recorded_at TEXT NOT NULL,
  CHECK(worker_id IS NULL OR auditor_id <> worker_id)
);

CREATE INDEX idx_source_assets_snapshot ON source_assets(source_snapshot_id);
CREATE INDEX idx_findings_status ON detection_findings(status, severity);
CREATE INDEX idx_finding_events_finding ON finding_events(finding_id, sequence);
CREATE INDEX idx_capsule_events_capsule ON harness_capsule_events(capsule_id, sequence);
CREATE INDEX idx_cycle_events_cycle ON infinity_cycle_events(cycle_id, sequence);
CREATE INDEX idx_evidence_subject ON evidence_records(subject_kind, subject_id);


CREATE TABLE design_screen_contracts (
  screen_id TEXT NOT NULL, revision INTEGER NOT NULL CHECK(revision > 0),
  design_lifecycle TEXT NOT NULL, implementation_lifecycle TEXT NOT NULL,
  prototype_digest TEXT NOT NULL, profile_id TEXT, updated_at TEXT NOT NULL,
  PRIMARY KEY(screen_id, revision)
);
CREATE TABLE design_frontend_bindings (
  binding_id TEXT PRIMARY KEY, screen_id TEXT NOT NULL, region_id TEXT NOT NULL,
  binding_digest TEXT NOT NULL, trace_digest TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE design_mission_receipts (
  receipt_id TEXT PRIMARY KEY, screen_id TEXT NOT NULL, revision INTEGER NOT NULL,
  worker_id TEXT NOT NULL, verifier_id TEXT NOT NULL, missions_json TEXT NOT NULL,
  evidence_digest TEXT NOT NULL, implemented INTEGER NOT NULL CHECK(implemented IN (0,1)),
  recorded_at TEXT NOT NULL, CHECK(worker_id <> verifier_id)
);
CREATE TABLE design_ux_evidence (
  ux_evidence_id TEXT PRIMARY KEY, screen_id TEXT NOT NULL, revision TEXT NOT NULL,
  families_json TEXT NOT NULL, evidence_digest TEXT NOT NULL, human_verdict TEXT NOT NULL,
  recorded_at TEXT NOT NULL
);
CREATE TABLE design_change_deltas (
  delta_id TEXT PRIMARY KEY, screen_id TEXT NOT NULL, status TEXT NOT NULL,
  route_mode TEXT NOT NULL, payload_digest TEXT NOT NULL, expiry_gate TEXT, updated_at TEXT NOT NULL
);
CREATE INDEX idx_design_binding_screen ON design_frontend_bindings(screen_id);
CREATE INDEX idx_design_receipt_screen ON design_mission_receipts(screen_id, revision);
CREATE INDEX idx_design_ux_screen ON design_ux_evidence(screen_id, revision);
