# HELIX Detection System Database

Design HARNESS関連tableはHELIX Hybrid Python Coreが評価したcontract/evidenceのprojectionである。

- `design_screen_contracts`
- `design_frontend_bindings`
- `design_mission_receipts`
- `design_ux_evidence`
- `design_change_deltas`

authoring sourceはPython Coreが読むHELIX contract files。DBはappend-only eventとrebuildable viewであり、
Design HARNESSを独立DB製品にしない。

## detection_findings.evidence とevidence_recordsの対応

finding.evidence[]の各要素は、evidence_recordsのうちsubject_kind='detection_finding' AND subject_id=finding_idに
該当する行へ1:1対応するN行として永続化され、detection_findings.evidence_digestは当該evidence_records集合を
正規化結合した合成digestである。Nodeがfinding受理時にevidence_records各行を書き込み、evidence_digestを再計算して
一致検証した上でdetection_findingsへ書き込む。JSON evidence[]配列とDB上の複数行の対応はsubject_kind/subject_id経由の
evidence_records JOINが唯一の正本であり、evidence_digest単独ではevidence[]を復元できない。参照整合性は
`trg_evidence_records_detection_finding_fk`トリガーでDB層（Node application層だけでなくSQLiteエンジン自体）で強制する。
