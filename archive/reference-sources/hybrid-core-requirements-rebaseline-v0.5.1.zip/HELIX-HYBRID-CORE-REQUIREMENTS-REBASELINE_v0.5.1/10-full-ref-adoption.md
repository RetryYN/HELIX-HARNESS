# 10. Full-ref Adoption

**ref enumeration gate実行済み・disposition未閉鎖**（是正UT-04）。
`scripts/generate-ut-tdd-ref-enumeration.py`でGitHubのbranch、tag、open/closed PR head・merge情報を直接列挙し、
`inventory/ut-tdd-ref-enumeration.json`へ固定した。`validation/verify-full-ref-adoption-status.py`はlog不在、
live branch欠落、SHA不一致、open PR head欠落をfail-closeする。authority statusがBLOCKEDでreview pending branchも
残るため`coverage_boundary.is_disposition_closed: false`を維持し、以下は暫定方針として読む。

既存資産の採用は「mainをgrepした」だけでは閉じません。Git refs、archive、uploads、generated assetsに加え、Hybrid Pythonはfile/function単位で棚卸しします。

Python adoptionの既定は保存的です。

```text
reuse_as_is → patch → wrap → split → replace/reject
```

右へ進むほど、必要なevidenceとapprovalを強くします。

PR #64はclosed admission tuple、atomic draft、receipt、journal、diff fenceを持つためNode runtimeへ`split`採用を暫定方針とします（`adopt_with_hardening_provisional_pending_receipt`、enumeration gate通過前）。Bun依存と現行path前提を外し、domain contractを抽出します。

PR #54はmainよりahead 0であり、code adoptionは`reject`方針を暫定維持、監査履歴は保持します（enumeration gate通過前は確定closureとしない）。
