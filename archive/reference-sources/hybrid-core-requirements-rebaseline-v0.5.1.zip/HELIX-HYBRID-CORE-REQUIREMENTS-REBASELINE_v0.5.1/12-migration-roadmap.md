# 12. Migration Roadmap

## Slice 0 — Rebaseline freeze

- 本requirements/ADR一式全体を確定させる前に、`docs/plans/`配下へ`plan_id`・`kind`・`layer`・`status`・
  `dependencies`・`review_evidence`を備えたPLANを起票し、既存の確定PLAN/ADR（ADR-009等）と抵触する決定には
  `supersedes:`を宣言する。宣言が欠落した場合はconfirmedへ遷移させない。
- 本requirements/ADRを承認
- 元ZIPと29 Python file SHAをpin
- 大規模rename/relocation/new replacement coreをfreeze

## Slice 1 — Baseline capture

- existing Python selftest/check/coverage/scheduleを再実行
- generated workbook/Markdown/diagram/finding/traceのgolden setを固定
- known warnings、OS assumptions、global/cwd、subprocess、write pathsを記録

## Slice 2 — File/function disposition

- 29 Python filesを`reuse_as_is / patch / wrap / split / replace / reject`へ分類
- function、change scope、compatibility oracle、rollbackを登録
- unclassified source 0をgate化

## Slice 3 — Minimal Python patch wave

- unclosed file handle修正
- cp932/Windows console副作用のterminal adapter化
- Linux font/path/process対応
- generated outputをallowlisted stagingへ制限
- old CLI/pathをcompatibility facadeとして保持

## Slice 4 — Selective split and bridge

- `build/schedule/assign/review/impact/diff/trace`等のI/Oとpure logicを必要箇所だけ分離
- 対象commandへJSON/NDJSON modeを追加
- 全tool一括RPC化はしない

## Slice 5 — Shared contracts

- schemas/DDL/protocol
- Python/Zod conformance
- compatibility versioning

## Slice 6 — Node de-Bun

- npm/Node scripts
- node:sqlite only
- Node snapshot runner
- Linux full CI
- Python staging outputのatomic promotion

## Slice 7 — Detection DB

- source/finding/evidence/capsule/infinity/Python patch tables
- transaction/idempotency/fault tests
- full rebuild

## Slice 8 — Workflow judgment adapter

- v1.1 vendor pin
- L1/L2 read-only interview
- L3 compiler
- existing Python schema/trace/buildへのadapter

## Slice 9 — HARNESS Capsule / PR64 adoption

- capsule lifecycle
- plan admission tuple/receipt/diff fence
- Bun-free tests

### 適用順序（roster: Claude 17種 + Codex 3種 = 計20 subagent_type）

1. まずClaude側fable apex単独（`advisor-fable`）でcapsule発行を先行導入し、conformance suiteを安定させる。
2. 次にClaude側の残り16種（`fe-lead`, `fe-ui`, `pmo-sonnet`, `pmo-haiku`, `pmo-project-explorer`,
   `pmo-project-scout`, `pmo-tech-docs`, `pmo-tech-fork`, `pmo-tech-news`, `refactor-scout`,
   `pdm-tech-innovation`, `pdm-marketing-innovation`, `pdm-innovation-manager`, `code-reviewer`,
   `security-audit`, `qa-test`）へ順次展開する。
3. 最後にCodex側3種（`default`, `explorer`, `worker`）へ展開する。

### Slice 0-8 との共存規定

Slice 0-8の間（capsule未実装）は既存 `.claude/hooks/agent-guard.ts`（SUBAGENT_ALLOWLIST /
DELEGATION_BRIEF_MARKERS / FABLE_APEX_SUBAGENTSチェック）を唯一の正本gateとする。capsule導入後は
capsule.scope.subagent_type/runtimeのスキーマ整合チェック（HBR-AGENT-016）をagent-guard hookの追加
検証として二重化せず統合する。責務分離: capsule発行前チェックはagent-guardが担い、capsule内容の
正当性はcapsule schema/digest検証が担う。

### ロールバック手順

capsule発行がconformance suiteを満たさない場合、当該subagent_typeのcapsule必須化フラグを
individually disableし、既存prompt-only経路へfallbackできることをフラグ管理で明記する。

## Slice 10 — Infinity Loop / Dogfood

- finding routing、independent audit、rollback
- HELIX requirements変更とPython patch loopを自己適用

## Slice 11 — Multi-OS/distribution cutover

- Linux full release
- macOS/Windows smoke
- old Bun entrypoint retirement
- Python path relocationはparity、consumer影響、approvalが揃った場合だけ別PLANで判断
