# 3. 既存資産棚卸し

旧HELIX（ai-dev-kit-vscode）は個別機能ソースの正本であり、棚卸し台帳は`docs/migration/helix-source-inventory.md`
（snapshot destination=`vendor/helix-source/`、copied files=1451、約12.2MiB）と`docs/migration/helix-porting-map.md`
を正本として引用する（`01-authority-and-source-order.md`参照）。

## Hybrid core

- archive: `ハイブリッド設計ドキュメントv1-fixed.zip`（sha256=`9c547ba8bc9eaf3a12f27254fd3eb6d04b37fb8c899f13d56ceb0d2cff179fb3`、file entries=703、実作業環境で実際に到達可能な確定archive。旧宣言filename『ハイブリッド設計ドキュメント_v1(1).zip』／sha256=`fd8854603fe908e9b3a4cab00952f1efdecafaf655a6d25a2c6cc64be9632f6f`は到達不能なため参照を差し替え済み）
- files: 703（`inventory/hybrid-core-files.csv`のデータ行数と一致）
- authored: 276
- generated/cache: 439
- Python source: 29
- Python bytecode/cacheを含むpython_core category: 40
- skill packs: 15
- structural findings: 0
- coverage: 100%（archive実体・sha256・file entries数の再照合が完了したため確定claimとして扱う。再照合未完了の間はdraft/unverifiedと明記すること）
- known defect: unclosed file handleによるResourceWarning

完全なfile/digest台帳は`inventory/hybrid-core-files.csv`です。改行コード: LF固定。sha256列は64桁固定長であり末尾に`\r`を含まない。Python 29 filesの部分修正方針は`inventory/python-partial-modification-ledger.yaml`に記録します。

## HELIX-HARNESS 現行リポジトリ既存資産（追補）

- `.claude/agents/`: 21ファイル（allowlist済みsubagent定義。正本=`src/runtime/agent-guard-policy.ts`の`SUBAGENT_ALLOWLIST`）
- `.claude/hooks/`: 4ファイル（agent-guard.ts, git-command-guard.ts, session-log.ts, work-guard.ts）
- `.helix/teams/`: example-review-team.yaml（`helix team run`定義）
- CLI: `src/cli.ts`, `src/cli/` 配下（helix runtime CLIエントリ）
- DB projections: `harness.db`（`src/state-db/projection-writer.ts`経由、PLAN-L7-44-harness-db-master）と asset-drift/rule-drift 検査機構

出典・突合せ台帳として`docs/migration/internal-asset-inventory.md`を明示引用する。棚卸し対象はzipアーカイブと
UT-TDDドナー参照のみに閉じず、Hybrid core/Workflow Engine/UT-TDD棚卸しと並列カテゴリとして本節を扱う。

## Python adoption rule

全Python sourceを初期値`rewrite`にはしません。file/function単位に、次の6分類を必須とします。

- `reuse_as_is`
- `patch`
- `wrap`
- `split`
- `replace`
- `reject`

元path、元digest、変更範囲、compatibility oracle、rollback sourceが無いrowは採用決定として無効です。

## Workflow Engine

- archive SHA-256: `b6fd08f5054930dde8379969bf9a84cb21270d1b7bac8e87be3bc243ad425d26`
- vendor sourceはbyte pinし、既存Pythonを直接改変するmergeではなくadapter/wrapperで利用

## UT-TDD

- main: `86b581c...`
- open PR #64: `work/drive-plan-guard`, mainより10 commits ahead、55 files
- closed-unmerged PR #54: mainよりahead 0、固有採用なし
- PR #65: design harness internalization governanceをmerged
- A-187: checked ZIP 109文書の全件乖離監査

詳細は`inventory/ut-tdd-ref-audit.yaml`と`requirements/source-disposition.yaml`です。
