# 14. Risks / Open Decisions

## R1 Big-bang rewrite

新packageへ全Pythonを移すと、既存の文書生成・trace・Excel出力の暗黙契約を失う。

対策: 元source pin、file/function disposition、golden-before-patch、old facade保持、slice単位rollback。

## R2 二言語drift

対策: shared schema、contract test、golden vectors。Python/Zodを二重手書きしない。

## R3 SQLite concurrent writer

対策: 初期はNode single writer。Python直接writerはconformance/fault suite通過後のみ。

## R4 部分splitによる互換崩れ

対策: original path/CLIをfacadeとして残し、内部抽出だけを行う。output digestまたは構造parityをgate化する。

## R5 自己改善暴走

対策: risk class、worker/verifier分離、cycle/budget breaker、semantic/irreversible human gate。

## R6 全ref scanコスト

対策: commit/blob cache、merge-base incremental scan、source snapshot digest、changed refs only。

## R7 Windows互換後退

LinuxをcanonicalにするがWindowsを捨てない。Windows固有処理はcompat adapterへ隔離し、smokeを維持する。

## Open decisions

- 最終product/repository name（D-ID無し）
- Python source pathを恒久保持するか、parity後に段階移設するか（関連: D-005, decisions/decision-ledger.md）
- Python package publishの有無（D-ID無し）
- Node package managerをnpm固定にするかpnpmを許可するか（D-ID無し）
- DB single writerを恒久化するか将来service化するか（D-ID無し。R3参照）
- old Bun CLIの互換期間（関連: D-007, decisions/decision-ledger.md）
- branch-only private refsのscan権限/credential model（D-ID無し）
