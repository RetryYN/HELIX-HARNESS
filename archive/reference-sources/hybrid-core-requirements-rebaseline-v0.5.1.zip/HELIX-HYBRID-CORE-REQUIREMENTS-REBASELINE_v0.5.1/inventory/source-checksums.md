# Source Checksums

| source | locator | SHA-256 |
|---|---|---|
| hybrid archive | `ハイブリッド設計ドキュメントv1-fixed.zip` | `9c547ba8bc9eaf3a12f27254fd3eb6d04b37fb8c899f13d56ceb0d2cff179fb3` |
| workflow engine archive | `UNIVERSAL-WORKFLOW-REQUIREMENTS-SKILL_v1.1.0.zip` | `b6fd08f5054930dde8379969bf9a84cb21270d1b7bac8e87be3bc243ad425d26` |

## Git refs observed

- UT-TDD main: `1839fa71` (observed 2026-07-17; supersedes prior pin `86b581c12121936180047b6f908bba832e5bbbda`
  observed 2026-07-15, see inventory/ut-tdd-ref-audit.yaml refs[main].superseded_snapshot — SRC-FRESH-02是正)
- UT-TDD PR64 head: `87bc2879b81fb258a66d863d3fc2e810f66654e3`
- UT-TDD PR54 head: `c163e6e5d4ec41c8b5192355e10cc5cc88102e50`
- UT-TDD PR65 merge: `ce87b9696e9529951137fbd184930263f12de66c`
