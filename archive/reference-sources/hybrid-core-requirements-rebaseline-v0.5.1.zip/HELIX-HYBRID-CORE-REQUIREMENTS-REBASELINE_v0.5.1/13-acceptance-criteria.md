# 13. Acceptance Criteria

機械化可能な受入条件を`requirements/acceptance-criteria.yaml`へ119件定義しました（`count: 119`、`acceptance_criteria`リスト実要素数119と一致。`validation/package-validation-report.json`の`catalog_counts`チェック実測値と揃える。v0.5.0是正F1でAC-TRACE-02を追加し116→117、その後の是正で117→118、LAYER-SCRUM-02で118→119。v0.5.1是正一覧は`20-v0.5.1-errata.md`を参照）。

v0.5.1是正（INTERNAL-CONSISTENCY-02）: AC-TRACE-02はv0.5.0時点でどの要件の`verification`欄からも参照されず、`requirements/traceability.yaml`にもedgeが無い孤立ACだった。`requirements/requirements-catalog.yaml`のHBR-ELICIT-013（chat trace、CHAT-017/CHAT-021由来）の`verification`へAC-TRACE-02を追加し、`traceability.yaml`へ`CHAT-021→HBR-ELICIT-013`（refined_into）・`HBR-ELICIT-013→AC-TRACE-02`（verified_by）のedgeを追加することで孤立を解消した。

重点条件:

1. 元archiveと29 Python file digestがrollback baselineとして固定される
2. 全Python file/functionが6分類され、未分類0になる
3. greenfield全面再実装や無承認の物理移設を検出する
4. patch前にgolden output/finding/traceが固定される
5. 部分修正後も旧path/CLI facadeと主要出力が互換である
6. Pythonはstaging/generatedだけへ書き、Nodeがatomic promotionする
7. Bun未導入のLinux clean checkoutでfull gateが完走する
8. Python selftest/check/coverageがResourceWarning 0で通る
9. L1/L2 AI surfaceはno-writeで、人が収束を宣言する
10. capsuleなしのsubagent起動、worker自己approvalを拒否する
11. DBを削除してsource/eventから同一projectionを再構築できる
12. Infinity Loopがrisk/stop/rollback/human boundaryを守る
13. all refs/assetsにdispositionが付き、未確認0になる
14. chat requirementからevidenceまでtrace orphanがない
15. charter P0–P9のラベルと、本パッケージ内の他フェーズ番号ラベルが文字列として衝突しないことを
    grep等で機械確認できる（例: `grep -rn 'P[0-9] ' <package>` の出力を目視分類し、17-design-harness-integration.md
    §17.7の対応表に列挙されたP0–P9以外の出現がPLAN-M固有prefix付きであることを確認する。v0.5.0是正AUTH-003）
16. chat要求蒸留のprovenance（上流割当根拠）に欠落がない（`inventory/chat-requirements-provenance.yaml`が
    `inventory/chat-requirements.yaml`の全CHAT-IDと1:1対応することをAC-TRACE-02で機械検証する。※本項目15行目とは異なり
    非normative — 機械検証対象は`requirements/acceptance-criteria.yaml`と`validation/package-validation-report.json`の
    数値一致およびAC-TRACE-02本文のみであり、本箇条書き自体はprose要約に過ぎない。v0.5.0是正F1）
