# 2. コアエンジン定義

（proposed、PO承認待ち）本ドキュメント内の暫定方針として次を提案する。decision-ledger.md の
対応する決定（D-001, D-002等）がstatus=confirmed/acceptedへ遷移するまでは確定事実として扱わない。

HELIXコアエンジンの基準実装は`hybrid-docgen/tools/*.py`（Python意味コア、ADR-010）である。要件抽出・typed spec・
trace・検出・impact・review・文書生成の意味判断・生成はPythonが恒久正本であり、TS/Nodeへの再実装義務は課さない
（reject-for-TS-reimplementation既定はADR-010で廃止）。各ファイルはcapability class（source_atomization／
document_engine／detector／product_data／analysis）で棚卸し分類し、分類できない新規機能はADR改定によるclass追加で
扱う。TypeScript/Nodeは実行境界（transactional boundary）として`harness.db`・Git/GitHubへのcommitと外部副作用のみを
単一の書き込み口で担い、Pythonの意味判断を複製・代行しない。動作しているPython意味コアのbulk TS再実装は高リスク
行為として原則禁止（PO個別承認時のみ）。

## Design HARNESSの位置

Design HARNESSは、コアエンジンに追加されるcapability familyである。

層別同格（layered authority、ADR-010決定4）。一方を他方の全面上位とする描画はしない。
意味判断の正本＝Python、実行（commit／外部副作用）の正本＝Nodeであり、Pythonの提案出力を
Nodeがschema／digest／authority policyで再検証してからcommitへ進める片方向の直列化点として
両者を並置する。

```text
Python 意味コア（semantic core、ADR-010: 意味判断の正本）
├ requirements and catalog
├ typed spec and trace
├ detection and impact
├ schedule and review
├ generation and export
├ design_harness
│  ├ experience_contract
│  ├ prototype_agreement
│  ├ screen_ledger
│  ├ pattern_profile
│  ├ frontend_binding
│  ├ implementation_mission
│  ├ ux_evidence
│  └ change_delta
├ source_atomization
├ document_engine
├ detector
├ product_data
└ analysis
        │
        │  proposal bytes（schema／digest／authority policyによるNode側再検証を経てのみ確定）
        ▼
Node 実行境界（transactional boundary、ADR-010: 実行の正本）
├ harness.db commit（append-only events／projections、唯一のtransaction writer）
├ Git / GitHub commit
├ 外部副作用（network egress等）
└ CLI（`helix`エントリポイント）
```

新しい別プロセスや別authoring DBを作らない。既存Python moduleへ以下の責務を分配する
（`capability_class` / `versioned_contract_id` は `inventory/python-partial-modification-ledger.yaml` を正本とする）。

- `activation.py`: Design HARNESS適用判定 — capability_class: analysis / versioned_contract_id: design-harness-activation-v1
- `schema_check.py`: six typed contractsのschema validation — capability_class: document_engine / versioned_contract_id: design-harness-schema-check-v1
- `spec_types.py / spec_check.py`: Design HARNESS kindと不変条件 — capability_class: document_engine / versioned_contract_id: design-harness-spec-check-v1
- `derive_traces.py / spec_trace.py`: L1→L10 continuity edge — capability_class: analysis / versioned_contract_id: design-harness-spec-trace-v1
- `consistency.py`: L2 implementation-neutral / profile isolation / claim整合 — capability_class: analysis / versioned_contract_id: design-harness-consistency-v1
- `scope.py / impact.py / diff_report.py`: UI Change Deltaと影響閉包 — capability_class: detector / versioned_contract_id: design-harness-impact-v1
- `schedule.py / assign.py`: UI-M0..M7 readinessと担当・資源配分 — capability_class: product_data / versioned_contract_id: design-harness-schedule-v1
- `review.py`: Design/FE/UX adversarial review — capability_class: analysis / versioned_contract_id: design-harness-review-v1
- `agent_docs.py / agent_meta.py`: subagent HARNESS Capsuleへの契約注入 — capability_class: document_engine / versioned_contract_id: design-harness-agent-docs-v1
- `build.py / md_export.py / render.py / diagram_dsl.py`: ledger・図・証跡view生成 — capability_class: document_engine / versioned_contract_id: design-harness-build-v1
- `validate.py / hook_gate.py / selftest.py`: gate・doctor・回帰 — capability_class: detector / versioned_contract_id: design-harness-validate-v1

TypeScript / Nodeは外部副作用とruntimeに加え、上記全moduleのproposal出力に対するschema／digest／authority policy
再検証とcommit判断を担当する（唯一のtransaction writer）。Design HARNESSの意味判断そのものはPython moduleが提案する
proposalに留め、Node側の再検証を経ずに確定させない。
