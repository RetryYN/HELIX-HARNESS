# 4. Target Architecture

```text
Human Requirements Authority
          ↓
Workflow Requirements Skill v1.1
          ↓
┌──────────────── HELIX Hybrid Python Core ────────────────┐
│ requirements / catalog / typed spec / trace / detection │
│                                                         │
│ HELIX Design HARNESS capability                         │
│ Prototype → Profile → Binding → Mission → UX Evidence   │
│                                                         │
│ schedule / assignment / review / generation             │
└───────────────────────┬─────────────────────────────────┘
                        │ versioned JSON/YAML/NDJSON
                 TypeScript / Node Runtime
          CLI / Git / GitHub / Browser / Provider / Agent
                        │
                 Detection System DB
        event / receipt / evidence / finding / projection
```

## Design HARNESSはCore内部

Design HARNESSはWorkflow SkillとPython Coreの間に置くmiddlewareではない。
Workflow Skillが整理した要求・画面遷移を受け、Python Core自身がDesign HARNESS contractを生成・検査・追跡する。

## Promotion boundary

```text
Python evaluates and generates staging artifacts
→ Node validates contract digest and authorization
→ Node performs browser/provider/Git side effects
→ evidence and receipt are appended
→ Python/DB projection re-evaluates continuity
```

## UT reference boundary

UT-TDDから採るものは実装パターンと検出知見だけであり、active runtime namespaceへは入れない。
