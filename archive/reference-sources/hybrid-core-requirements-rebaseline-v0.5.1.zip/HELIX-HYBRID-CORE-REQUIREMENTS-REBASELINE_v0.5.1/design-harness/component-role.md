# Design HARNESSの役割

Design HARNESSは描画ツールではなく、次の三契約を連続させる。

- Experience Contract: 誰が、何を、どの頻度・重要度で達成するか
- UI Contract: 何を、どの順序・状態・responsive/motion制約で見せるか
- Frontend Contract: data、state owner、event、permission、logging、errorをどう成立させるか

接続主キーは`screen_id / region_id / slot_id / action_id / state_id / binding_id`。
framework、component class、file pathは意味主キーにしない。
