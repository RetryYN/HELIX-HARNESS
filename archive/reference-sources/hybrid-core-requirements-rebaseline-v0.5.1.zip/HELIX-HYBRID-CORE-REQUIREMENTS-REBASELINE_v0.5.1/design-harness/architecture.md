# UX–FE Continuity Architecture

## 三契約

- Experience Contract: 利用者、目的、頻度、重要度、事業成果。
- UI Contract: Region/Slot、情報優先順位、state、responsive、motion。
- Frontend Contract: data、state owner、event、permission、logging、error boundary。

接続主キーは`screen_id / region_id / slot_id / action_id / state_id / binding_id`。
component classやfile pathを意味主キーにしない。

## Workflow mapping

- current_state → visual state
- trigger → action intent / UI event
- condition → visibility / validation / permission
- action → frontend event contract
- next_state → screen/view transition
- loop → retry/rework/refresh
- terminal → success/cancel/failure/expiry UX
