# HELIX Design HARNESS

HELIX Design HARNESSは、利用者価値、画面仮説、フロント成立条件、実装、実利用検証を
同じsemantic IDで閉じる、**HELIX Hybrid Python Coreのネイティブ設計能力**である。

Design HARNESS設計ベースのraw 53資産は`source-material/design-harness-base-v0.1/`へbyte-preservedで保持する。
これはprovenanceと比較のための変換元であり、active HELIX runtimeや要求の正本ではない。

Active contract:

- `schemas/design-harness/`
- `templates/design-harness/`
- `design-harness/python-core-binding.yaml`
- `design-harness/hybrid-document-binding.yaml`
- HELIX authored L1-L6 artifacts
- Detection DBはprojectionのみ
