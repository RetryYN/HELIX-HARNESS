# Existing Hybrid Python / Node mapping

本章の境界定義はADR-009-node-python-linux-runtime.md（存続条項）およびADR-010-python-semantic-core-node-commit-boundary.md
（部分改定、accepted）に従う。ADR-009/ADR-010いずれかが改定された場合、本章とHBR-ARCH-*群は同一PLANで追補されなければ
ならない。

## ADR-010追補（層別同格・呼称改定）

- 下表の「Existing Python」列はPython意味コア（semantic core、ADR-010）の実装であり、意味判断・生成の正本として
  TS/Nodeへの再実装義務を負わない。表内の各moduleはNodeに従属する処理ではなく、Nodeと層別同格（layered authority）の
  意味判断責務として扱う。
- Nodeが担当する下段（Playwright、axe-core、Lighthouse、Git/GitHub、SQLite transaction等）は実行境界
  （transactional boundary）の正本であり、Python意味コアの出力をschema／digest／authority policyで再検証してから
  commitへ進める直列化点として並置される（ADR-010決定4）。

| Existing Python | Design HARNESS responsibility |
|---|---|
| activation.py | UI scopeとsignalからoverlay候補を返す |
| schema_check.py | Design HARNESS schema検査 |
| spec_check.py | lifecycle/mission/receipt/profile制約 |
| spec_trace.py / derive_traces.py | L1→L10 semantic edge |
| scope.py / impact.py | UI Change Delta影響分析 |
| schedule.py / assign.py | layer obligation、role、readiness |
| review.py / consistency.py | false implemented claimとdrift検出 |
| build.py / render.py | read-only ledger/diagram/report生成 |
| agent_docs.py | HARNESS Capsuleへdesign contractを注入 |

NodeはPlaywright、axe-core、Lighthouse、snapshot/pixel comparison、Git/GitHub、provider、
canonical promotion、SQLite transactionを担当する。chrome-devtools-mcpはagentic補助でありCI決定経路へ入れない。
