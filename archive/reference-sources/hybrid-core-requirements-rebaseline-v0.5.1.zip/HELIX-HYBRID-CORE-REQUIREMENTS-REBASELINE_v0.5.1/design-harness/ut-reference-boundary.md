# UT reference boundary

UT-TDD_AGENT-HARNESSは別製品である。

利用してよいもの:

- detector / ledger / receipt / atomicityの実装パターン
- review evidenceとfailure fixture
- branchを含む採用候補の棚卸し結果

直接持ち込まないもの:

- `ut-tdd` CLI、`.ut-tdd/`、`harness.db`
- UTのPLAN、requirement ID、role、approval model
- TypeScript/Bun-only architecture
- UT consumer/team前提

PR #65は、Design HARNESS内蔵化を検討した参考証跡であり、HELIX Design HARNESSの正本でも
exact parity targetでもない。
