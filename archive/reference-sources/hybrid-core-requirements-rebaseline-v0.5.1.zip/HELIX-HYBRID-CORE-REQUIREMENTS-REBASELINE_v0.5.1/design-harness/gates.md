# Design HARNESS gate integration

新Gate番号は作らず既存Gateへsub-checkを追加する。

- G2: prototype contract、screen ledger、L2 implementation-neutral boundary
- G4: pattern/profile/token、product value isolation
- G5: frontend binding orphan 0
- G6: UI-M0..M7 plan/oracle/readiness
- G7: mission receipt、false implemented claim防止
- G10: real-data、responsive、motion、a11y、continuity、人間評価
- 横断: semantic trace、delta routing、source reconciliation

`implemented`と`ux_verified`は別状態である。
