# Runtime / Detection DB boundary

## Python Core

要求意味、Design HARNESS schema、不変条件、trace、impact、readiness、review判定を所有する。

## TypeScript / Node

browser automation、VRT、screenshot、Git/GitHub、provider/subagent、atomic publish、transactionを所有する。
Pythonと同じDesign HARNESS判定を再実装しない。

## Detection DB

contract digest、mission receipt、UX evidence、finding、delta、cycle eventを投影する。
DBはauthoring sourceではなく、rebuild可能なread modelである。
