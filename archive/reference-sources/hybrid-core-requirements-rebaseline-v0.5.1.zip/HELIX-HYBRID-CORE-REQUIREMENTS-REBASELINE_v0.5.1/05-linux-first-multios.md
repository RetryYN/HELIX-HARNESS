# 5. Linux-first Multi-OS

Linuxをcanonical execution semanticsとします。ただし既存PythonにあるWindows互換処理を一括削除せず、core pathから隔離してcompatibility adapterとして残します。

- process/signal/file permission/symlink/case-sensitive pathをLinux基準で設計
- Python commandは既存`python3 tools/<tool>.py` facadeを保持し、対象commandから`python3 -m`/JSON modeを追加
- POSIX wrapperをcanonical、PowerShellは薄いcompat adapter
- `util.py`のcp932 stdout副作用は局所patchし、terminal encoding adapterへ移す
- `diagram_dsl.py`のWindows font pathはoptional candidateへ降格し、Linux font discoveryをprimaryにする
- CI full gateはLinux。macOS/Windowsは互換性smoke
- rootless containerで再現可能

Nodeのproductionランタイムは Node.js 24 LTS単一系列とし、`>=24.15.0 <25` を minimum とする（ADR-009準拠）。24系より前のLTS系列は canonical/compatibility いずれの gate にも含めない。`node:sqlite` へ移行しBun分岐を除去する。
