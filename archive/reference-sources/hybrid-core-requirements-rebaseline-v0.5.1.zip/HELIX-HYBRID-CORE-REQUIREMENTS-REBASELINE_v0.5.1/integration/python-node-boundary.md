# Existing Python / Node Boundary Contract

本章の境界定義はADR-009-node-python-linux-runtime.md（存続条項）およびADR-010-python-semantic-core-node-commit-boundary.md
（部分改定、accepted）に従う。ADR-009/ADR-010いずれかが改定された場合、本章とHBR-ARCH-*群は同一PLANで追補されなければ
ならない。

## ADR-010追補（層別同格・呼称改定）

- **呼称改定**: 本章以下で「Python proposal worker」という従属的呼称は廃止し、「Python意味コア（semantic core）」と表記する。
  以降の節に残る「Python」単独表記は特記なき限りPython意味コアを指す。
- **層別同格**: Python意味コア＝意味判断の正本、Node＝実行境界（transactional boundary）の正本であり、一方を他方の
  全面上位に置く記述をしない（ADR-010決定4）。下記「Python write boundary」「Nodeが所有するもの」節はNode単一
  commit境界の技術的直列化点を定義するものであり、Pythonの意味判断そのものへの従属を意味しない。
- **再実装義務の廃止**: 分類できない新規機能をreject-for-TS-reimplementationとする既定はADR-010で廃止された。
  capability classに分類できない機能はADR改定によるclass追加で扱う。動作しているPython意味コアのbulk TS再実装は
  高リスク行為として原則禁止し、実施にはPO個別承認を要する（ADR-010決定1）。

## Python sourceの扱い

正本実装は現行`hybrid-docgen/tools/*.py`です。全面再実装・一括移設は行いません。

Pythonが所有するもの:

- 122文書catalog、profiles、activation
- schema/type validation
- requirement/spec/workflow normalization
- trace derivation/closure
- impact/diff/coverage/schedule
- deterministic detectorとadversarial review packet
- agent purpose digest
- 文書・表・図のgenerated output生成

## Python write boundary

Pythonは次だけを書けます。

- temporary workspace
- `build/`等のgenerated projection
- Nodeが発行したstaging directory

PythonはGit/GitHub/provider、canonical source promotion、approval record、release actionを直接実行しません。既存toolに該当処理がある場合はwrapまたはpatchしてNode portへ移します。

## Python read boundary

ADR-009存続条項（PythonへDB path/credential/`.helix/`を渡さない）により、Python意味コアは`harness.db`へ
直接read queryを発行しません。detection DB等のNode所有ストアを参照する場合、Pythonが受け取れるのは
Node実行境界が提供する**read view**のみです。

- Nodeがexportするsnapshot JSON/NDJSONファイル（Nodeがrequest単位で生成し、staging directoryまたは
  一時workspaceへ渡す）
- Node側typed query serviceへのcall経由の応答（DB接続そのものではなくNode process内で完結するAPI）

いずれの経路でもPythonはDB接続文字列・ファイルpath・credentialを保持しません。08-detection-system-database.md
の記述は本節の用語（read view）に従う。

## Nodeが所有するもの

- CLIとprocess lifecycle
- Git/GitHub/provider adapter
- hook/CI adapter
- canonical file promotion、receipt、lease
- SQLite transaction coordinatorとprojection writer
- Web/IDE surface
- subagent launchとHARNESS capsule delivery

## Compatibility strategy

- 既存`python3 tools/<tool>.py ...`は互換期間中維持する。互換期間の終了条件 = ADR-009 terminal cutover receipt発行（Bun
  known-goodがactive execution graph外の固定commit／content-addressed artifact／DB backupとして保存された時点）。
  terminal receipt発行後はレガシーCLIをhistorical参照allowlistへ降格し、通常運用のcapability経路から除外する。
- 内部pure functionをsplitしても旧scriptをfacadeとして残す。
- JSON/NDJSON modeはHELIXが呼ぶcommandから追加し、全toolへ一括強制しない。
- stdout protocol modeではJSONだけ、human logはstderr。legacy text modeは明示flagで区別する。
- request ID + payload digestで冪等化する。
- invalid version/schemaはpartial canonical write 0で終了する。

## Promotion

```text
Python staging output
→ Node schema/trace/digest check
→ atomic promote
→ receipt + DB event
```
