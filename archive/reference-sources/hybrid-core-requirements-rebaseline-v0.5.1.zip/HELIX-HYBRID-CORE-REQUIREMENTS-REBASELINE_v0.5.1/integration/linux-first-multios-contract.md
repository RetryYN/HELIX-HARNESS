# Linux-first Multi-OS Contract

## Tier

- Tier 1: Linux x86_64/arm64 — full tests、DB fault injection、packaging、container、provider adapter smoke
- Tier 2: macOS arm64/x64 — install、CLI、SQLite、Git、Python bridge、selected integration
- Tier 3: Windows x64 — compatibility smoke。canonical behaviorをWindowsへ寄せない
- Tier 4: WSL2（Linux distro on Windows）— optional compatibility gate。required conditionではなく、Tier 1 Linux full gateの合否には影響しない。CI matrixの `wsl2-compat-smoke` job（node: ["24.15.x"], python: [3.14]）として任意実行し、failしてもmerge blockしない。

## 禁止される中核前提

- drive letter、backslash固定、case-insensitive filesystem依存
- `cmd.exe /c`、PowerShellをcanonical commandとすること
- shell command string連結
- `bun` binary/npm shim
- cp932/console code pageをcore protocolへ持ち込むこと
- user home/OneDrive absolute pathをtracked evidenceへ記録すること

## CI matrix

```yaml
linux-full:
  os: ["ubuntu-24.04"]
  python: [3.12, 3.13, 3.14]
  node: ["24.15.x"]
macos-smoke:
  os: ["macos-14"]
  node: ["24.15.x"]
  python: [3.14]
windows-compat-smoke:
  os: ["windows-2022"]
  node: ["24.15.x"]
  python: [3.14]
wsl2-compat-smoke:
  os: ["ubuntu-24.04-on-wsl2"]
  node: ["24.15.x"]
  python: [3.14]
```

Linux full gateはrequired。macOS/Windows smokeは互換性を示しますが、Linux failの代替にはなりません。WSL2 compat smokeはoptionalであり、failしてもmerge blockしない。
