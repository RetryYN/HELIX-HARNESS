# Workflow Requirements Engine v1.1.0 統合

`UNIVERSAL-WORKFLOW-REQUIREMENTS-SKILL_v1.1.0.zip`は既存Python sourceへcopy/mergeしません。byte-pinned vendor assetを**wrapper/adapter**で接続します。

1. **L1/L2 read-only elicitation** — base questionとsignal条件付き質問を使い、候補と未決事項だけを返す。
2. **L3 contract compiler** — state/trigger/condition/action/next stateからFR、GWT AC、test scenarioを生成する。
3. **Node adapter（ADR-009準拠）** — engine outputを既存YAML、typed ID、schema/trace/build inputへNode CLI側で変換する。
4. **L4-L6 design judgment** — switching、routing、resource pool、allocation policyを設計契約へ降下する。実体成果物 = `templates/L4-L6-workflow-judgment-design.template.yaml`（design-harness/配下のUI専用テンプレートとは別系統）。
5. **Runtime observation** — 実績をモデルへ投影するが、confirmed requirementを自動変更しない。

### Mode別権限

| mode | read | draft | authored write | approve | runtime execute |
|---|---:|---:|---:|---:|---:|
| human_authored_ai_gap_check | yes | candidate only | no | no | no |
| l3_draft | yes | yes | draft bundle only | no | no |
| confirmed_execution | yes | no | no | no | confirmed contract only |
| runtime_observation | yes | finding/delta | no | no | observation only |

Engineのschema、question catalog、prompts、contractsはvendor directoryでbyte pinし、HELIX固有adapterはNode runtime側（D-009のNode CLIサブコマンド）にのみ置き、Python側へは実行権限を与えない。

## resource_type compatibility

Workflow Engine v1.1の`resource_pool.resource_type`には`agent`がありません。vendor schemaは改変せず、adapterではnative kind `agent`を保持し、v1.1互換出力時だけ`other`へcompileします。mappingはmetadataとcontract testで可視化します。
