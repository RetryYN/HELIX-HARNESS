# Target package layout

```text
HELIX/
├ hybrid-docgen/                       # existing Python core, partially patched in place
│  ├ tools/
│  ├ docs/                             # 122 document catalog
│  ├ schema/
│  └ templates/
├ contracts/design-harness/            # authored HELIX-native sidecars
├ schemas/design-harness/              # strict machine contracts
├ skills/design-harness-continuity/
├ src/                                 # TypeScript/Node side-effect runtime
├ tests/
├ .helix/                              # runtime state/evidence; DB projection
└ docs/
```

Design HARNESSを別repository、別engine、UT adapterとして配置しない。raw変換元はmigration/reference assetとしてのみ保持する。
