# HELIX Patch Map

## 1. Hybrid Python Core

Design HARNESSを既存Pythonのnative capabilityとして実装する。

- `activation.py`: UI/UX/FE/screen/browser signalとprofile activation
- `schema_check.py`: Design HARNESS six schema registration
- `spec_types.py`, `spec_check.py`: Region/Slot/Action/State/Binding/Mission kindと不変条件
- `derive_traces.py`, `spec_trace.py`: L1→L10 continuity graph
- `consistency.py`: L2 implementation-neutral、profile isolation、UT namespace exclusion
- `impact.py`, `diff_report.py`: UI Change Deltaと影響閉包
- `schedule.py`, `assign.py`: G2/G4/G5/G6/G7/G10 obligationとHARNESS Capsule
- `review.py`: false implemented claim / generic table / motion overuse / evidence review
- `agent_docs.py`, `agent_meta.py`: Design HARNESS context injection
- `build.py`, `md_export.py`, `render.py`, `diagram_dsl.py`: contract view、ledger、wireframe evidence
- `validate.py`, `hook_gate.py`, `selftest.py`: fail-close gateと回帰

意味判定をTSへ二重実装しない。

## 2. Hybrid document catalog

`design-harness/hybrid-document-binding.yaml`に従い、02/04/06/14/19/21/23/28/31/33/37/39/43/44/49/51/72/73/97/99/108/109へtyped sidecarを接続する。

## 3. TypeScript / Node Runtime

- Python command adapter
- browser/VRT/a11y/performance runner
- provider/subagent launcher
- Git/GitHub integration
- staging→canonical atomic promotion
- receipt append / DB transaction
- Linux-primary process and path adapter

## 4. Detection DB

- screen contract projection
- frontend binding projection
- mission receipt projection
- UX evidence projection
- UI change delta projection
- Infinity Loop finding/routing/event

DBからauthoring contractを書き換えない。

## 5. Workflow Requirements Skill

画面遷移を`state × trigger × condition → action → next_state`へ正規化し、Prototype AgreementとWorkflow contractへ供給する。L1/L2の最終確定は人間authorityを維持する。

## 6. UT-TDD donor/reference

全ref調査から採るのは実装パターンとfindingだけ。UT CLI、DB、state path、PLAN、role、Bun前提をactive HELIXへ移植しない。
