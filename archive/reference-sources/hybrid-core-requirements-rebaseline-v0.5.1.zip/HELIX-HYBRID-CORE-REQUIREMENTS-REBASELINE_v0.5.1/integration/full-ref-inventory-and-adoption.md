# 全ref・全資産棚卸し

## Scanner scope

```text
Git:
  refs/heads/*
  refs/tags/*
  refs/remotes/* (configured allowlist)
  open PR heads
  closed-unmerged PR heads
  merge base / ahead / behind
Files:
  current tree
  archive ZIPs
  Library/conversation uploads
  generated packages
  Hybrid Python files/functions
DB:
  tracked source snapshots
  evidence/audit/capsule assets
```

## 処理

1. ref/file/functionをenumerateしdigestを固定
2. capabilityへ分類
3. main/branch/archive間のsemantic duplicateを検出
4. `reuse_as_is / patch / wrap / split / replace / reject`を決定
5. patch scope、target、compatibility oracle、rollbackを割当
6. disposition未決0になるまでclosureを宣言しない

replace/rejectは保存的選択肢ではありません。patch/wrap/splitで要求を満たせないevidenceとapprovalを必要とします。
