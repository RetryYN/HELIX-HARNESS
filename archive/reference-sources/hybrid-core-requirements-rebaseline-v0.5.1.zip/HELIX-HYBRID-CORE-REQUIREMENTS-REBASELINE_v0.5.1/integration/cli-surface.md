# CLI Surface案

```text
helix core validate|build|detect|impact|diff|schedule|review
helix core legacy <tool> ...               # 既存Python facade
helix core parity --tool <tool>
helix core patch-ledger check

helix requirements interview --read-only
helix requirements compile --l3-draft
helix workflow validate|derive|graph

helix inventory refs|archives|assets|disposition
helix capsule issue|check|checkpoint|resume|close
helix infinity observe|run|audit|status|dead-letter
helix db rebuild|verify|migrate --dry-run
```

Node CLIがcommand admission、staging directory発行、canonical promotion、external side effectを所有します。既存Python scriptは互換facadeとして残し、HELIX内部呼出しはtoolごとのadapter経由へ段階移行します。
