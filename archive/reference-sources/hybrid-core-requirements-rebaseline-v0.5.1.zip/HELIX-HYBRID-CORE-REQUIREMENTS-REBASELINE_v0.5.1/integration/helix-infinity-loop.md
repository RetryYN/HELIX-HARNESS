# HELIX Infinity Loop

> 権威順序（INF-01是正）: 本書はrepo正本
> `docs/design/helix/L4-basic-design/infinity-loop-platform-basic-design.md`のL4 component
> （`InfinityCoordinator`、`agent_verification_receipts`、`LearningPromotionLedger`等）に従属し、
> 対立時はL4正本が優先する。

```text
Observe
  → Detect
  → Classify
  → Route
  → Plan
  → Implement
  → Verify
  → Audit
  → Learn
  → Promote / Reject / Rollback / Escalate
  → Observe
```

## 三重ループ

- Task Loop: 一つのPLAN/task内のfix/verify
- Project Loop: requirement/design/runtime driftと改善
- Harness Loop: detector、skill、rule、model allocation、DB、CI自身の自己監査

## 自動適用境界

| risk | auto apply | 必要条件 |
|---|---:|---|
| observation | no | finding/evidence保存 |
| reversible_internal | conditional | rollback、independent verifier、all gates green、budget内 |
| semantic_contract | no | PO承認、L1/L3 back-propagation |
| irreversible_high_impact | no | action-bound human approval、dry-run、backup、rollback、monitoring |

自己改善は「自分で直して自分で合格」ではありません。worker、verifier、auditorを分離し、rule昇格には複数事例とfalse-positive評価を要求します。
