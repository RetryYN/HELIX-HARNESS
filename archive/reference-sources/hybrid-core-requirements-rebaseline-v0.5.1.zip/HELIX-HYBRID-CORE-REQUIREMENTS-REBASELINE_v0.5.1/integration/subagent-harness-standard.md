# サブエージェントHARNESS保持標準

サブエージェントへ単なるpromptを渡す方式を廃止し、**HARNESS Capsule**を配布します。

```text
Parent observation/state
→ immutable capsule issue
→ child executes within scope/budget/authority
→ checkpoint receipts
→ typed result
→ independent verification
→ capsule terminal/compact
```

## 必須保持項目

- repo/ref/commit/worktree/platform
- PLAN、workflow、current state、trigger
- objective、input refs、output schema、completion oracle
- allowed/denied paths、actions、tools
- subagent_type/runtime（既存agent-guard allowlistとの対応）とis_fable_apex_subagent（advisor-fableのみtrue）
- injected requirement/design/skill/memoryのversion+digest
- model/effort/token/time/cost/concurrency/retry budget
- write/approve/complete/merge/release authority
- checkpoint interval、resume pointer、lease
- retention class、expiry、redaction
- capsule発行時にClaude Agent promptへ委譲ブリーフ4marker（【objective】/【output format】/【tool guidance】/
  【task boundary】、正本DELEGATION_BRIEF_MARKERS）を含めることを、capsule.taskとscopeの対応関係として要件化する。

## 標準不変条件

1. Capsuleなしのsubagent spawnを拒否する。
2. Capsule digest不一致を拒否する。正規化はdigest-canonicalization-authority.mdのcanonicalJson/sha256Digest
   契約に従い、capsule_digest自己参照はプレースホルダ除外する。
3. workerは自己成果物をtrusted approvalできない。
4. 子が境界外を発見した場合、変更せずfinding/escalationとして返す。
5. raw transcript、secret、PIIは既定保存しない。
6. capsuleとcheckpointからfresh sessionでresumeできる。


## HELIX Design HARNESS context

Design/FE/UXタスクのCapsuleには、対象screenのPrototype Agreement、Product UI Profile、Frontend Binding、
UI-Mission、test oracle、UX evidence requirementをdigest付きで含める。これらはHybrid Python Coreが解決し、
Node runtimeはdeliveryとprocess isolationのみを担う。
