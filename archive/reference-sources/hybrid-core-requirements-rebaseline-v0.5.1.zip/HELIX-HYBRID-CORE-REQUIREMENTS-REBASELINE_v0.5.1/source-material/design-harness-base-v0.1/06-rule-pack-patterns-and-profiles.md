# 6. Rule Pack、Pattern Contract、Product UI Profile

## 6.1 三層分離

```text
Harness Rule Pack
  ↓
Product UI Profile
  ↓
Screen Ledger / Prototype Agreement
```

### Harness Rule Pack

全案件共通の原則、禁止事項、Pattern、検証観点。

### Product UI Profile

案件固有のブランド、platform、font、color、density、breakpoint、a11y目標、motion方針。

### Screen Ledger

画面固有の目的、構造、状態、差分。

## 6.2 Pattern Contract

Patternは画面の見た目を固定するtemplateではなく、構造と制約を定めます。

### Operational pattern

- dashboard
- list/explorer
- detail/review
- edit/form
- diagnostic
- monitoring
- log/console
- settings
- wizard

### Expressive pattern

- onboarding
- feature introduction
- completion/achievement
- campaign/landing
- brand story

## 6.3 Patternが持つ項目

```yaml
pattern:
  id: PAT-OP-DIAGNOSTIC
  required_regions: [summary, next_action, evidence]
  optional_regions: [diagnostics, history]
  forbidden:
    - continuous_decorative_motion
    - hidden_primary_action
  responsive_strategy: priority-stack
  motion_budget: minimal
  decoration_budget: low
  implementation_order:
    - semantic_structure
    - responsive_structure
    - data_state
    - interaction
    - decoration
    - motion
```

## 6.4 Product UI Profile

profileの例:

- `operational-desktop`
- `responsive-service`
- `expressive-campaign`
- `mixed-product`

profileは「mobile対応の有無」だけでなく、使用時間、頻度、入力方式、情報密度を定義します。

## 6.5 Tokenの扱い

- Rule Pack: token categoryと禁止事項
- Product Profile: token value
- Screen: tokenを参照するだけ

例:

```text
Rule Pack: status.error.fgが必要
Profile: #CF222E
Screen: status.error.fgを参照
```

## 6.6 テンプレワイヤー

AIは画面要求からPatternを選び、required Regionを埋めます。

```text
1. surface class判定
2. pattern選択
3. required region配置
4. information priority反映
5. state family追加
6. responsive変形定義
7. motion/decorative budget適用
8. unresolved/extension登録
9. trace登録
10. prototype evidence生成
```

## 6.7 禁止パターン

- backend tableを画面全体の代替にする
- primary actionを複数箇所に重複
- colorだけで状態表現
- responsiveを縮小表示だけで済ませる
- 常用画面で連続animation
- global tokenを画面内でoverride
- evidenceのsourceを隠す
- empty/loading/errorを省略
- L2でframework classを固定
- プロトコードを本番へ昇格

## 6.8 外部デザインツール

Figma/Excalidraw/画像は次の用途に限定します。

- High-Fi review
- brand expression review
- complex layout discussion
- screenshot evidence

戻ってきた成果物はPrototype Agreementへback-propagateし、契約と不一致ならL1-L4を修正します。
