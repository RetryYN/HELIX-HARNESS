# 0. エグゼクティブサマリー

## 結論

最適な構造は、UT-TDDのForward spineへ **UX–FE Continuity Contract** を差し込むことです。

```text
L1 利用者・事業・画面要求
  ↓
L2 Prototype Agreement / 想定画面台帳
  ↓   同じ意味IDを維持
L3 画面機能要求・AC
  ↓
L4 UI Rule Pack / Product UI Profile / Token
  ↓
L5 Frontend Binding Contract
  ↓
L6 Screen Function Contract / WBS / Unit Oracle
  ↓
L7 本番フロント実装
  ↓
L8-L9 結合・総合検証
  ↓
L10 実データUX・responsive・motion・a11y検証
```

独立したデザインmodeや描画エンジンは不要です。既存の `screen-design`（L2）と `frontend-design`（L10）を、L3〜L7の設計・実装鎖で切れないようにします。

## 最重要の是正

### 1. L2で実装クラスを固定しない

L2は次を固定します。

- 利用者の目的と判断
- 情報優先順位
- 画面Region / Slot
- 状態、遷移、responsive意図
- motion / decorationの許容量
- 拡張点と未確定依存

以下はL5以降へ送ります。

- React/Vue等の実装部品
- props / state owner
- API / event / logging
- component boundary
- class / module / file

### 2. 「プロト合意」を本文中の単語ではなく型で検査する

現行のG2関連実装は、`confirmed`、pair、本文中の「G2」「PO」「合意」「prototype」等を主に見ています。本案では `prototype_agreement` と `screen_ledger` を型付き宣言にし、目的・状態・responsive・未確定事項・traceの実体を検査します。

### 3. L2→L10→実装という順序誤認を直す

正しい順序は次です。

```text
L2設計 + L10で実行するUXテスト設計を事前凍結
→ L4-L6設計
→ L7実装
→ L10実検証
```

`implemented` はG7、`ux_verified` はG10で別管理します。

### 4. フロント実装ゼロ問題を「Frontend Mission」で塞ぐ

画面一覧にIDがある、routeがある、汎用tableが出る、というだけで実装済みにしません。各画面は次を完遂して初めてG7で実装済みになります。

```text
foundation
route
screen-specific composition
data binding
five-state coverage
interaction
responsive
accessibility
motion policy
tests
evidence
trace
```

### 5. デザイナー最適とエンジニア最適をExperience Ownerで統合する

初期導入では新role enumを追加せず、既存 `po` slotをUI系PLANでExperience Ownerとして定義します。

```text
PO / Experience Owner: 誰に何を達成させ、何を感じさせ、何を事業成果とするか
UIUX: 情報をどう知覚・理解・操作させるか
TL/SE: データ・状態・性能・ログ・保守性をどう成立させるか
QA: 契約が実レンダリングで成立するか
```

## Figma型かCanva型か

正本は **Pattern Contract + Typed Ledger型**です。

- Figmaから借りる: 階層、制約、Variant、Token、Auto Layout的変形
- Canvaから借りる: 用途別テンプレート、表現画面用スタイルセット
- 正本: Markdown/YAML内の契約とtyped spec
- Figma/画像/HTML: evidence

## 完了像

Design Harness内蔵化が成功した状態は、次の一文で表せます。

> L2で作った画面仮説が、L5のフロント契約、L7のコード、L10の実利用検証まで同じ意味IDで継承され、変更は安全なdeltaとして上流へ戻る。
