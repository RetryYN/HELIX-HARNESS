# 15. リスクと設計判断

## 15.1 推奨確定事項

- 独立engineを作らない
- L2で実装classを固定しない
- L5でUI-FE bindingを確定
- G7 implemented / G10 ux_verifiedを分離
- existing PO slotをExperience Ownerとして利用
- Rule Pack / Product Profile / Screen Ledgerを分離
- Frontend Missionで実装ゼロ問題を塞ぐ

## 15.2 後続判断

### D1: 共通Rule Packの正本配置

推奨: `docs/process/ui/`

理由: 工程・駆動モデルと同じ運用正本で、製品固有design docと分離できる。

### D2: Product UI Profileの配置

推奨: 各productのL4 design配下。

### D3: typed spec ID namespace

推奨: existing screen IDを維持し、Region/Binding等だけ新prefix。

### D4: `implemented_screens`移行

推奨: read-only compatibility fieldへ降格し、mission projectionから生成。

### D5: role enum

推奨: 初期は追加しない。Experience OwnerをPO slot label/policyで表現。組織運用で恒常的に別人となる場合だけ新roleをADR化。

### D6: responsive hard level

推奨: profile controlled。responsive serviceはhard、desktop-onlyはsafe resize/zoom/overflowをhard。

### D7: visual tool

推奨: optional evidence。正本化しない。

## 15.3 リスク

| リスク | 対策 |
|---|---|
| 文書がさらに増える | 既存docを再編し、重複を移動。新doc最小化 |
| schemaが重い | screen/pattern/bindingの3主schemaに絞る |
| AIがfieldを埋めるだけ | G10実測、review、evidenceを要求 |
| UIUXだけが責任を負う | PO/TL/QA signoffを分担 |
| frontend implementationが後回し | G6でL7 missionを必須化 |
| hard gate導入で既存が全赤 | warning→new/changed only→hardの段階導入 |
| 個別案件へ中央UI値が漏れる | Product Profile分離 |
| 過剰な自由表現 | surface classとbudget |
| 過剰な無機質化 | expressive regionを正式許可 |
