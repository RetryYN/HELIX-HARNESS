# 10. Typed spec、台帳、projection

## 10.1 新DBを作らない

既存typed specとrelation graphへUI契約を追加します。`harness.db`はread-modelです。

## 10.2 ID family

| ID | 意味 |
|---|---|
| existing PM/HM/GD | screen |
| `REG-*` | semantic region |
| `SLOT-*` | information/action slot |
| `ACT-*` | action intent |
| `STA-*` | state contract |
| `PAT-*` | pattern contract |
| `RSP-*` | responsive rule |
| `MOT-*` | motion rule |
| `EXT-*` | extension point |
| `BND-*` | frontend binding |
| `UI-M*` | implementation mission |
| existing `UXV-*` | UX validation oracle |

Screen ID体系は既存を維持します。

## 10.3 authored spec例

```yaml
spec:
  defines:
    - id: REG-PM03-NEXT-ACTION
      kind: ui-region
      traces_from: [PM-03, FR-L1-05]
      traces_to: [BND-PM03-NEXT-ACTION]
      tests: [UXV-CONTINUITY-PM03, U-SCREEN-PM03-ACTION]
```

## 10.4 Ledgerとtyped specの関係

- Ledger: 人間が画面全体を読む台帳
- typed spec: 検出器がedgeを読む宣言
- projection: UI/doctor/search用

同じ情報を二重正本化しません。Ledger entry内に`spec.defines`を置くか、owner artifact直下へ分散します。

## 10.5 Projection案

既存 `spec_defs / spec_relations / findings / artifact_progress`へ投影可能です。専用table追加は必要性をL4/L5で判断します。

推奨derived view:

- `ui_screen_progress`
- `ui_contract_orphans`
- `ui_mission_progress`
- `ui_ux_evidence_status`

derived viewは正本ではありません。

## 10.6 実装claim導出

`implemented`はledgerに人間が自由記入せず、mission evidenceから導出します。

```text
implemented =
  route_exists
  AND screen_specific_composition
  AND required_bindings_complete
  AND required_states_complete
  AND required_tests_green
  AND evidence_exists
  AND trace_orphans = 0
```

## 10.7 Revision

- base contractを破壊せずadditive revision
- `revision_track: additive`
- `revision_base_artifact`
- delta ID
- approval
- back-propagation target

既存のadditive revision規則へ合わせます。

## 10.8 File boundary

提案配置:

```text
docs/process/ui/                     共通Rule Packの正本
docs/design/<product>/L2-screen/     案件screen ledger/prototype
docs/design/<product>/L4-ui/         Product UI Profile/tokens
docs/design/<product>/L5-ui/         binding
docs/design/<product>/L6-ui/         function spec
skills/ui-continuity/                 Pack runtime注入
```

現行harness dogfoodは `docs/design/harness/...` を維持し、共通Rule Packだけ切り出します。
