# 5. UI責務とフロント責務の分離・継続契約

## 5.1 分離の目的

UI責務とフロント責務を分ける理由は、担当を分断するためではありません。

> 見せ方と成立条件を別々に変更可能にし、同じ意味IDで結合するためです。

## 5.2 UI Contract

UI Contractが持つもの:

- information priority
- reading order
- region purpose
- action intent
- visual state
- responsive transformation
- motion/decorative budget
- progressive disclosure

UI Contractが持たないもの:

- API name
- DB column
- React state
- logger field
- file path

## 5.3 Frontend Binding Contract

L5で次を接続します。

| UI側 | FE側 |
|---|---|
| Screen | route / screen adapter |
| Region | composition boundary |
| Slot | view-model field |
| Action intent | event contract |
| Visual state | typed view state |
| Responsive rule | layout implementation rule |
| Motion rule | transition implementation |
| Evidence slot | source/provenance binding |

## 5.4 接続主キー

```text
screen_id
region_id
slot_id
action_id
state_id
extension_id
binding_id
```

実装class名を主キーにしません。

## 5.5 Decision first, evidence available

エンジニア中心UIは内部構造を全面へ出しがちです。デザイン中心UIは根拠を隠しがちです。統合原則は次です。

```text
Primary layer: 利用者の判断に必要な要約
Secondary layer: 詳細・比較・履歴
Evidence layer: raw data / source path / logs / trace
```

監査・DB explorer等の専門画面は高密度を許可しますが、それでもpurposeとinformation priorityを持たせます。

## 5.6 State ownership

L5でstate ownerを確定します。

- URL: 共有・再現・backに必要
- local component: 一時展開
- application state: 画面横断
- server/cache: data freshness
- repository/DB: workflow SSoT

UI stateをworkflow SSoTにしません。

## 5.7 Logging / diagnostics

開発コンソールやログ画面はL2で最終形を固定しません。

L2:

- 診断が必要というpurpose
- evidence/diagnostic extension point
- 利用者が知りたい情報

L5:

- logging schema
- permission
- redaction
- trace correlation
- pagination/streaming
- retention

L6:

- screen function
- validation
- unit oracle

## 5.8 Frontend Bindingの完了条件

各required Slotに対して次のどれかが必要です。

- concrete binding
- explicit static source
- approved defer with expiry

孤児SlotはG5 failです。

## 5.9 例

`examples/PM-03-frontend-binding.yaml`に、Gate画面のaction/evidence/diagnostics接続例を収録しています。
