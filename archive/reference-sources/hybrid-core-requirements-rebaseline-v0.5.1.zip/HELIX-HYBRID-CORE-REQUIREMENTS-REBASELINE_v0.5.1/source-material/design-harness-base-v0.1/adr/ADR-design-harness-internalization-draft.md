# ADR-DRAFT: UT-TDDへDesign HarnessをUX–FE Continuity Contractとして内蔵する

- Status: proposed
- Decision owner: PO / TL
- Scope: UT-TDD engine + Pack rule distribution

## Context

画面設計資産はL1〜L6へ存在するが、フロント本実装がほぼゼロであり、設計と実装の継続性が機械保証されていない。L2には実装寄り契約が混入し、L10とL7の工程順にも不整合がある。

## Decision

1. Design Harnessを独立engine/mode/layerとして作らない。
2. ForwardへUX–FE Continuity Contractをoverlayする。
3. L2はPrototype Agreementとsemantic Region/Slotを所有する。
4. L5はFrontend Bindingを所有する。
5. L7はFrontend Missionで実装完遂を判定する。
6. L10は実レンダリングUX検証を行う。
7. Rule Pack、Product UI Profile、Screen Ledgerを分離する。
8. typed specとdoctorへ統合し、DBはprojectionとする。

## Consequences

### Positive

- デザインと実装の孤児を検出できる。
- L2早期固定を防げる。
- 実装ゼロのまま画面設計完了を名乗りにくい。
- responsive/motion/a11yが後付けにならない。
- marketing/UX/engineering判断を同じ契約で接続できる。

### Negative

- L2/L4/L5既存文書の再編が必要。
- doctor checkとtyped specが増える。
- 初期dogfood期間はwarningが多くなる。

## Rejected alternatives

### Figma互換engine

描画機能が主目的ではなく、既存UT-TDDのrule parityを壊すため不採用。

### Canva型template generator

高速だが構造・状態・実装traceが弱いため正本には不採用。

### 独立Design mode

Forwardから分断され、今回の目的に逆行するため不採用。

### L2でcomponent契約固定

後続のログ、データ、権限設計に追従しにくいため不採用。
