# UT-TDD Design Harness 内蔵化パッケージ v0.1

## 目的

本パッケージは、`unison-ai-product/UT-TDD_AGENT-HARNESS` の既存 Forward spine（L0〜L14）へ、デザインとフロント実装を分断しないための **UX–FE Continuity Contract** を内蔵する構想・契約・導入計画をまとめたものです。

新しい画面生成エンジン、Figma代替、Canva代替、独立した開発modeは作りません。既存の以下へルールを差し込みます。

- V-model の L1〜L10
- PLAN / pair-freeze / trace-freeze
- typed spec
- `doctor` / gate / relation graph
- layer-context / skill injection
- `harness.db` projection

## 今回の中心課題

現状は画面設計文書が先行している一方、フロント本実装が限りなくゼロに近い状態です。したがって本案は、デザイン文書を増やすことではなく、次を機械的に成立させることを中心にしています。

1. L2で画面仮説と体験契約を作る。
2. L3〜L6で要求・データ・状態・ログ・権限・実装境界へ降下する。
3. L7で実際に動くフロントを段階実装する。
4. L10で実データ・実レンダリング・継続利用性を検証する。
5. どの段階でも画面、設計、コード、テストの孤児を許さない。

## 推奨読順

1. `00-executive-summary.md`
2. `01-current-state-gap-analysis.md`
3. `02-target-concept.md`
4. `03-forward-spine-insertion.md`
5. `04-l2-prototype-agreement.md`
6. `05-ui-fe-continuity-contract.md`
7. `08-greenfield-frontend-path.md`
8. `09-gates-doctor-and-trace.md`
9. `12-patch-map-and-plan-sequence.md`
10. `13-rollout-and-dogfood.md`

## ディレクトリ

```text
.
├── 00-15                 構想、詳細、導入計画
├── adr/                  ADR草案
├── plans/                Master PLAN草案
├── schemas/              契約形式案（実装エンジンではない）
├── templates/            L2〜L10とPLANの雛形
├── examples/             PM-03等の記入例
├── checklists/           Gateレビュー項目
├── diagrams/             Mermaidソース
└── skill-pack/           動的注入用ルールパック案
```

## 正本と投影

- 正本: governance / process / design / test-design / PLAN / source / tests
- `harness.db`: 検索・検出・可視化用 projection
- Figma、画像、HTMLプロト: レビュー証跡。契約の正本にはしない

## 用語

- **Design Harness 内蔵化**: デザイン専用システムを増やすのではなく、UT-TDDの既存工程に画面・体験・フロント継続契約を差し込むこと。
- **Experience Owner**: PO slotに持たせる、利用者価値・事業価値・継続利用・表現方針の統合責務。初期導入では新role enumを増やさない。
- **Pattern Contract**: 自由描画ではなく、画面型、必須領域、禁止配置、responsive変形、motion予算を定義する契約。
- **Frontend Mission**: 「画面数」ではなく、shell、route、data、state、interaction、responsive、a11y、evidenceの完遂単位。
