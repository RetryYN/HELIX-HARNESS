# 3. Forward spineへの差し込み構造

## 3.1 新layer・新modeを作らない

本機構は `forward-specialist-overlay` として扱います。

```yaml
activation:
  when_any:
    - drive: fe
    - drive: fullstack
    - drive: agent
    - l1_screen_requirements_present: true
    - ui_paths_touched: true
    - route_signal: screen_addition_to_backend
```

`screen-design`と`frontend-design`は既存通り工程専門です。Design Harnessはこの二点をL3〜L7で接続する規則です。

## 3.2 Layer別責務

| Layer | Design Harnessの必須成果 | 終了条件 |
|---|---|---|
| L0 | UX原則、対象利用者、プロダクト表現方針 | L1へ価値軸を渡せる |
| L1 | Experience Contract、画面要求、利用シナリオ | BR/UX/Screen trace |
| L2 | Prototype Agreement、Screen Ledger、Pattern、Region/Slot、Low-Fi evidence | G2内容契約 |
| L3 | Screen FR/AC、データ・権限・ログ・性能要求 | G3 AC + L2 back-merge |
| L4 | Rule Pack適用、Product UI Profile、token、layout/responsive/motion/a11y標準 | G4 profile freeze |
| L5 | Frontend Binding、state owner、data flow、event、permission、logging | G5 binding freeze |
| L6 | per-screen function contract、WBS、unit oracle、実装順 | G6 implementation readiness |
| L7 | frontend missions、code、unit tests、render evidence | G7 implementation freeze |
| L8 | route/data/state/component integration | G8 |
| L9 | cross-screen visual/a11y/token/system consistency | G9 |
| L10 | real-data UX、responsive、motion、VRT、継続利用review | G10 |
| L11-L14 | UAT、受入、運用価値feedback | 次cycleへback-prop |

## 3.3 L2とL3の反復

画面プロトは要求を可視化するため、L2で要求漏れが見つかります。したがってL2→L3は一方向ではありません。

```text
L1 screen requirement
  ↓
L2 prototype hypothesis
  ↓ gap found
L3 FR / AC / NFR formalization
  ↓
L2 ledger back-merge
  ↓
G2 + G3 alignment
```

## 3.4 Pairの正しい扱い

```text
L2 design authored
L10 test-design authored and pair-frozen
      ↓
L4-L6 descent
      ↓
L7 implementation
      ↓
L10 test execution and UX refinement
```

以下を区別します。

| 状態 | 意味 |
|---|---|
| `pair_design_ready` | L10で何を検証するかが設計済み |
| `implementation_ready` | L4-L6が閉じ、L7着手可 |
| `implemented` | G7でコード・テスト・証跡が閉じた |
| `ux_verified` | G10で実レンダリング検証済み |

## 3.5 既存駆動モデルとの接続

| 発見 | route |
|---|---|
| 利用者価値が不明 | Discovery |
| backend先行で画面が必要になった | design-bottomup → L1/L2 |
| 既存画面への軽微追加 | Add-feature |
| 設計と実装の不一致 | Reverse normalization |
| UI内部改善、振る舞い不変 | Refactor |
| 依存やfrontend stack更新 | Retrofit |
| 実装暴走・誤claim | Recovery |
| 本番UI回帰 | Incident |

## 3.6 Dynamic skill injection

各layerで同じ巨大promptを注入しません。

```text
L1: experience-principles
L2: prototype-contract + pattern-catalog
L3: screen-functional-ac
L4: design-rule-profile
L5: frontend-binding
L6: screen-function-wbs
L7: frontend-mission-tdd
L10: real-data-ux-verification
```

提案skill packは `skill-pack/` を参照してください。
