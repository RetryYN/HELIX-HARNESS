# Layer Obligations

## L2

Purpose, persona, frequency, criticality, information priority, Pattern, Region/Slot, state, responsive, motion, extension, unresolved, trace, evidence. No implementation class/API binding.

## L4

Rule Pack, Product UI Profile, token values, responsive/motion/a11y standards.

## L5

Data, state owner, events, side effects, permissions, logging, redaction, component boundary, integration pair.

## L6

Function contracts, frontend missions, WBS, unit oracles, implementation order.

## L7

Production code and tests. Screen-specific composition and M0-M7 evidence are mandatory.

## L10

Real rendering, real-data conditions, responsive, motion, continuity, a11y, visual regression, review evidence.
