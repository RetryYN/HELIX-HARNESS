# Design Principles

1. Usability before spectacle.
2. Continuity before novelty.
3. Visibility before decoration.
4. Decision first, evidence available.
5. Operational UI is quiet and predictable.
6. Expressive UI is localized and intentional.
7. Responsive behavior is a transformation contract.
8. Motion has a budget and reduced-motion fallback.
9. Empty/loading/stale/partial/error are first-class states.
10. Prototype evidence never replaces authored contracts.
