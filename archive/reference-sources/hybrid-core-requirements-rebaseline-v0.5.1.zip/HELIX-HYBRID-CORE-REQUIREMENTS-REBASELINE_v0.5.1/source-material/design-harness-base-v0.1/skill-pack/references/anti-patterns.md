# Anti-patterns

- Treating a route as an implemented screen
- Treating a generic table dumper as multiple screens
- Free-form `implemented_screens` claims
- Freezing React/Vue classes or API endpoints at L2
- Copying prototype code into production without redesign
- Hiding evidence behind summary-only UI
- Exposing backend structures as the primary user model
- Omitting empty/loading/error/stale/partial states
- Using color as the only status signal
- Shrinking desktop layout as responsive design
- Continuous animation in operational screens
- Closing G10 without rendered evidence
- Writing authored contracts from DB projections
