---
name: ui-continuity
purpose: Inject UX–FE Continuity rules into UT-TDD Forward layers without creating a design engine.
---

# UI Continuity Skill

## Trigger

Use when any of the following applies:

- drive is `fe`, `fullstack`, or UI-bearing `agent`
- L1 screen requirements exist
- UI route, layout, component, token, responsive, animation, accessibility, or visual evidence changes
- backend-derived screen signal occurs

## Read first

1. Product UI Profile
2. Relevant L1 screen/experience requirements
3. L2 Prototype Agreement and Screen Ledger
4. Current layer obligation from `references/layer-obligations.md`
5. Pattern/anti-pattern rules

## Core rule

Do not create a new design engine. Author or update the existing UT-TDD artifacts and preserve semantic IDs from L2 through L10.

## Layer behavior

- L2: author semantic structure, not implementation classes
- L4: apply rule/profile/token standards
- L5: bind semantic slots to frontend contracts
- L6: create function specs, tests, and frontend missions
- L7: implement production frontend; prototype code is not production evidence
- L10: verify real rendering, real data, responsive, motion, accessibility, continuity

## Done when

- relevant gate checklist passes
- trace orphans are zero
- unresolved items have an expiry gate
- no implemented claim is based only on route/count/placeholder/generic table
- findings are routed or back-propagated
