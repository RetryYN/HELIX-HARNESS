# File checksums

`CHECKSUMS.md` 自身は循環参照を避けるため対象外です。

| Path | SHA-256 |
|---|---|
| `00-executive-summary.md` | `e3e508302486faf473b2382429f2a571135050dff28d98d977b1c54d50c21ef0` |
| `01-current-state-gap-analysis.md` | `91a690ff6dce0d2e48e3b093462c76f2b2e077e4dec98ab1faaf3c4b0bf32346` |
| `02-target-concept.md` | `9000c6f651d47d675229b2301f184ea61116bd3c508a3fad4c10f7e3fcdf4b12` |
| `03-forward-spine-insertion.md` | `423b73006500f8b20e2f04b52879dda635402fdd53efb07f6111acec371a7842` |
| `04-l2-prototype-agreement.md` | `cfd60253f0822d15bee3247070bfcf4d4312b120049584cb2a7911842697eede` |
| `05-ui-fe-continuity-contract.md` | `68f311128b389524ce9de758e68f34f71871a10d4aaf4206bc09e1fed4c49937` |
| `06-rule-pack-patterns-and-profiles.md` | `7a78db9b8e87ac694c9a52ad56ebfe4f07ea355859ccc0c33d1d5f006281143f` |
| `07-responsive-motion-and-expressiveness.md` | `4326ae039c2787a24b4cb5753aad327605691f564a672364827e0975091eb13c` |
| `08-greenfield-frontend-path.md` | `18beeac2cfaf76ca3a135efc06581e9df0edfda4897bfa07754887de03fe97e6` |
| `09-gates-doctor-and-trace.md` | `9b6319bc3da7100621382dbcce340d9d0144f77503903b8bf7c21929b2a75292` |
| `10-typed-spec-ledger-and-projection.md` | `0b4d42830a4b5a1be0baac9cdae5fc1bf1bfde5c81966b3c8bc34581f8457aab` |
| `11-safe-change-and-routing.md` | `7120d1b44f7db8a331af0f29b8a79e8b0d25e969a4f5959f627b72b45521af8c` |
| `12-patch-map-and-plan-sequence.md` | `05764daa7e55cbecf518444f9ece352cb7fd66cb5490433ea93b60b416602e96` |
| `13-rollout-and-dogfood.md` | `76e1edfb6df08bc972417f936af38b3f65a07125c97afc87a0214da6c5691e54` |
| `14-acceptance-criteria.md` | `f241552d38e65d41f2a63097d558b4d7ccc3a9f171da831b7d5fc593b7692e67` |
| `15-risks-and-open-decisions.md` | `41d86ec48bd5cb47155db0842d914991d235b6269857a5337bdfa7fa5725209a` |
| `MANIFEST.json` | `359e9dc408528a27a2ae952a1ae3de8b821320fd5de3107670c49ad73a4b3134` |
| `README.md` | `dc449344e6dfcb9ad4544379d03666cadce536d3e2e19fd8db4232faf1a3391d` |
| `adr/ADR-design-harness-internalization-draft.md` | `8689f8de474a489cc7044ebe6db99c2844aaf57120ef2451a08efb44d922c89c` |
| `checklists/G10.md` | `73829b5cd37ad335a4d6127f81453cce16a1e383582fe9ec8d72952dd8a41c0d` |
| `checklists/G2.md` | `3c4d22423329a1e20218195a001e3e063036abc280dbfa398bc2cb4b0ce3a6d1` |
| `checklists/G4.md` | `c5ed11eaba68bf39b201eee5f380d72ce1a11c658afeaba87ece44fd4ec692e9` |
| `checklists/G5.md` | `f112cbefc1afb679d0fb3ba5b1ca1b529937dd3c69a458500199ba7123a0fe09` |
| `checklists/G6.md` | `9c95bf131569bc1242ec0e1ae51c2fbbbff950921a6d83d2942f5dfaf840cd92` |
| `checklists/G7.md` | `147b95b4d96eba0f5b4375b8f141b7decef0852d4f46d322f8c56ebc42e6052d` |
| `diagrams/forward-insertion.mmd` | `7eeef8dd3cac187a032549d1537ae76be8e20377027db9ad680a29a465931dbc` |
| `diagrams/responsibility-continuity.mmd` | `0f1735adfb6c4c2cd2f8b11854780e86b990c217da8c7218f9fc0097daf4df97` |
| `diagrams/safe-change-routing.mmd` | `079fc54719d5f95cd48b725447cbdfc3de0b309bf5d84e4ca6583ff6d5478a80` |
| `examples/EXP-01-onboarding-prototype-agreement.yaml` | `f677c0a201a365903ed5d344102c7ffdfbf6295678117393cd721e946f3b7d78` |
| `examples/PM-03-frontend-binding.yaml` | `d6e64c72a8a9c264df12be1b86c4a499bd7a5c04b9b831a06e94389cfdffaf13` |
| `examples/PM-03-prototype-agreement.yaml` | `12f121ff7114d169afcf358b15f9c6da76707eebf7d47019a584f410bd6de6b4` |
| `examples/PM-03-screen-ledger.yaml` | `05bac2c81b6196fac14f0a1e2e1d5239e929e420a1a21eb8a4cb6b360fbc6cc6` |
| `examples/ui-change-delta-log-console.yaml` | `38d11208eb2c9de54adb0173a2babb70c18c1ccecc6f77fc255ddef23338e4fd` |
| `examples/ui-profile-mixed.yaml` | `0e793b5c9e66c19e304d646c0030e6ca05c730589d2b4da79a13311ede44814f` |
| `plans/PLAN-M-design-harness-internalization-draft.md` | `8326863c1e5bae9befd3154ddae96f7bd3053a879d649fa5e7bc14c1ce097310` |
| `schemas/frontend-binding.schema.yaml` | `032ac5bdef4ab87ef09bbf6dae7face15e4a9f8139c0a80fd703ea5f9d9e7cd5` |
| `schemas/prototype-agreement.schema.yaml` | `3eb0b18e616a3589672b1faffdaf3396f23d9d5b284acd0d57a24591693ee13c` |
| `schemas/screen-ledger.schema.yaml` | `a18d364bb381347dc7d3dbce20309aaf80fe439f4acda385924ddfd5d1f4dc3c` |
| `schemas/ui-change-delta.schema.yaml` | `79feb12fdfe189857cd0fa03d63971d0c5aa327028b5958ce0aa6a8164c4fb46` |
| `schemas/ui-profile.schema.yaml` | `b20e31ff97e3cb1f4eaa17c62fcdcbd57ccce9bbc97d82b50be479c65e1fd7ed` |
| `schemas/ux-evidence.schema.yaml` | `4371dae29f3884e057eea78469137a74d8922ab14830c9523fa6634d4dc5bc1e` |
| `skill-pack/SKILL.md` | `bbc002a773af3e2c6a24e54388478d60aab4a09c5300a9d45cf94a44b2836a4b` |
| `skill-pack/injection.yaml` | `a1390c9f866f04663597cd3b524ac822d6c87ca7c459f41a5eab425142619b4d` |
| `skill-pack/references/anti-patterns.md` | `8395886a69ac5c86a496f10f0ea6dab22571847fb6bac13204053d0a75097ed3` |
| `skill-pack/references/design-principles.md` | `5a07febebe30cda7fcc727425cf6e7e22e74eb157c8fdcf3ddf80981c47479e7` |
| `skill-pack/references/layer-obligations.md` | `0172c53d755016d7dd06001d606b07a308fa2645f0a1b9cb144883dd88a909b9` |
| `templates/G2-prototype-agreement-review.template.md` | `f983a874a4ed7199493e500fd9322b787ef9db9549206cd3d4b6b765ce901785` |
| `templates/L2-prototype-agreement.template.md` | `6baf1cf5ef6e7462fbe74d1adcb2263d6d9d6dfee9ed712f03bec6106a24368a` |
| `templates/L4-ui-profile.template.yaml` | `0c4088f2cb9ee250c77acc45bebe58189ef2488b9e8f0f17448d761a209f34cc` |
| `templates/L5-frontend-binding.template.md` | `79b6dd20ff3005f1472140a9ca19bbad14a835081c38f4cf785a08f85b4e2cea` |
| `templates/L6-screen-function-and-mission.template.md` | `5802e8dc9acda0d93b02492e0aa98ccaa7fb14917dd2e926f030c4e4c956e3c0` |
| `templates/PLAN-ui-workstream.template.md` | `a73bbc1bbc9b9efe4ce4e07ddbf4d7accf95be7f8ab643d5d70dbd7b5616dde3` |
