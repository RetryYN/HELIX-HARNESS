# 11. 抜け漏れ・変更を安全に差し込む仕組み

## 11.1 前提

画面と機能の抜け漏れは必ず出ます。重要なのは、最初から完全に固定することではなく、変更が無秩序に実装へ混入しないことです。

## 11.2 UI Change Delta

```yaml
ui_change_delta:
  id: DELTA-UI-021
  discovered_at_layer: L4
  cause: logging_design_expanded
  target_screen: PM-03
  target_extension: EXT-PM03-DIAGNOSTICS
  hypothesis: gate失敗の相関ログを同画面で確認すると調査時間が減る
  status: observing
  dependencies: [logging-contract, permission-model]
  decision_layer: L5
  implementation_blocked: true
```

## 11.3 状態

```text
candidate
→ observing
→ approved
   ├ merge
   ├ split
   ├ optional
   └ reject
→ implemented
→ verified
```

## 11.4 Routing rule

| 条件 | route |
|---|---|
| 価値仮説が未確認 | Discovery |
| backendの実装事実から必要 | design-bottomup |
| 現scopeの追加 | Add-feature |
| 既存設計と実装のdrift | Reverse |
| 内部構造改善 | Refactor |
| 依存更新 | Retrofit |
| 誤claim/暴走 | Recovery |

## 11.5 差し込みの優先順

1. existing optional slot
2. existing extension point
3. new region in existing screen
4. tab / drawer / disclosure
5. new screen

画面を増やす前に既存Patternで成立するか確認します。ただし無理な詰め込みは禁止します。

## 11.6 分割・統合判断

判断軸:

- user taskが別か
- permissionが別か
- data refreshが別か
- information density
- navigation depth
- error boundary
- usage frequency
- responsive conflict

## 11.7 期限

`observing`はexpiry gateを必須にします。期限切れで自動実装せず、finding化します。

## 11.8 Back-propagation

変更承認後:

```text
L2 ledger revision
→ L3 FR/AC revision
→ L4 profile/rule impact
→ L5 binding
→ L6 spec/test
→ L7 add-impl
→ L10 evidence
```
