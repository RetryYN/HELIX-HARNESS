# 2. 目標構想 — UX–FE Continuity Harness

## 2.1 正体

Design Harness内蔵化は、AIが画面を描くための絵画ルールではありません。

> 利用者価値、画面構造、フロント成立条件、実装、UX検証を同じ契約IDで持ち回る、UT-TDD Forwardの横断契約です。

## 2.2 不変原則

1. **利用者価値優先**: backendの内部構造をそのままUIへ出さない。
2. **継続利用優先**: 初見の派手さより、反復利用の疲労と迷いを減らす。
3. **視認性優先**: 状態、重要度、次の操作を誤認させない。
4. **証跡到達性**: 要約しても、根拠へdrill-downできる。
5. **制約付き生成**: AIは白紙から描かず、Pattern Contractを選んで構成する。
6. **実装遅延禁止**: L2設計だけを完了させ、L7 frontend missionを未計画にしない。
7. **早期実装固定禁止**: L2でclass、props、APIを固定しない。
8. **安全な追加**: 新機能はcandidate/observingから差し込む。
9. **正本単一性**: authored sourceが正本、DBはprojection。
10. **実測主義**: responsive、a11y、motion、real-dataはL10で実レンダリング検証する。

## 2.3 三つの契約面

### Experience Contract

誰が、何を、どの頻度で、どの重要度で達成するか。

### UI Contract

何を、どの順で、どの画面型・領域・状態で見せるか。

### Frontend Contract

どのデータ、状態、イベント、権限、ログ、エラー境界で成立させるか。

三つを分けますが、`screen_id / region_id / action_id / state_id`で接続します。

## 2.4 マーケター統合責務

初期導入では既存PO roleをExperience Ownerとして利用します。

| 責務 | Experience Owner | UIUX | TL/SE | QA |
|---|---|---|---|---|
| 利用者・市場・事業目的 | 決定 | 助言 | 制約提示 | 検証観点 |
| 情報優先順位 | 決定 | 設計 | 実現性確認 | 認知負荷確認 |
| UI構造 | 承認 | 主設計 | データ成立性 | 状態網羅 |
| フロント境界 | 意図確認 | 表示責務 | 主設計 | 結合観点 |
| 実装 | 受入責任 | design review | 主実装 | test/review |
| L10 | 継続利用・価値判断 | UX review | 修正 | 実測 |

## 2.5 Operational / Expressive

### Operational UI

- 常用
- 高頻度
- 高重要度
- 予測可能
- 低motion
- 低装飾
- 高視認性

### Expressive UI

- オンボーディング
- 紹介
- 達成
- キャンペーン
- 非常用ブランド表現

### Mixed UI

常用画面の骨格はOperational、empty/success/onboarding等の限定RegionだけExpressiveにします。

## 2.6 成功条件

- L2 screen contractに孤児がない。
- L5 bindingに未接続Regionがない。
- L7実装済みclaimにmission欠落がない。
- L10で実データ・responsive・motion・a11y証跡がある。
- 変更が上流へback-propagateされる。
- UIとbackendの用語が一致しつつ、内部構造の露出はprogressive disclosureで制御される。
