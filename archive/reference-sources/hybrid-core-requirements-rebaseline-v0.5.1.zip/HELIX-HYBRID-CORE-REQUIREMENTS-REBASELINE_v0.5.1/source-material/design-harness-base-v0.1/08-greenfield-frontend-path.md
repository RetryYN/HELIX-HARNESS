# 8. フロント実装ゼロからのGreenfield Frontend Path

## 8.1 なぜ必要か

今回のハーネス構築では、画面文書に対してフロント実装がほぼゼロです。通常の「設計から実装へ」という一文だけでは、AIはdocsを揃えた時点で完了に寄りやすくなります。

そこで、L7 frontendを画面数ではなくmissionで閉じます。

## 8.2 Frontend Mission

### UI-M0 Activation

- UI profile選択
- frontend stack決定（L4/L5）
- build/test/render command
- source/test配置

### UI-M1 Foundation

- App shell
- routing
- token binding
- global error boundary
- typed view-state primitive
- test/render harness

### UI-M2 Shared Patterns

- navigation
- status
- loading/empty/error
- table/list
- disclosure
- evidence link
- copy/command handoff

### UI-M3 Screen-specific Composition

各screenが少なくとも1つの固有Pattern/Region compositionを持つこと。汎用table 1枚で全画面を代替しない。

### UI-M4 Data Binding

- actual projection/API/file source
- provenance
- stale
- partial failure
- retry/refresh
- redaction

### UI-M5 Interaction

- route/query state
- primary/secondary action
- keyboard
- focus
- validation
- no forbidden side effect

### UI-M6 Adaptive Quality

- responsive transformations
- motion contract
- reduced motion
- a11y
- long text / large data

### UI-M7 Evidence & Trace

- source path
- test path
- render/screenshot evidence
- contract ID
- review evidence
- implementation status

## 8.3 実装状態

| status | 条件 |
|---|---|
| not_started | codeなし |
| foundation_ready | M0-M1完了 |
| skeleton_rendered | route + semantic structure |
| data_bound | M4完了 |
| states_complete | required state matrix完了 |
| interaction_complete | M5完了 |
| responsive_complete | M6 responsive完了 |
| implemented | M0-M7 + unit/integration green |
| ux_verified | G10 evidence green |

## 8.4 implemented claimの禁止条件

次のいずれかがあれば`implemented=false`です。

- routeだけ
- placeholderだけ
- static screenshotだけ
- generic table dumperだけ
- mock dataのみで実data planなし
- loading/empty/error欠落
- screen-specific Region欠落
- testsなし
- contract traceなし
- responsive contract未実装
- evidenceなし

## 8.5 WBSの切り方

L6で画面単位だけでなくfoundation/shared/screen/data/qualityへ分けます。

```text
Sprint A: foundation
Sprint B: shared operational patterns
Sprint C: PM daily-use screens
Sprint D: HM diagnostics screens
Sprint E: GD docs/expressive regions
Sprint F: responsive/a11y/motion
Sprint G: G10 evidence
```

## 8.6 TDD

L6 oracleからL7テストを先行します。

- route registry
- query round-trip
- view-state preservation
- event side-effect restrictions
- binding completeness
- screen-specific composition
- token hardcode absence
- responsive invariant
- reduced-motion behavior

## 8.7 中央UIの優先dogfood

最初の4画面:

1. PM-01: dashboard/responsive/priority
2. PM-03: diagnostic/next action/evidence
3. HM-05: log/provenance/density
4. HM-07: doctor/result hierarchy

これで主要Patternを検証できます。
