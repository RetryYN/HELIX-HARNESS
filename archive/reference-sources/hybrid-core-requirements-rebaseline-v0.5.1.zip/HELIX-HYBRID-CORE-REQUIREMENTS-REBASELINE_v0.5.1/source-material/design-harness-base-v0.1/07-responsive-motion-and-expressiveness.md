# 7. Responsive、Motion、視認性、遊び心

## 7.1 Responsiveは画面別画像ではなく変形契約

```yaml
responsive:
  strategy: priority-stack
  wide:
    layout: two-column
  medium:
    layout: main-plus-collapsible-evidence
  narrow:
    layout: single-column
  preserve:
    - failure_reason
    - next_action
  move:
    - evidence_to_disclosure
  forbid:
    - critical_action_hidden
    - text_scale_below_profile_min
```

## 7.2 Desktop-onlyも契約が必要

`desktop_only`はresponsive免除ではありません。

必須:

- minimum safe width
- overflow container
- zoom 200%時の挙動
- long text
- window resize
- keyboard-only
- critical information clipping禁止

## 7.3 Layout実装順

```text
1. semantic structure
2. information priority
3. responsive containers
4. data states
5. controls
6. typography/tokens
7. decoration
8. motion
```

装飾から始めません。

## 7.4 Motion budget

| Surface | Budget | 許可 | 禁止 |
|---|---|---|---|
| operational-high-critical | minimal | focus、open/close、save/result feedback | page spectacle、loop |
| operational-normal | low | state transition、progress、reorder cue | background animation |
| mixed | region-based | expressive regionのみ | operational regionへの波及 |
| expressive | medium | onboarding、achievement、story | reduced-motion無視 |

## 7.5 Motion contract

- duration range
- easing family
- trigger
- repeat count
- layout shift policy
- interruption
- reduced-motion fallback
- re-run condition

## 7.6 Decoration budget

利用頻度と重要度から決めます。

```text
高頻度 × 高重要度 → low
低頻度 × 低重要度 → medium/high可
高頻度 × 低重要度 → low/medium
低頻度 × 高重要度 → controlled emphasis
```

## 7.7 遊び心の入れ場所

推奨:

- empty state
- completion
- onboarding
- new feature introduction
- campaign
- easter egg（業務を阻害しない）

非推奨:

- log table
- error diagnosis
- permission decision
- high-frequency navigation
- destructive confirmation

## 7.8 視認性

- information hierarchy
- color + icon + label
- consistent location
- whitespace by meaning
- long-session contrast
- number alignment
- table density profile
- progressive disclosure

## 7.9 継続利用検証

L10では初見レビューだけでなく、反復taskを検証します。

- 同一task 5回
- 連続30分利用
- 状態切替
- stale/partial data
- keyboard navigation
- back/forward/share
- userが次actionを言語化できるか
