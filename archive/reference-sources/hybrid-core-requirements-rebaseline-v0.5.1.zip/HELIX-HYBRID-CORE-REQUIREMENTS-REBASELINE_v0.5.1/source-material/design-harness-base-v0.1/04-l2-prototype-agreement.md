# 4. L2 Prototype Agreementと想定画面台帳

## 4.1 L2の目的

L2は完成デザインを固定する工程ではありません。

> 画面を媒体にして、利用者目的、情報優先順位、主要状態、導線、responsive意図、未確定依存を合意する工程です。

## 4.2 L2で固定するもの

- Screen ID
- Purpose / Persona / Usage frequency / Criticality
- Surface class（operational / expressive / mixed）
- Pattern ID
- Region / Slotと読み順
- Primary action intent
- 情報優先順位
- State family
- Transition intent
- Responsive transformation
- Motion / decoration budget
- Extension point
- Unresolved dependency
- L1/L3 trace
- Low-Fi evidence

## 4.3 L2で固定しないもの

- framework
- source file
- class / module
- component implementation name
- props型
- state management library
- API endpoint
- DB schema
- logging field
- event bus
- animation library

L2文書にこれらが必要になった場合は、`implementation_hint`として非binding参照に留めるか、L5 carryへ移します。

## 4.4 Screen Ledgerの二軸状態

### Design lifecycle

```text
candidate → assumed → observing → confirmed → revised → retired
```

### Implementation lifecycle

```text
not_started
→ foundation_ready
→ skeleton_rendered
→ data_bound
→ states_complete
→ interaction_complete
→ responsive_complete
→ implemented
→ ux_verified
```

二軸を混ぜません。`confirmed`な画面でも`not_started`は正常です。ただし、L7への実装PLANが無い状態を長期放置しないようreadiness gateが検出します。

## 4.5 Region / Slot

L2はFigma的な階層構造を借りますが、実装componentではなく意味構造を持ちます。

```text
Screen
├─ Region: summary
│  ├─ Slot: current-status
│  └─ Slot: impact
├─ Region: action
│  └─ Slot: next-action
└─ Region: evidence
   ├─ Slot: evidence-list
   └─ Slot: raw-detail
```

`Region`は責務、`Slot`は情報または操作の受け口です。

## 4.6 Prototype evidence

許可されるevidence:

- ASCII / Mermaid / SVG
- static HTML
- screenshot
- Figma等の外部URL参照
- approved image artifact

禁止:

- プロトコードをそのままL7本実装扱いにする
- evidenceだけで契約を省略する
- 画像内の情報を正本にする

## 4.7 G2合意者

- Experience Owner（PO slot）
- UIUX
- TL

高重要度画面はQAのtest perspective確認を加えます。

## 4.8 未確定事項の扱い

未確定は欠陥ではありません。宙に浮くことが欠陥です。

```yaml
unresolved:
  - id: UNR-PM03-LOG-01
    question: ログ詳細を同画面に出すか別画面に分離するか
    depends_on: [logging-contract, permission-model]
    decision_layer: L5
    default_behavior: EXT-DIAGNOSTICSを非表示
    expiry_gate: G5
```

## 4.9 安全な差し込み

新しい機能は、まずextension pointへ候補として差し込みます。

```text
candidate → observing → approved
                      ├ merge
                      ├ split
                      ├ optional
                      └ reject
```

例は `examples/ui-change-delta-log-console.yaml` を参照してください。
