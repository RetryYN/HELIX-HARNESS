# 13. Rolloutと中央UI Dogfood

## 13.1 Phase 0 — Normalize

完了条件:

- 工程順矛盾解消
- L2 sub-doc catalog一致
- G2 marker regex依存の問題をdocumented
- implementation statusの二軸化

## 13.2 Phase 1 — Rule-only

- governance
- process/ui
- schemas
- templates
- skill pack

まだconsumerにhard gateをかけません。

## 13.3 Phase 2 — Central UI dogfood

対象4画面:

### PM-01

検証:

- dashboard pattern
- information priority
- heatmap + drilldown
- responsive overflow/stack

### PM-03

検証:

- diagnostic pattern
- next action
- evidence progression
- extension point

### HM-05

検証:

- log/provenance
- density
- filters
- redaction

### HM-07

検証:

- hierarchical result
- severity
- remediation
- doctor integration

## 13.4 Phase 3 — Soft doctor

warning:

- profile missing
- L2 boundary drift
- binding orphan
- mission incomplete

## 13.5 Phase 4 — Hard G2/G5/G6

新規または変更されたUI PLANだけhard化。既存unchanged assetは移行期限を持つ。

## 13.6 Phase 5 — G7 implementation hard gate

`implemented` claimをmission-derivedに変更。

## 13.7 Phase 6 — G10 evidence hard gate

responsive/a11y/motion/continuity/real-dataを必須familyにする。

## 13.8 Phase 7 — Pack distribution

- root `skills/ui-continuity/`
- adapter docsは参照のみ
- setupでprofile templateを投影
- engine tag pinで更新

## 13.9 Dogfood metrics

- L2→L7 lead time
- design-only orphan count
- screen binding orphan count
- generic table substitution count
- implemented claim retraction count
- G10 defect back-prop count
- responsive defect count
- repeated-task completion time
- evidence drilldown success

## 13.10 Exit criteria

- 4画面がM0-M7完了
- G2/G5/G6/G7/G10がgreen
- unapproved delta 0
- typed spec orphan 0
- UI/FE trace 100%
- false implemented claim 0
