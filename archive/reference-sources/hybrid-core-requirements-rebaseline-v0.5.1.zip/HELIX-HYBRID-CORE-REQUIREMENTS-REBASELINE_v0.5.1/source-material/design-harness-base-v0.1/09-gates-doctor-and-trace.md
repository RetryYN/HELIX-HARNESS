# 9. Gate、doctor、trace設計

## 9.1 新Gate番号は増やさない

既存G1〜G10へsub-checkを追加します。

## 9.2 G1 Experience Trace

Hard:

- screen requirementにuser/persona/purposeがある
- BR/UX/Screenのtrace
- usage frequency / criticality
- surface class

## 9.3 G2 Prototype Agreement

### G2-ledger

- 全screen IDがledgerに存在
- duplicateなし
- lifecycle明示

### G2-purpose

- user task
- business goal
- information priority

### G2-structure

- pattern
- required Region
- states
- transitions

### G2-adaptability

- responsive strategy
- motion/decorative budget
- extension points

### G2-boundary

- L2にframework/class/API/props bindingを固定していない
- unresolvedがdecision layerを持つ

### G2-agreement

- prototype evidence
- PO/Experience Owner、UIUX、TL review
- ledger/evidenceのrevision一致

## 9.4 G3 Screen Functional

- 全Action intentにFR/AC
- data/error/permission/logging requirement
- L2で発見したgapのback-merge
- hidden implementation requirement禁止

## 9.5 G4 UI Rule/Profile Freeze

- Rule Pack version
- Product UI Profile
- token SSoT
- responsive/motion/a11y standard
- operational/expressive classification
- hardcoded value禁止方針

## 9.6 G5 Frontend Binding Freeze

- required Slotのbinding孤児0
- state owner
- data source/provenance
- event/side-effect
- logging/permission/redaction
- integration test-design pair

## 9.7 G6 Implementation Readiness

- per-screen function spec
- Frontend Mission WBS
- unit oracle
- implementation order
- unresolved expiry 0
- L7 PLAN生成済み

## 9.8 G7 Implementation Freeze

- code exists
- screen-specific composition
- M0-M7 complete
- tests green
- contract/source/test/evidence trace
- unapproved UI delta 0

## 9.9 G8/G9

### G8

- route → adapter → data → component integration
- query round-trip
- error/empty/stale/loading
- responsive container integration

### G9

- token consistency
- cross-screen navigation
- system accessibility
- visual regression
- performance budget

## 9.10 G10 UX Verification

既存familyに追加:

- UXV-RESPONSIVE
- UXV-MOTION
- UXV-CONTINUITY
- UXV-REALDATA
- UXV-EXPRESSION

## 9.11 Doctor checks proposal

| check | severity | 内容 |
|---|---|---|
| `ui-activation-profile` | hard | UI対象なのにprofileなし |
| `g2-prototype-contract` | hard | L2契約欠落 |
| `ui-l2-boundary` | hard | L2に実装固定field |
| `ui-rule-profile` | hard | L4 rule/profile/token不整合 |
| `ui-binding-completeness` | hard | Slot/binding孤児 |
| `ui-implementation-readiness` | hard | G6なのにL7 missionなし |
| `ui-implementation-mission` | hard | implemented claimとmission不一致 |
| `ui-contract-trace` | hard | L1→L10 ID断絶 |
| `ui-delta-routing` | hard/warn | unapproved delta / observing期限超過 |
| `ui-expression-budget` | warning | operationalに過剰表現 |
| `g10-ux-workflow` | hard | evidence family欠落 |

## 9.12 `screen-impl-pair-freeze`の置換

現行checkは次へ置換します。

```text
ui-pair-design-readiness
  L2↔L10 test designが凍結済みか

ui-implementation-readiness
  L4-L6 + L7 PLANが揃ったか

ui-implementation-mission
  G7 claimが実装証跡を持つか

ui-ux-execution
  G10実施済みか
```

## 9.13 Trace graph

最低edge:

```text
BR/UX → Screen
Screen → Region/Slot
Region/Slot → FR/AC
Region/Slot → Binding
Binding → Function Spec
Function Spec → Source
Function Spec → Unit Test
Screen → UXV
UXV → Evidence
```
