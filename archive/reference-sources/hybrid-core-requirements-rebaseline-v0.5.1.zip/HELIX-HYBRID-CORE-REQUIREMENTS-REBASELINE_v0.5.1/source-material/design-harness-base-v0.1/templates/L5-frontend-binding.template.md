---
layer: L5
sub_doc: ui-binding
status: draft
pair_artifact: docs/test-design/<product>/L8-integration-test-design.md
next_pair_freeze: L8
---

# <SCREEN-ID> Frontend Binding

## Binding matrix

| Binding ID | Region/Slot | View model | Data source | State owner | Event | Permission | Logging | Test |
|---|---|---|---|---|---|---|---|---|

## State handling

| State | UI behavior | Source condition | Recovery |
|---|---|---|---|
| loading | | | |
| ok | | | |
| empty | | | |
| stale | | | |
| partial | | | |
| error | | | |

## Responsive implementation

| Contract | Implementation rule | Test |
|---|---|---|

## Motion implementation

| Contract | Implementation rule | Reduced-motion | Test |
|---|---|---|---|

## Security / redaction

## Orphan check

- required slots:
- bound slots:
- approved defers:
- orphan count: 0
