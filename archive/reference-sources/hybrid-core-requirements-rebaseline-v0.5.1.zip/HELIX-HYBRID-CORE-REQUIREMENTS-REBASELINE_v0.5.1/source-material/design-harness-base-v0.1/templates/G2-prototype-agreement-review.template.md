# G2 Prototype Agreement Review

- Screen / scope:
- Revision:
- Reviewer roles:

## G2-ledger

- [ ] Screen ID unique
- [ ] Design lifecycle present
- [ ] Product UI Profile linked

## G2-purpose

- [ ] User task
- [ ] Business goal
- [ ] Frequency / criticality
- [ ] Information priority

## G2-structure

- [ ] Pattern selected
- [ ] Required Regions present
- [ ] States present
- [ ] Action intent present

## G2-adaptability

- [ ] Responsive strategy
- [ ] Motion/decorative budget
- [ ] Extension points

## G2-boundary

- [ ] No implementation class/API binding
- [ ] Unresolved items have owner layer/expiry

## G2-trace/evidence

- [ ] L1 trace
- [ ] L3 target
- [ ] L10 UXV target
- [ ] Prototype evidence revision matches

## Verdict

PASS / FAIL / DEFER
