---
plan_id: PLAN-L<layer>-NN-<slug>
title: "UI workstream: <title>"
kind: design
layer: L<layer>
drive: fe
status: draft
parent_design: null
agent_slots:
  - role: po
    slot_label: "Experience Owner"
  - role: tl
    slot_label: "TL — continuity and technical boundary"
  - role: uiux
    slot_label: "UIUX — pattern and usability"
  - role: qa
    slot_label: "QA — paired verification"
generates: []
dependencies:
  parent: null
  requires: []
  blocks: []
---

# Goal

# Experience / UI / FE scope

# Contract IDs

# Frontend missions

# Pair/test design

# Gate

# Evidence

# Back-propagation
