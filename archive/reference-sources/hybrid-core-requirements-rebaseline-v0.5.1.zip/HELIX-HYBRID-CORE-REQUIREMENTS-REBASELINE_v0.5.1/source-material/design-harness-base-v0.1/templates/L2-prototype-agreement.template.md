---
layer: L2
sub_doc: screen-detail
status: draft
pair_artifact: docs/test-design/<product>/L10-ux-validation-test-design.md
next_pair_freeze: L10
product_ui_profile: docs/design/<product>/L4-ui/ui-profile.yaml
---

# <SCREEN-ID> Prototype Agreement

## Experience

| Field | Value |
|---|---|
| User | |
| User task | |
| Business goal | |
| Frequency | |
| Criticality | |
| Surface class | operational / expressive / mixed |

## Information priority

1.
2.
3.

## Pattern

- Pattern ID:
- Rationale:

## Regions and slots

| Region ID | Purpose | Required | Reading order | Slots |
|---|---|---:|---:|---|

## Actions

| Action ID | Intent | Priority | Result intent |
|---|---|---|---|

## State family

- loading
- ok
- empty
- stale
- partial
- error

## Responsive

- Strategy:
- Preserve:
- Transform:
- Forbidden:

## Motion / decoration

- Motion budget:
- Allowed:
- Forbidden:
- Reduced-motion fallback:
- Decoration budget:

## Extension points

| ID | Status | Accepts | Dependency |
|---|---|---|---|

## Unresolved

| ID | Question | Dependency | Decision layer | Expiry gate | Default behavior |
|---|---|---|---|---|---|

## Trace

- BR/UX:
- Screen requirement:
- L3 target:
- UXV target:

## Prototype evidence

- Type:
- Path/reference:
- Revision:

## Approval

- Experience Owner:
- UIUX:
- TL:
