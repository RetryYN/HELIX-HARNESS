---
layer: L6
sub_doc: screen-spec
status: draft
pair_artifact: docs/test-design/<product>/L7-unit-test-design.md
next_pair_freeze: L7
---

# <SCREEN-ID> Screen Function & Frontend Mission

## Function contracts

| Function | Pre | Post | Invariant | Unit oracle |
|---|---|---|---|---|

## Events

| Action ID | Input | Output | Forbidden side effect | Oracle |
|---|---|---|---|---|

## Frontend missions

| Mission | Scope | Source target | Test target | Evidence | Status |
|---|---|---|---|---|---|
| UI-M0 | activation | | | | pending |
| UI-M1 | foundation | | | | pending |
| UI-M2 | shared pattern | | | | pending |
| UI-M3 | screen-specific composition | | | | pending |
| UI-M4 | data binding | | | | pending |
| UI-M5 | interaction | | | | pending |
| UI-M6 | responsive/a11y/motion | | | | pending |
| UI-M7 | evidence/trace | | | | pending |

## Implementation order

1.
2.
3.

## L7 entry

- unit tests authored red:
- unresolved expiry count: 0
- L7 PLAN:
