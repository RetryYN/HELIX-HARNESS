# 12. 既存リポジトリへのPatch MapとPLAN順序

## 12.1 先に直す矛盾

### Patch A: 工程順

対象:

- `src/lint/screen-impl-pair-freeze.ts`
- `docs/design/harness/L2-screen/screen-list.md`
- `docs/design/harness/L2-screen/wireframe.md`
- `docs/design/harness/L4-basic-design/ui-standard.md`
- `docs/design/harness/L10-ux/visual-design.md`
- `docs/test-design/harness/L10-ux-validation-test-design.md`

変更:

- L10到達をL7実装前提にしない。
- pair design freezeとpair executionを分離。
- `implemented`と`ux_verified`を分離。

### Patch B: L2/L5境界

対象:

- `docs/design/harness/L2-screen/ui-element.md`
- `docs/design/harness/L2-screen/screen-detail.md`
- `docs/design/harness/L5-detailed-design/ui-detail.md`
- `docs/design/harness/L6-function-design/screen-spec.md`

変更:

- L2のprops/state/event実装契約をsemantic Region/Slotへ変更。
- 実装bindingをL5へ移動。

### Patch C: Rule Pack / Product Profile分離

対象:

- `docs/design/harness/L4-basic-design/ui-standard.md`
- `docs/design/harness/L4-basic-design/tokens.yaml`
- 新規 `docs/process/ui/`

変更:

- 共通原則を`docs/process/ui/`へ移す。
- 中央UI固有値はProduct UI Profileとして残す。

### Patch D: G2内容検査

対象:

- `src/vmodel/lint.ts`
- doctor wiring
- `tests/vmodel-forward-freeze-contracts.test.ts`

変更:

- regex markerをschema/typed spec検査へ置換。
- required L2 docのhard-coded path依存をdocument catalog/profileへ寄せる。

### Patch E: Frontend Mission

対象:

- L6 screen spec / WBS
- L7 PLAN schema/roadmap
- doctor
- relation graph
- central UI implementation plans

変更:

- per-screen mission ledger
- implemented claim導出
- screen-specific composition check

## 12.2 Governance更新

- `docs/governance/ut-tdd-agent-harness-concept_v3.1.md`
- `docs/governance/ut-tdd-agent-harness-requirements_v1.2.md`
- `docs/process/forward/overview.md`
- `docs/process/gates.md`
- `docs/governance/vmodel-document-catalog.md`
- `docs/governance/vmodel-typed-spec-definitions.md`

## 12.3 PLAN sequence proposal

### Slice 0 — Recovery/normalization

現行のL2→L10→impl矛盾、4/6 sub-doc表記差、実装claim定義を正規化。

### Slice 1 — L1/L2 concept and requirements

Experience Contract、Prototype Agreement、Screen Ledger、surface class。

### Slice 2 — Rule Pack and Product Profile

共通UI原則、Pattern、responsive/motion、中央UI profile。

### Slice 3 — L2/L5 boundary migration

Region/Slot化、props/state/eventのL5移管。

### Slice 4 — Typed spec and schemas

UI ID、trace、ledger schema、delta schema。

### Slice 5 — G2/G4/G5/G6 doctor gates

content validation、binding completeness、implementation readiness。

### Slice 6 — Frontend Mission and G7

mission ledger、implementation claim、source/test/evidence trace。

### Slice 7 — G10 expansion

responsive、motion、continuity、real-data family。

### Slice 8 — Central UI dogfood

PM-01、PM-03、HM-05、HM-07。

### Slice 9 — Pack injection

`skills/ui-continuity`とlayer injectionをPackへ同期。

## 12.4 PLAN kind/route案

- 矛盾是正: Recovery → Reverse normalization
- 新契約: add-design L1-L6
- gate実装: add-impl L7
- central UI実装: impl/add-impl L7 drive=fe/fullstack
- G10 test: L10 test design + evidence

## 12.5 移行ポリシー

- 既存15画面IDを維持
- existing docsを一括破棄しない
- additive revisionで移行
- old fieldsにdeprecation marker
- doctor warning → hardの段階適用
- central UI dogfood green後にconsumer profileをhard化
