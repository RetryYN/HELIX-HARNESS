# 14. Design Harness内蔵化の受入条件

## AC-01 内蔵方式

Given UT-TDD coreが存在する
When Design Harnessを導入する
Then 新しい独立engine/mode/layer/DB正本を追加せず既存Forward、schema、doctor、skill injectionへ統合する。

## AC-02 L2境界

Given L2 Prototype Agreement
When schemaを検査する
Then framework class、API、props/state ownerはbinding fieldとして確定されておらず、L5 carryが存在する。

## AC-03 Prototype Agreement

Given UI scopeがactive
When G2を実行する
Then purpose、persona、frequency、criticality、pattern、regions、states、responsive、motion、unresolved、trace、evidenceが検査される。

## AC-04 L2/L10順序

Given L10 test designがpair-frozen
When L7 implementationを開始する
Then L10実施完了は要求されず、L4-L6 readinessが要求される。

## AC-05 Binding

Given required Slotが存在する
When G5を実行する
Then concrete binding、static source、approved deferのいずれも無いSlotはfailする。

## AC-06 Frontendゼロ検出

Given L2 confirmed screensが存在する
When G6を実行する
Then対応L7 frontend mission/PLANが無い場合はblockまたは明示version deferを要求する。

## AC-07 Implemented claim

Given screenがimplementedをclaimする
When G7を実行する
Then route、screen-specific composition、data、states、interaction、responsive、tests、evidence、traceが全て必要になる。

## AC-08 Generic table防止

Given複数screenがある
When implementation coverageを評価する
Then同じ汎用tableだけで固有Regionを持たないscreenはimplementedとして数えない。

## AC-09 Rule/Profile分離

Given中央UT-TDD UIの具体token/desktop制約
When共通Rule Packを配布する
Then中央UI固有値はProduct UI Profileに留まり、consumer共通規則へ固定されない。

## AC-10 Responsive

Given UI profile
When screen contractを作る
Then responsive strategyまたは明示desktop-only safe behaviorが必須になる。

## AC-11 Motion

Given operational screen
When motion contractを評価する
Then continuous decorationは拒否され、reduced-motion fallbackが存在する。

## AC-12 Expressiveness

Given mixed surface
When expressive Regionを追加する
Then対象Region、利用頻度、budgetが明示され、operational primary taskを阻害しない。

## AC-13 Trace

Given screen contract
When relation graphを構築する
Then BR/UX→Screen→Region/Slot→FR/AC→Binding→Function→Source/Test→UXV/Evidenceの孤児が0になる。

## AC-14 Delta

Given後工程で画面機能の抜けが見つかる
When差し込む
Then UI Change Deltaとしてcandidate/observing/approvedを経て、適切なmodeへrouteされる。

## AC-15 L10

Given implemented screen
When G10を実行する
Then visual/token/a11y/VRT/reviewに加えresponsive/motion/continuity/real-data evidenceが評価される。

## AC-16 Projection

Given UI contractがauthoring sourceにある
When DB rebuildする
Thenprojectionは更新されるが、DBからauthoring sourceを書き換えない。
