# 1. 現状評価とギャップ分析

## 1.1 現在の強み

現行リポジトリは、Design Harnessを差し込む土台として強い構造を既に持っています。

- L0〜L14のV-model
- 設計、実装、テスト設計、テストコードの別置き
- pair-freeze / trace-freeze
- PLAN frontmatterとtyped spec
- `doctor` fail-close
- `harness.db`を非正本のprojectionとして扱う原則
- layer-context / skill injection
- screen-designとfrontend-designをForward内の工程専門として扱う考え方

したがって、別製品を作るより既存の契約鎖を補強する方が合理的です。

## 1.2 現在の画面設計鎖

現行文書から読み取れる画面系の鎖は以下です。

```text
L1 screen-requirements
L2 business-flow / screen-detail / screen-flow / screen-list / ui-element / wireframe
L3 screen-functional
L4 ui-standard / tokens
L5 ui-detail
L6 screen-spec
L7 src/web implementation
L10 UX validation
```

この鎖自体は正しい方向です。しかし、工程境界と完了判定に複数の不整合があります。

## 1.3 Critical gap

### GAP-C1: L2がフロント詳細へ踏み込みすぎる

現行 `L2-screen/ui-element.md` は再利用コンポーネント、props、state、eventをL2で確定し、L4もそれを変更しない前提です。

問題:

- ログschema、API、権限、データ量が後続で変わる。
- 早期のcomponent boundaryが誤った実装制約になる。
- 抜け漏れを安全に差し込む余地が減る。
- L5 `ui-detail` と責務が重複する。

是正:

- L2の `ui-element` を **semantic region / slot / action intent** に変更する。
- props/state/event/component boundaryはL5へ移す。
- L2では `unresolved_dependencies` と `extension_points` を正式要素にする。

### GAP-C2: G2 Prototype Agreementが内容を検証していない

現行のforward freeze contractは、L2文書の存在、`confirmed`、L10 pair、本文中の合意らしい文字列を検査します。

問題:

- 利用者目的がなくても通る。
- responsive契約がなくても通る。
- 未確定依存が宙に浮いても通る。
- プロトと台帳の不一致を見ない。
- 実装詳細をL2に固定しても検知しない。

是正:

- G2を6つのsub-gateへ分解する。
- `prototype_agreement` schemaをtyped specとして正本化する。
- marker regexではなく必須fieldとtraceで検査する。

### GAP-C3: 工程順が矛盾している

現行 `screen-impl-pair-freeze` はL10到達前の実装宣言を止め、説明上は `L2 → L10 → src/web` です。一方、L4/L10文書は `L2 → L4 → L6 → L7 → L10` に是正されています。

問題:

- L10は実装後のUX検証なのに、実装前条件として扱われる。
- pair設計の凍結と、pair実施工程の到達が混同される。
- 実装が永遠に始まらないか、別のclaimで迂回される。

是正:

- `next_pair_freeze` の意味を「右腕テスト設計の凍結先」と明記する。
- `pair_design_ready` と `pair_execution_complete` を分ける。
- `implemented_at=G7`、`ux_verified_at=G10`を別statusにする。

### GAP-C4: フロントの実装完遂定義が弱い

今回のハーネス開発では、設計文書に対してフロント実装が限りなくゼロに近い状態です。

主因:

- screen countやroute countで実装被覆を誤認できる。
- generic table dumperで複数画面を代替できる。
- L7のFrontend Missionが工程表に独立していない。
- component/state/data/responsive/evidenceの完遂を1つのclaimに集約している。

是正:

- per-screen `implementation_missions` を導入する。
- screen-specific patternが無い画面を実装済みにしない。
- route、data、state、responsive、test、evidenceを別々に閉じる。
- `implemented_screens`自由文字列を廃止し、typed ledgerから導出する。

## 1.4 Important gap

### GAP-I1: 共通規約と中央UI固有設計が混在

現在のL4 UI標準は、15画面、Desktop専用、light、日本語、1024px、具体色など中央UT-TDD UI固有の内容を含みます。

是正:

```text
Harness Rule Pack     全案件共通
Product UI Profile    案件固有
Screen Ledger         画面固有
```

### GAP-I2: raw data常時露出がエンジニア最適に寄りすぎる

現行標準は「サマリのみ禁止」「raw data粒度優先」を強く要求します。証跡への到達性は重要ですが、すべてを最初から露出すると利用者の判断を阻害します。

是正原則:

> Decision first, evidence available.

- 初期表示: 利用者の判断に必要な情報
- drill-down: 根拠、raw row、source path
- 監査画面: 高密度を許可
- 日常画面: raw dataを全面に出さない

### GAP-I3: Desktop-onlyを汎用ルールにできない

中央管理UIのDesktop-onlyは案件profileとしては許容できます。しかしDesign Harness共通ルールとしては、各profileがresponsive strategyを宣言する必要があります。

`desktop_only`であっても次を定義します。

- safe minimum width
- overflow strategy
- window縮小時の優先順位
- critical actionが隠れないこと
- zoom / text scaling

### GAP-I4: 遊び心の許可範囲が型化されていない

是正:

- operational surface
- expressive surface
- mixed surface

という分類と、motion/decorative budgetを持たせます。

## 1.5 改修しないもの

- 新しい描画エンジン
- 新しいDB正本
- 新しいV-model layer
- 新しい独立mode
- Figma互換形式
- プロトコードの本番昇格

既存のTS/Bun core、schema、doctor、PLAN、skill injectionへ追加します。
