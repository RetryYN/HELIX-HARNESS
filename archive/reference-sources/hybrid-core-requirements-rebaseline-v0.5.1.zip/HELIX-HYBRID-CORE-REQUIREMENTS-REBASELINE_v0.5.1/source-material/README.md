# Source material

`design-harness-base-v0.1/`は、ユーザーがHELIX Design HARNESSの設計ベースとして提示したraw sourceである。
内容をbyte-preservedで保持し、HELIX化の差分・provenance・回帰比較に使う。

このdirectory内のUT固有名称・path・role・DB・PLANはactive HELIX contractではない。
active definitionsは`design-harness/`、`schemas/design-harness/`、`requirements/`を参照する。
