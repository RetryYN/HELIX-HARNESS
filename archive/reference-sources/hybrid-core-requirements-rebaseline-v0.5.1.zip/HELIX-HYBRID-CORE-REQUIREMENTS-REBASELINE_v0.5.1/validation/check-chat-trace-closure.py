#!/usr/bin/env python3
"""IC-03 是正: chat_trace_closure を要件単位（sources中の各CHAT-ID）で突合する。

requirements-catalog.yaml の各要件 `sources` に列挙された CHAT-ID それぞれについて、
requirements/traceability.yaml に `from: <CHAT-ID> / to: <requirement id> / type: refined_into`
の edge が存在するかを検査する。従来の「CHAT-IDが最低1回使われているか」という粗い集計ではなく、
要件×CHAT-IDの組ごとに厳密突合する。

exit code 0: 不一致0件。exit code 1: 不一致あり（不一致リストをstdoutへ列挙）。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    print("PyYAML is required to run this validation script", file=sys.stderr)
    sys.exit(2)

PACKAGE_ROOT = Path(__file__).resolve().parent.parent
CATALOG_PATH = PACKAGE_ROOT / "requirements" / "requirements-catalog.yaml"
TRACE_PATH = PACKAGE_ROOT / "requirements" / "traceability.yaml"


def main() -> int:
    catalog = yaml.safe_load(CATALOG_PATH.read_text(encoding="utf-8"))
    trace = yaml.safe_load(TRACE_PATH.read_text(encoding="utf-8"))

    refined_pairs = {
        (edge["from"], edge["to"])
        for edge in trace.get("edges", [])
        if edge.get("type") == "refined_into"
    }

    gaps: list[tuple[str, str]] = []
    checked_pairs = 0
    for requirement in catalog.get("requirements", []):
        requirement_id = requirement.get("id")
        for source in requirement.get("sources") or []:
            if not str(source).startswith("CHAT-"):
                continue
            checked_pairs += 1
            if (source, requirement_id) not in refined_pairs:
                gaps.append((source, requirement_id))

    if gaps:
        print(f"chat_trace_closure: MISMATCH — {len(gaps)} 件不一致 / {checked_pairs} 組中")
        for source, requirement_id in gaps:
            print(f"  missing refined_into edge: {source} -> {requirement_id}")
        return 1

    print(
        f"chat_trace_closure: OK — 要件単位で不一致0件（{checked_pairs} 組のCHAT-ID×要件を検査）"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
