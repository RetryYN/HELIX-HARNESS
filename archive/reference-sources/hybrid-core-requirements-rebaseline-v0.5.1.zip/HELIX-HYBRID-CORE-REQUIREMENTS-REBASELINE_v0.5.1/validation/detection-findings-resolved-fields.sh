#!/usr/bin/env bash
# validation/detection-findings-resolved-fields.sh
#
# 是正F1の機械検証。sqlite3 CLIでdatabase/detection-system-schema.sqlを直接ロードし、
# detection_findings.resolved_by / detection_findings.residual_risk のNULLABLE設計を検証する。
# DETECTION-DB-02是正: status/resolved_by/residual_risk整合をDB CHECK制約で強制することを検証する（正例・違反例）。
# Node control plane実装非依存で成立する（本パッケージには対応するNode実装がまだ存在しない）。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
SCHEMA="${PKG_ROOT}/database/detection-system-schema.sql"
WORKDIR="$(mktemp -d)"
DB="${WORKDIR}/detection-findings-resolved-fields.test.db"

cleanup() { rm -rf "${WORKDIR}"; }
trap cleanup EXIT

echo "[1/5] load schema"
sqlite3 "${DB}" < "${SCHEMA}"

echo "[2/5] non-resolved status keeps resolved_by/residual_risk NULL"
sqlite3 "${DB}" <<'SQL'
INSERT INTO source_snapshots (source_snapshot_id, source_kind, locator, ref_name, content_digest, observed_at)
VALUES ('snap-1', 'git_ref', 'origin/main', 'main', 'digest-1', '2026-07-17T00:00:00Z');

INSERT INTO detection_findings
  (finding_id, finding_type, severity, status, source_snapshot_id, detector_id, detector_version,
   detector_policy_digest, evidence_digest, route, created_at, updated_at)
VALUES
  ('finding-candidate', 'lint', 'warning', 'candidate', 'snap-1', 'detector-a', '1.0.0',
   'policy-digest-1', 'evidence-digest-1', 'route-a', '2026-07-17T00:00:00Z', '2026-07-17T00:00:00Z');
SQL

NULL_CHECK=$(sqlite3 "${DB}" "SELECT resolved_by IS NULL AND residual_risk IS NULL FROM detection_findings WHERE finding_id='finding-candidate';")
if [ "${NULL_CHECK}" != "1" ]; then
  echo "FAIL: non-resolved finding must keep resolved_by/residual_risk NULL" >&2
  exit 1
fi
echo "OK: non-resolved finding rows keep resolved_by/residual_risk NULL"

echo "[3/5] resolved status carries resolved_by/residual_risk values"
sqlite3 "${DB}" <<'SQL'
INSERT INTO detection_findings
  (finding_id, finding_type, severity, status, source_snapshot_id, detector_id, detector_version,
   detector_policy_digest, evidence_digest, route, created_at, updated_at, resolved_by, residual_risk)
VALUES
  ('finding-resolved', 'lint', 'warning', 'resolved', 'snap-1', 'detector-a', '1.0.0',
   'policy-digest-1', 'evidence-digest-2', 'route-a', '2026-07-17T00:00:00Z', '2026-07-17T01:00:00Z',
   'reviewer-x', 'residual-risk-note');
SQL

RESOLVED_CHECK=$(sqlite3 "${DB}" "SELECT resolved_by || '|' || residual_risk FROM detection_findings WHERE finding_id='finding-resolved';")
if [ "${RESOLVED_CHECK}" != "reviewer-x|residual-risk-note" ]; then
  echo "FAIL: resolved finding must persist resolved_by/residual_risk values, got: ${RESOLVED_CHECK}" >&2
  exit 1
fi
echo "OK: resolved finding rows persist resolved_by/residual_risk values (${RESOLVED_CHECK})"

echo "[4/5] candidate status with resolved_by/residual_risk set is rejected by DB CHECK"
if sqlite3 "${DB}" <<'SQL' 2>${WORKDIR}/detdb02-neg1.err
INSERT INTO detection_findings
  (finding_id, finding_type, severity, status, source_snapshot_id, detector_id, detector_version,
   detector_policy_digest, evidence_digest, route, created_at, updated_at, resolved_by, residual_risk)
VALUES
  ('finding-candidate-violation', 'lint', 'warning', 'candidate', 'snap-1', 'detector-a', '1.0.0',
   'policy-digest-1', 'evidence-digest-3', 'route-a', '2026-07-17T00:00:00Z', '2026-07-17T00:00:00Z',
   'reviewer-x', 'residual-risk-note');
SQL
then
  echo "FAIL: candidate status with non-NULL resolved_by/residual_risk must be rejected by CHECK" >&2
  exit 1
fi
grep -qi "CHECK constraint failed" ${WORKDIR}/detdb02-neg1.err
echo "OK: candidate + non-NULL resolved_by/residual_risk rejected by DB CHECK"

echo "[5/5] resolved status with resolved_by NULL is rejected by DB CHECK"
if sqlite3 "${DB}" <<'SQL' 2>${WORKDIR}/detdb02-neg2.err
INSERT INTO detection_findings
  (finding_id, finding_type, severity, status, source_snapshot_id, detector_id, detector_version,
   detector_policy_digest, evidence_digest, route, created_at, updated_at)
VALUES
  ('finding-resolved-violation', 'lint', 'warning', 'resolved', 'snap-1', 'detector-a', '1.0.0',
   'policy-digest-1', 'evidence-digest-4', 'route-a', '2026-07-17T00:00:00Z', '2026-07-17T01:00:00Z');
SQL
then
  echo "FAIL: resolved status with NULL resolved_by must be rejected by CHECK" >&2
  exit 1
fi
grep -qi "CHECK constraint failed" ${WORKDIR}/detdb02-neg2.err
echo "OK: resolved + NULL resolved_by rejected by DB CHECK"
rm -f ${WORKDIR}/detdb02-neg1.err ${WORKDIR}/detdb02-neg2.err

echo "PASS: validation/detection-findings-resolved-fields.sh"
