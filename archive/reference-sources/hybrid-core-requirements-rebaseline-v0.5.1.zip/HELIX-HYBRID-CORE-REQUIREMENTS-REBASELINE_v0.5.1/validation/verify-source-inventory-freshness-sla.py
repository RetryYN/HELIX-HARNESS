#!/usr/bin/env python3
"""是正 GH-03 (HBR-INV-014 / AC-INV-08) の機械検証（package内で完結する部分）。

1. schemas/source-inventory.schema.json の改訂版（next_reaudit_due・
   commits_behind_upstream を required + properties 両方に追加済み）に対し、
   validation/fixtures/source-inventory-fresh.json が jsonschema で正しく
   validate されることを確認する（required 追加だけで properties 未定義になる
   unsatisfiable schema ではないことの直接証明）。
2. 将来 `helix doctor source-ref-freshness-sla` gate が実装するSLAロジック
   （30日 または 10 commit 先行のいずれか早い方を超過していれば fail-close）を
   このスクリプト内で再現し、
   - fresh fixture (commits_behind_upstream=0, observed_at=today) は PASS
   - stale fixture (commits_behind_upstream=81, observed_at 30日超過) は FAIL
   することを確認する。

exit 0: 両フィクスチャがschema validationを通過し、かつSLA判定が期待どおり
        (fresh=pass, stale=fail) である。
exit 1: 上記いずれかに反する（unsatisfiable schemaまたはSLA判定ロジック不整合）。
"""
import json
import sys
from datetime import date, timedelta
from pathlib import Path

try:
    import jsonschema
except ImportError:
    print("FAIL: jsonschema not available", file=sys.stderr)
    sys.exit(1)

HERE = Path(__file__).resolve().parent
PKG_ROOT = HERE.parent
SCHEMA_PATH = PKG_ROOT / "schemas" / "source-inventory.schema.json"
FRESH_PATH = HERE / "fixtures" / "source-inventory-fresh.json"
STALE_PATH = HERE / "fixtures" / "source-inventory-stale.json"

SLA_DAYS = 30
SLA_COMMITS = 10

errors = []


def sla_violated(observed_at: str, commits_behind_upstream: int, today: date) -> bool:
    observed = date.fromisoformat(observed_at)
    age_days = (today - observed).days
    return age_days > SLA_DAYS or commits_behind_upstream > SLA_COMMITS


def main() -> int:
    if not SCHEMA_PATH.exists():
        print(f"FAIL: {SCHEMA_PATH} not found", file=sys.stderr)
        return 1
    if not FRESH_PATH.exists() or not STALE_PATH.exists():
        print("FAIL: fixture files not found", file=sys.stderr)
        return 1

    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))

    for name in ("next_reaudit_due", "commits_behind_upstream"):
        if name not in schema.get("required", []):
            errors.append(f"schema required[] missing '{name}'")
        if name not in schema.get("properties", {}):
            errors.append(f"schema properties missing type definition for '{name}'")

    fresh = json.loads(FRESH_PATH.read_text(encoding="utf-8"))
    stale = json.loads(STALE_PATH.read_text(encoding="utf-8"))

    try:
        jsonschema.validate(instance=fresh, schema=schema)
    except jsonschema.exceptions.ValidationError as exc:
        errors.append(f"fresh fixture failed schema validation (schema may be unsatisfiable): {exc.message}")

    try:
        jsonschema.validate(instance=stale, schema=schema)
    except jsonschema.exceptions.ValidationError as exc:
        errors.append(f"stale fixture failed schema validation (schema may be unsatisfiable): {exc.message}")

    today = date.fromisoformat(fresh["observed_at"])
    fresh_violation = sla_violated(fresh["observed_at"], fresh["commits_behind_upstream"], today)
    if fresh_violation:
        errors.append("fresh fixture unexpectedly violates freshness SLA")

    stale_violation = sla_violated(stale["observed_at"], stale["commits_behind_upstream"], today)
    if not stale_violation:
        errors.append("stale fixture unexpectedly passes freshness SLA (gate would not fail-close)")

    if errors:
        print("FAIL: verify-source-inventory-freshness-sla")
        for e in errors:
            print(f"  - {e}")
        return 1

    print(
        "PASS: verify-source-inventory-freshness-sla "
        f"(schema satisfiable; fresh=pass @{fresh['observed_at']}, "
        f"stale=fail @{stale['observed_at']} commits_behind={stale['commits_behind_upstream']})"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
