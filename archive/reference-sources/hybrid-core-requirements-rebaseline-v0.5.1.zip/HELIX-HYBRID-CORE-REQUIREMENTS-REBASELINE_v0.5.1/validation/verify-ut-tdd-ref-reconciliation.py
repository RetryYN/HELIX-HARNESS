#!/usr/bin/env python3
"""是正 UT-01/UT-02 の機械検証（package内で完結する部分）。

exit 0: 全refに reconciled_against があり、authority_status が enum に適合し、
        未説明のsha不一致 (reconciliation_note欠如) が無い。
exit 1: 上記いずれかの違反を検出（disposition closureを許可しない）。

将来リポジトリ側の `helix doctor source-authority-consistency` は、本スクリプトの
package内チェックに加えて docs/governance/infinity-loop-source-capability-ledger.md
§1.2 の `predecessor-ut` status との一致確認を行う想定（validation/TODO-authority-corrections-lint.md
参照）。本スクリプトはpackage可搬性のため、そのledgerファイルが同一リポジトリ内に
見つかった場合のみ追加でクロスチェックする（見つからない場合はbest-effort skipとし、
package内チェックの合否には影響させない）。
"""
import json
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("FAIL: pyyaml not available", file=sys.stderr)
    sys.exit(1)

HERE = Path(__file__).resolve().parent
PKG_ROOT = HERE.parent
AUDIT_PATH = PKG_ROOT / "inventory" / "ut-tdd-ref-audit.yaml"
SCHEMA_PATH = PKG_ROOT / "schemas" / "source-ref-audit.schema.json"

errors = []


def main() -> int:
    if not AUDIT_PATH.exists():
        print(f"FAIL: {AUDIT_PATH} not found", file=sys.stderr)
        return 1
    if not SCHEMA_PATH.exists():
        print(f"FAIL: {SCHEMA_PATH} not found", file=sys.stderr)
        return 1

    raw_text = AUDIT_PATH.read_text(encoding="utf-8")
    doc = yaml.safe_load(raw_text)
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))

    allowed_authority_status = schema["properties"]["authority_status"]["enum"]

    authority_status = doc.get("authority_status")
    if authority_status not in allowed_authority_status:
        errors.append(
            f"authority_status={authority_status!r} not in {allowed_authority_status!r}"
        )

    refs = doc.get("refs", [])
    if not refs:
        errors.append("refs list is empty")

    # grep-equivalent count check: every ref entry must literally contain
    # `reconciled_against:` (the finding's stated verification method).
    reconciled_against_count = raw_text.count("reconciled_against:")
    if reconciled_against_count != len(refs):
        errors.append(
            "reconciled_against count "
            f"({reconciled_against_count}) does not match ref count ({len(refs)})"
        )

    for i, ref in enumerate(refs):
        ref_name = ref.get("ref", f"<index {i}>")
        if "reconciled_against" not in ref:
            errors.append(f"ref '{ref_name}': missing reconciled_against")
            continue
        # A sha mismatch is "unreconciled" only if there is no explanatory
        # reconciliation_note. Every ref in this audit currently carries one;
        # absence must force status=sha_mismatch_unreconciled.
        has_note = bool(ref.get("reconciliation_note", "").strip())
        status = ref.get("status")
        if not has_note and status != "sha_mismatch_unreconciled":
            errors.append(
                f"ref '{ref_name}': no reconciliation_note but status is "
                f"'{status}' (expected 'sha_mismatch_unreconciled')"
            )
        if has_note and status == "sha_mismatch_unreconciled":
            errors.append(
                f"ref '{ref_name}': has reconciliation_note but status is still "
                "'sha_mismatch_unreconciled' (explained mismatches must not use "
                "this status)"
            )

    # Best-effort cross-check against the canonical ledger, if reachable from
    # a repo checkout. Not required for package-internal pass/fail.
    for candidate in [
        PKG_ROOT.parent.parent / "docs" / "governance" / "infinity-loop-source-capability-ledger.md",
        Path("/home/tenni/HELIX-HARNESS/docs/governance/infinity-loop-source-capability-ledger.md"),
    ]:
        if candidate.exists():
            ledger_text = candidate.read_text(encoding="utf-8")
            if "| `predecessor-ut` |" in ledger_text:
                row = [
                    line
                    for line in ledger_text.splitlines()
                    if line.strip().startswith("| `predecessor-ut` |")
                ]
                if row:
                    cells = [c.strip() for c in row[0].strip("|").split("|")]
                    ledger_status = cells[-1].strip("` ") if cells else None
                    if ledger_status and ledger_status != authority_status:
                        errors.append(
                            "cross-check: ledger §1.2 predecessor-ut status="
                            f"{ledger_status!r} != authority_status={authority_status!r}"
                        )
            break

    if errors:
        print("FAIL: verify-ut-tdd-ref-reconciliation")
        for e in errors:
            print(f"  - {e}")
        return 1

    print(
        f"PASS: verify-ut-tdd-ref-reconciliation "
        f"({len(refs)} refs, authority_status={authority_status})"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
