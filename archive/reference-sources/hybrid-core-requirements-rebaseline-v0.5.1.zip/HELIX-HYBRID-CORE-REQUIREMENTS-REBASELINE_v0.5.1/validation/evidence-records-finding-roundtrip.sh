#!/usr/bin/env bash
# validation/evidence-records-finding-roundtrip.sh
#
# 是正F2の機械検証。sqlite3 CLIでdatabase/detection-system-schema.sqlを直接ロードし、
# evidence_records <-> detection_findings の subject_kind/subject_id 結合と、
# trg_evidence_records_detection_finding_fk / _update トリガーによるDB層参照整合性を検証する。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
SCHEMA="${PKG_ROOT}/database/detection-system-schema.sql"
WORKDIR="$(mktemp -d)"
DB="${WORKDIR}/evidence-records-finding-roundtrip.test.db"

cleanup() { rm -rf "${WORKDIR}"; }
trap cleanup EXIT

echo "[1/3] load schema (includes trg_evidence_records_detection_finding_fk / _update)"
sqlite3 "${DB}" < "${SCHEMA}"

echo "[2/3] finding + N(>=2) evidence_records rows round-trip via subject_kind/subject_id JOIN"
sqlite3 "${DB}" <<'SQL'
INSERT INTO source_snapshots (source_snapshot_id, source_kind, locator, ref_name, content_digest, observed_at)
VALUES ('snap-1', 'git_ref', 'origin/main', 'main', 'digest-1', '2026-07-17T00:00:00Z');

INSERT INTO detection_findings
  (finding_id, finding_type, severity, status, source_snapshot_id, detector_id, detector_version,
   detector_policy_digest, evidence_digest, route, created_at, updated_at)
VALUES
  ('finding-evidence-1', 'lint', 'warning', 'confirmed', 'snap-1', 'detector-a', '1.0.0',
   'policy-digest-1',
   -- synthetic composite digest standing in for the normalized SHA-256 join of the evidence set below.
   'composite-sha256-of-ev1-ev2-ev3',
   'route-a', '2026-07-17T00:00:00Z', '2026-07-17T00:00:00Z');

INSERT INTO evidence_records
  (evidence_id, subject_kind, subject_id, producer_id, evidence_kind, artifact_digest, trusted, recorded_at)
VALUES
  ('ev-1', 'detection_finding', 'finding-evidence-1', 'detector-a', 'log', 'digest-ev-1', 1, '2026-07-17T00:00:01Z'),
  ('ev-2', 'detection_finding', 'finding-evidence-1', 'detector-a', 'log', 'digest-ev-2', 1, '2026-07-17T00:00:02Z'),
  ('ev-3', 'detection_finding', 'finding-evidence-1', 'detector-a', 'log', 'digest-ev-3', 1, '2026-07-17T00:00:03Z');
SQL

JOIN_COUNT=$(sqlite3 "${DB}" "
SELECT COUNT(*)
FROM evidence_records er
JOIN detection_findings f
  ON er.subject_kind = 'detection_finding' AND er.subject_id = f.finding_id
WHERE f.finding_id = 'finding-evidence-1';
")
if [ "${JOIN_COUNT}" != "3" ]; then
  echo "FAIL: expected 3 evidence_records rows to round-trip via subject_kind/subject_id JOIN, got ${JOIN_COUNT}" >&2
  exit 1
fi
echo "OK: ${JOIN_COUNT} evidence_records rows round-trip via subject_kind/subject_id JOIN"

echo "[3/3] trigger rejects evidence_records row pointing at a nonexistent finding_id"
set +e
sqlite3 "${DB}" "
INSERT INTO evidence_records
  (evidence_id, subject_kind, subject_id, producer_id, evidence_kind, artifact_digest, trusted, recorded_at)
VALUES
  ('ev-orphan', 'detection_finding', 'finding-does-not-exist', 'detector-a', 'log', 'digest-ev-orphan', 1, '2026-07-17T00:00:04Z');
" 2>"${WORKDIR}/insert-orphan.err"
INSERT_EXIT=$?
set -e

if [ "${INSERT_EXIT}" -eq 0 ]; then
  echo "FAIL: trg_evidence_records_detection_finding_fk did not reject orphan subject_id" >&2
  exit 1
fi
echo "OK: trg_evidence_records_detection_finding_fk rejected orphan subject_id (exit ${INSERT_EXIT}: $(cat "${WORKDIR}/insert-orphan.err"))"

echo "PASS: validation/evidence-records-finding-roundtrip.sh"
