#!/usr/bin/env python3
"""validation/capability-map-bijection.py

是正F3/F4の機械検証。

F3単独受入 (partial): fix_names, id_utils, selftest, style, util の5要素それぞれが
python_tools に含まれ、かつ capability_families 配下のちょうど1箇所にのみ出現すること。

F3+F4結合後にのみ成立する全体ゲート (full bijection): python_tools 集合と
capability_families 配下の全要素集合が双方向で一致すること
（capability_families 配下に python_tools に無い要素が残っていないか、
python_tools の全要素が capability_families のどこかに属しているか）。

Usage:
  python3 validation/capability-map-bijection.py           # runs both checks, exits non-zero if either fails
  python3 validation/capability-map-bijection.py --partial # F3-only partial check
  python3 validation/capability-map-bijection.py --full    # F3+F4 full bijection check
"""
import sys
import pathlib

import yaml

PKG_ROOT = pathlib.Path(__file__).resolve().parent.parent
MAP_PATH = PKG_ROOT / "inventory" / "hybrid-core-capability-map.yaml"

F3_ADDED_ELEMENTS = ["fix_names", "id_utils", "selftest", "style", "util"]


def load_map():
    with open(MAP_PATH, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def check_partial(data):
    python_tools = set(data["python_tools"])
    families = data["capability_families"]
    ok = True
    for elem in F3_ADDED_ELEMENTS:
        if elem not in python_tools:
            print(f"FAIL(partial): {elem} not present in python_tools", file=sys.stderr)
            ok = False
            continue
        occurrences = sum(1 for family in families.values() if elem in family)
        if occurrences != 1:
            print(
                f"FAIL(partial): {elem} occurs {occurrences} times in capability_families "
                "(expected exactly 1)",
                file=sys.stderr,
            )
            ok = False
    if ok:
        print("PASS(partial): F3 added elements each occur exactly once in capability_families")
    return ok


def check_full(data):
    python_tools = set(data["python_tools"])
    families = data["capability_families"]
    family_elements = set()
    for family in families.values():
        family_elements.update(family)

    extra_in_families = family_elements - python_tools
    missing_from_families = python_tools - family_elements

    ok = True
    if extra_in_families:
        print(
            f"FAIL(full): capability_families has elements not in python_tools: {sorted(extra_in_families)}",
            file=sys.stderr,
        )
        ok = False
    if missing_from_families:
        print(
            f"FAIL(full): python_tools has elements missing from capability_families: {sorted(missing_from_families)}",
            file=sys.stderr,
        )
        ok = False
    if ok:
        print("PASS(full): python_tools <-> capability_families is a full bijection (29/29, no extras)")
    return ok


def main():
    args = sys.argv[1:]
    data = load_map()

    run_partial = "--full" not in args
    run_full = "--partial" not in args

    ok = True
    if run_partial:
        ok = check_partial(data) and ok
    if run_full:
        ok = check_full(data) and ok

    if not ok:
        sys.exit(1)


if __name__ == "__main__":
    main()
