#!/usr/bin/env python3
"""UT-04 full-ref enumeration snapshotをfail-closeで検証する。"""
import json
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("FAIL: pyyaml not available", file=sys.stderr)
    sys.exit(1)

HERE = Path(__file__).resolve().parent
PKG_ROOT = HERE.parent
AUDIT_PATH = PKG_ROOT / "inventory" / "ut-tdd-ref-audit.yaml"
ENUM_LOG_PATH = PKG_ROOT / "inventory" / "ut-tdd-ref-enumeration.json"

errors = []


def main() -> int:
    if not AUDIT_PATH.exists():
        print(f"FAIL: {AUDIT_PATH} not found", file=sys.stderr)
        return 1

    doc = yaml.safe_load(AUDIT_PATH.read_text(encoding="utf-8"))
    coverage = doc.get("coverage_boundary", {})
    is_closed = coverage.get("is_disposition_closed")
    if not ENUM_LOG_PATH.exists():
        errors.append(f"{ENUM_LOG_PATH.name} is required; absence must fail closed")
    else:
        snapshot = json.loads(ENUM_LOG_PATH.read_text(encoding="utf-8"))
        if snapshot.get("repository") != doc.get("repository"):
            errors.append("enumeration repository does not match audit repository")
        audit_rows = {row.get("ref"): row for row in doc.get("refs", [])}
        branch_rows = {row.get("ref"): row for row in snapshot.get("branches", [])}
        missing_branches = sorted(set(branch_rows) - set(audit_rows))
        if missing_branches:
            errors.append(f"live branches missing from audit refs: {missing_branches}")
        sha_mismatches = sorted(
            ref
            for ref, branch in branch_rows.items()
            if audit_rows.get(ref, {}).get("sha") != branch.get("sha")
        )
        if sha_mismatches:
            errors.append(f"live branch SHA mismatch: {sha_mismatches}")
        open_pulls = [row for row in snapshot.get("pulls", []) if row.get("state") == "open"]
        missing_open_heads = sorted(
            row.get("head_ref") for row in open_pulls if row.get("head_ref") not in audit_rows
        )
        if missing_open_heads:
            errors.append(f"open PR heads missing from audit refs: {missing_open_heads}")
        if not snapshot.get("pulls"):
            errors.append("open/closed PR enumeration is empty")
        if is_closed is True and doc.get("authority_status") != "cleared":
            errors.append("disposition closure requires authority_status=cleared")

    if errors:
        print("FAIL: verify-full-ref-adoption-status")
        for e in errors:
            print(f"  - {e}")
        return 1

    print(
        "PASS: verify-full-ref-adoption-status "
        f"(branches={len(branch_rows)} pulls={len(snapshot.get('pulls', []))} "
        f"disposition_closed={is_closed})"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
