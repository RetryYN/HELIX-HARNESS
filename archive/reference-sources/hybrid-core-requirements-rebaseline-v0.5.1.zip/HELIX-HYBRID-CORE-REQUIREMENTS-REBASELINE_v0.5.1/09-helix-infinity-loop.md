# 9. HELIX Infinity Loop

## 権威順序（INF-01是正）

本packageのInfinity Loop記述（本書、`schemas/infinity-loop-cycle.schema.json`、
`schemas/self-audit-report.schema.json`、`schemas/learning-recipe.schema.json`、
`templates/infinity-loop-cycle.template.yaml`を含む）は、repo正本
`docs/design/helix/L4-basic-design/infinity-loop-platform-basic-design.md`のL4 component
（`InfinityCoordinator`、`agent_verification_receipts`、`LearningPromotionLedger`等）に従属し、
対立時はL4正本が優先する。本packageはL4正本の下位実装形（schema/template/prose）であり、
独立した並行正本ではない。

Infinity Loopは無限自動修正ではありません。停止条件・権限・独立監査を持つbounded recurrent systemです。

```text
Observe → Detect → Classify → Route → Plan → Implement → Verify → Audit → Learn
      ↑                                                                     ↓
      └── Observe ←──────────── Disposition{Promote / Reject / Rollback} ──┘
                                          │
                                          └─ Escalate → Human Decision → Observe
```

上図の遷移順は`diagrams/infinity-loop.mmd`をcanonicalとして整合させたものである
（Learn実行後にDispositionとしてPromote/Reject/Rollback/Escalateが決定され、Escalateのみ
Human Decisionを経由してObserveへ戻る）。rollbackはLearn実行後にDispositionとして決定され、
AC-INF-06のrollback証跡（`snapshot_id`/`rollback_command`/`verification_oracle`/`monitor_window`、
INF-05是正で`schemas/infinity-loop-cycle.schema.json`の`history[]`へ追加）を伴いObserveへ戻る。

- worker ≠ verifier ≠ high-impact approver
- semantic/irreversible changeは自動適用しない
- 進行中止トリガー（`terminal_policy.stop_conditions`）: no_progress、repeat、budget_exhausted。
  no_progressの算出はNode既存`evaluateStop`/`probe.noProgress(threshold)`
  （`src/orchestration/loop-stop-rules.ts`）に従属し、本packageは`no_progress_threshold`相当の
  config値のみを提供する。terminal結果（cycleの最終状態）はverified/rejected/cycle_limit_exhaustedで
  区別する。両者の対応関係は`schemas/infinity-loop-cycle.schema.json`の
  `terminal_policy.stop_conditions` enumで機械強制する（INF-07/INF-09是正）。
- 成功修復はrecipe候補、複数evidence後にruleへ昇格
- 再発findingはAC/test/detectorへ昇格
- L14運用結果をL0価値へ返す
