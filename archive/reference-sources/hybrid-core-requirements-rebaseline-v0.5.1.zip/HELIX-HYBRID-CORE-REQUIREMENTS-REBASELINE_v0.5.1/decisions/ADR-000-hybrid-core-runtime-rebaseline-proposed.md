# ADR-000 — Existing Hybrid Python Core Partial-Modification Rebaseline

- Status: proposed
- Supersedes-Check: ADR-009-node-python-linux-runtime (accepted) — 本ADRはADR-009を上書き・逸脱しない。抵触する場合はADR-009が優先する。
  ADR-010-python-semantic-core-node-commit-boundary (accepted) — ADR-009のうちADR-010が上書きした条項
  （proposal-only呼称、reject-for-TS-reimplementation既定、権威関係の非対称記述）については、抵触する場合ADR-010が優先する。
- 適用範囲: 本ADRの適用範囲はADR-009の許容範囲内に限定される。
- Decision:
  - `hybrid-docgen/tools/*.py`のうち、ADR-009の許可capability class（`source_atomization`/`document_engine`/`detector`/`product_data`/`analysis`）に属するbehavior atomを、versioned contract配下のPython意味コア（semantic core、ADR-010）として個別に採用する。分類できない新規機能（制御面・writer・orchestration相当を除く意味判断機能）はADR改定によるclass追加で扱い、reject-for-TS-reimplementationを既定にしない（ADR-010決定1）。TS/Node再実装は既定ではなくPO個別承認による例外とし、動作しているPython意味コアのbulk TS再実装は高リスク行為として原則禁止する。採用単位は個別behavior atomとする。
  - file/function単位に`reuse_as_is / patch / wrap / split / replace / reject`を記録する
  - original archive/file digestとgolden behaviorをrollback/parity基準とする
  - 旧path/CLIをcompatibility facadeとして保持する
  - Pythonはgenerated/staging outputを生成し、Nodeがcanonical promotionと外部副作用を所有する。Nodeがschema・lineage・digest・lease/fence・policyを再検証し、唯一のtransaction writerとしてcommitする。Pythonはnetwork default denyとし、DB path・credential・repository・`.helix/`を受け取らない。
  - TypeScript/NodeをBun-free runtime/adapter層とする
  - Linuxをprimary platformとする
  - Workflow Requirements Engine v1.1をadapterで接続する
  - Detection DB、HARNESS Capsule、Infinity Loopをfirst-class contractにする
- Supersedes:
  - TS/Bun-only core assumptions
  - HELIX workflow-spine v0.2 proposal
  - v0.3.0のmandatory `packages/python-core` relocation interpretation
- Consequences:
  - migration量とbehavior riskを抑えられる
  - compatibility facadeとgolden suiteを一定期間維持する必要がある
  - physical path migrationは別cutoverになる
  - dual-language contract disciplineは引き続き必要

本ADRはPO承認までproposedであり、承認前に02章以降で確定事実として記述してはならない。
