# Decision Ledger

| ID | Decision | Status |
|---|---|---|
| D-001 | Existing Hybrid Python source is the semantic/design core | proposed |
| D-002 | Python core is reused through partial modification; no greenfield wholesale rewrite | proposed |
| D-003 | Original archive/file digest and golden behavior are rollback/parity baselines | proposed |
| D-004 | File/function decisions use reuse_as_is/patch/wrap/split/replace/reject | proposed |
| D-005 | Existing Python path/CLI remains a compatibility facade during migration. 関連Open decision: 14-risks-and-open-decisions.md #Open decisions（Python source pathを恒久保持するか、parity後に段階移設するか） | proposed |
| D-006 | Python may write generated staging output; Node owns canonical/external side effects | proposed |
| D-007 | TypeScript/Node owns Bun-free runtime integration. 関連Open decision: 14-risks-and-open-decisions.md #Open decisions（old Bun CLIの互換期間） | proposed |
| D-008 | Linux is primary; macOS/Windows are support tiers | proposed |
| D-009 | Workflow Engine v1.1 judgment coreはbyte-pin vendor資産とし、adapter実行はNode CLIサブコマンド（`helix requirements interview --read-only` / `helix requirements compile --l3-draft` / `helix workflow validate\|derive\|graph`）としてのみ実装し、Python側には実行権限を与えない（ADR-009: Node=唯一transaction writer、Pythonは`source_atomization`/`document_engine`/`detector`/`product_data`/`analysis`のclosed capability classに限るproposal-only worker）。PO承認待ち（confirmed化は本ledgerの次回改訂で別途行う）。（呼称は ADR-010/D-016 により『意味コア』へ改定。本行の proposal-only 表現は歴史的記録） | proposed |
| D-010 | Subagents require HARNESS Capsules | proposed |
| D-011 | Infinity Loop requires independent audit and human boundaries | proposed |
| D-012 | Detection DB is event ledger/projection, not authored requirement SSoT | proposed |
| D-013 | UT-TDD PR64 is split/adopt with hardening | proposed |
| D-014 | Closed PR54 code adoption is rejected; audit history remains | observed |
| D-015 | v0.5.0是正F1（chat-reqs軸, AC-TRACE-02）: CHAT-001〜CHAT-020の生チャットログ本文はv0.4.0起票時点で本パッケージに保存されておらず「再構成不能」（`inventory/chat-requirements-provenance.yaml` の `source.type: reconstructed_unavailable`）とし、代替検証は `downstream_requirement_crosscheck`（各CHAT-IDの `requirements/traceability.yaml` `refined_into` edgeが指すHBR/HNFR要件群のstatementと要約文が矛盾しないことの目視+grep突合、`requirements/requirements-catalog.yaml`と照合）で充足したものと扱う。以後の新規チャット要求蒸留（CHAT-021以降）はelicitation-sessionの`inputs`へ生ログ参照/digestを同時記録し、事後追補を発生させない。 | proposed |
| D-016 | ランタイム権威は層別同格とする（ADR-010: Python=意味コア恒久正本・TS再実装義務廃止・proposal-only呼称廃止、Node=harness.db/Git単一commit境界のみ維持）。PO委任裁定 2026-07-17（チャット指示「技術的にどちらが優位かで決めろ」）に基づく確定。確定根拠: `docs/governance/hybrid-rebaseline-v0.4.0-fullcheck-audit-2026-07-17.md`「権威衝突の最終裁定」節、監査workflow `wf_11095bcf-712`/`wf_452d88b3-fd2`、harness memory key `harness:adr-010-runtime-authority-ruling`（origin=helix-memory-cli、2026-07-17、type=decision）。 | confirmed |
