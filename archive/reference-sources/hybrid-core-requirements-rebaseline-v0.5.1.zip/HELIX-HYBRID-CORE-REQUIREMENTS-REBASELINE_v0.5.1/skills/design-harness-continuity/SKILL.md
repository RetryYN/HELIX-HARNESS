---
schema_version: skill.v1
name: design-harness-continuity
skill_type: design-contract
applies_to:
  layers: [L1, L2, L3, L4, L5, L6, L7, L8, L9, L10]
  drive_models: [Forward, Add-feature, Discovery, Reverse, Refactor, Retrofit]
---

# Design HARNESS Continuity

UI、screen transition、responsive、motion、a11y、frontend binding、visual evidenceが対象なら読む。
新しいdesign engineを作らず、L2からL10までsemantic IDを維持する。

- L2: meaning structure only。framework/class/APIを固定しない。
- L4: Pattern/Profile/Token。
- L5: Region/Slotとdata/state/event/permissionをbind。
- L6: UI-M0〜M7、test oracle、WBS。
- L7: prototypeをproduction evidenceにしない。receiptが無ければimplemented不可。
- L10: real rendering、real data、responsive、motion、a11y、human review。
