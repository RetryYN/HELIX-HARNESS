# Anti-patterns
- routeや画面数だけでimplementedとする
- 全画面を同じgeneric tableで埋める
- L2でReact component/API/propsを固定する
- operational screenへcontinuous decorationを入れる
- screenshotだけでG10を閉じる
- DB projectionをauthoring sourceにする
