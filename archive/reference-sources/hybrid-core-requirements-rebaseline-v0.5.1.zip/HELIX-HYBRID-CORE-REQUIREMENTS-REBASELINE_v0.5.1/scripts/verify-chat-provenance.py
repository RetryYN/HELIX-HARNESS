#!/usr/bin/env python3
"""v0.5.0是正 F1 (AC-TRACE-02) detector: chat要求蒸留の上流provenance欠落検出。

ADR-009 closed capability class = detector（欠落・不整合検出）。本スクリプトは
Python意味コア（semantic core、ADR-010: 意味判断の正本）の一部であり、ADR-009/ADR-010の
Node=唯一のtransaction writer原則（実行境界としてのcommit直列化）に従う。以下を満たす:

  (a) 引数は chat-requirements.yaml と chat-requirements-provenance.yaml の
      2パスのみ。DB path・credential・`.helix/`は一切受け取らない。標準ライブラリ
      （argparse/json/sys/pathlib/hashlib/datetime）のみをimportし、network access
      を一切行わない（network default deny）。
  (b) 判定結果は stdout へ構造化JSONの **proposal** として出すのみであり、この
      スクリプトのexit codeやokフィールド単体をCI/`helix doctor`相当gateの合否
      根拠として直接信用してはならない。
  (c) 将来のNode側control-plane再検証モジュールが、両入力YAMLを自ら読み直して
      digest/件数を再計算し、本スクリプトのproposal要約値と突合したうえで、出力
      JSONのschema検証を行って初めてgate合否を確定する（schema不一致・digest
      不一致・本スクリプト異常終了はすべてfail-close）。
  (d) AC-TRACE-02のverificationは「本スクリプトの exit 0」単独ではなく、
      「本スクリプトのproposal + Node側再検証(schema/digest突合)」の二段構成
      である。本スクリプト単体の green は AC-TRACE-02 充足の必要条件だが
      十分条件ではない。

使い方:
    python3 scripts/verify-chat-provenance.py \
        --chat-requirements inventory/chat-requirements.yaml \
        --provenance inventory/chat-requirements-provenance.yaml \
        --json

exit 0: chat-requirements.yaml の全CHAT-IDについて、provenance台帳に1:1の
        レコード（chat_id, source{type, ref|unavailable_reason}, assigned_by,
        assigned_at, verification_method 必須フィールドすべて充足）が存在する。
exit 1: orphan CHAT-ID（provenanceレコードなし）または必須フィールド欠落がある。
exit 2: 入力ファイルが読めない/parseできない（PyYAML不在含む）。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    print(
        json.dumps(
            {
                "schema_version": "helix-chat-provenance-check.v1",
                "ok": False,
                "error": "PyYAML is required to run this Python semantic core detector",
            }
        )
    )
    sys.exit(2)

REQUIRED_RECORD_FIELDS = ("chat_id", "source", "assigned_by", "assigned_at", "verification_method")
REQUIRED_SOURCE_TYPES = ("raw_log_excerpt", "reconstructed_unavailable")


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _load_yaml(path: Path):
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def check(chat_requirements_path: Path, provenance_path: Path) -> dict:
    missing_fields: list[str] = []

    chat_doc = _load_yaml(chat_requirements_path)
    prov_doc = _load_yaml(provenance_path)

    chat_ids = [str(r["id"]) for r in (chat_doc.get("requirements") or []) if r.get("id")]
    records = prov_doc.get("records") or []

    records_by_id: dict[str, dict] = {}
    for rec in records:
        cid = rec.get("chat_id")
        if not cid:
            missing_fields.append("record missing chat_id field")
            continue
        records_by_id[str(cid)] = rec

    orphan_chat_ids = [cid for cid in chat_ids if cid not in records_by_id]

    for cid, rec in records_by_id.items():
        for field in REQUIRED_RECORD_FIELDS:
            if field not in rec or rec[field] in (None, ""):
                missing_fields.append(f"{cid}: missing required field '{field}'")
        source = rec.get("source") or {}
        source_type = source.get("type")
        if source_type not in REQUIRED_SOURCE_TYPES:
            missing_fields.append(f"{cid}: source.type must be one of {REQUIRED_SOURCE_TYPES}, got {source_type!r}")
        elif source_type == "raw_log_excerpt" and not source.get("ref"):
            missing_fields.append(f"{cid}: source.type=raw_log_excerpt requires source.ref")
        elif source_type == "reconstructed_unavailable" and not source.get("unavailable_reason"):
            missing_fields.append(f"{cid}: source.type=reconstructed_unavailable requires source.unavailable_reason")

    ok = not orphan_chat_ids and not missing_fields

    return {
        "schema_version": "helix-chat-provenance-check.v1",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "semantic_core_output": True,
        "authority_note": (
            "ADR-010 Python semantic core detector output. Exit code / ok field alone MUST NOT be "
            "trusted as gate verdict; a Node execution-boundary re-verification (digest + schema "
            "cross-check) is required before AC-TRACE-02 can be marked satisfied."
        ),
        "inputs": {
            "chat_requirements_path": str(chat_requirements_path),
            "chat_requirements_digest": f"sha256:{_digest(chat_requirements_path)}",
            "provenance_path": str(provenance_path),
            "provenance_digest": f"sha256:{_digest(provenance_path)}",
        },
        "chat_ids_total": len(chat_ids),
        "provenance_records_total": len(records),
        "orphan_chat_ids": orphan_chat_ids,
        "missing_fields": missing_fields,
        "ok": ok,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--chat-requirements", required=True, type=Path)
    parser.add_argument("--provenance", required=True, type=Path)
    parser.add_argument("--json", action="store_true", help="emit structured JSON proposal to stdout")
    args = parser.parse_args()

    try:
        result = check(args.chat_requirements, args.provenance)
    except FileNotFoundError as exc:
        print(json.dumps({"schema_version": "helix-chat-provenance-check.v1", "ok": False, "error": str(exc)}))
        return 2
    except yaml.YAMLError as exc:
        print(json.dumps({"schema_version": "helix-chat-provenance-check.v1", "ok": False, "error": f"YAML parse error: {exc}"}))
        return 2

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=1))
    else:
        print(
            f"chat_provenance_check: ok={result['ok']} chat_ids={result['chat_ids_total']} "
            f"records={result['provenance_records_total']} orphans={len(result['orphan_chat_ids'])} "
            f"missing_fields={len(result['missing_fields'])}"
        )

    return 0 if result["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
