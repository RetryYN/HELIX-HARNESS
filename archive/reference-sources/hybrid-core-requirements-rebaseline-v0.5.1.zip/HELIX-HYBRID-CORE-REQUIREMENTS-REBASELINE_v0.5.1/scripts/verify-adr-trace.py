#!/usr/bin/env python3
"""RUNTIME-CONFLICT-03 検証: ADR-* sources と traceability edge の双方向整合。

requirements-catalog.yaml で sources に ADR-* を持つ全要件について、
traceability.yaml に ADR-* -> 要件ID の refined_into edge が存在すること、
および逆方向（edge があるのに sources に無い）が無いことを検査する。不一致は exit 1。
"""
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
cat = yaml.safe_load((ROOT / 'requirements' / 'requirements-catalog.yaml').read_text(encoding='utf-8'))
trace = yaml.safe_load((ROOT / 'requirements' / 'traceability.yaml').read_text(encoding='utf-8'))

reqs = cat.get('requirements', [])
edges = trace.get('edges', [])
adr_edges = {(e.get('from'), e.get('to')) for e in edges
             if isinstance(e.get('from'), str) and e['from'].startswith('ADR-')}

want = set()
for r in reqs:
    for s in r.get('sources', []) or []:
        if isinstance(s, str) and s.startswith('ADR-'):
            want.add((s, r['id']))

missing = sorted(want - adr_edges)
extra = sorted(adr_edges - want)
print(f'adr_source_pairs={len(want)} adr_edges={len(adr_edges)} missing_edges={len(missing)} extra_edges={len(extra)}')
for m in missing:
    print('  missing edge:', m[0], '->', m[1])
for e in extra:
    print('  edge without source:', e[0], '->', e[1])
if missing or extra:
    print('FAIL: ADR sources と traceability edge が双方向一致しない')
    sys.exit(1)
print('PASS: ADR sources <-> edges 双方向一致')
