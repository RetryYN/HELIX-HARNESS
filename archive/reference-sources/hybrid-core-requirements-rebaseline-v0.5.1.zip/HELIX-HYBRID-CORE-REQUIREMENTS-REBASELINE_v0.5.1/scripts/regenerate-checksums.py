#!/usr/bin/env python3
"""MANIFEST.jsonのfilesからCHECKSUMS.mdを決定的に再生成する。"""

import hashlib
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser()
parser.add_argument("--check", action="store_true")
args = parser.parse_args()
manifest = json.loads((ROOT / "MANIFEST.json").read_text(encoding="utf-8"))
rows = ["# SHA-256", ""]
for relative in manifest["files"]:
    path = ROOT / relative
    if not path.is_file():
        raise SystemExit(f"missing manifest file: {relative}")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    rows.append(f"`{digest}`  `{relative}`")
rendered = "\n".join(rows) + "\n"
checksum_path = ROOT / "CHECKSUMS.md"
if args.check:
    if not checksum_path.is_file() or checksum_path.read_text(encoding="utf-8") != rendered:
        raise SystemExit("CHECKSUMS.md is stale")
    print(f"CHECKSUMS.md is current: {len(manifest['files'])} entries")
else:
    checksum_path.write_text(rendered, encoding="utf-8")
    print(f"wrote CHECKSUMS.md: {len(manifest['files'])} entries")
