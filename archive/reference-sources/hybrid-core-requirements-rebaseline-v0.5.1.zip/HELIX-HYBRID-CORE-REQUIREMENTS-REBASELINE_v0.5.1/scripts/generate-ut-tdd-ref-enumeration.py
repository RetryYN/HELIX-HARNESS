#!/usr/bin/env python3
"""GitHubのbranch/tag/PR headを固定snapshotへ列挙する。"""

import argparse
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def gh_json(endpoint: str) -> object:
    result = subprocess.run(
        ["gh", "api", endpoint],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(result.stdout)


def paged(repo: str, resource: str) -> list[dict]:
    rows: list[dict] = []
    page = 1
    while True:
        separator = "&" if "?" in resource else "?"
        batch = gh_json(f"repos/{repo}/{resource}{separator}per_page=100&page={page}")
        if not isinstance(batch, list):
            raise RuntimeError(f"GitHub response is not a list: {resource}")
        rows.extend(batch)
        if len(batch) < 100:
            return rows
        page += 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository", default="unison-ai-product/UT-TDD_AGENT-HARNESS")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("inventory/ut-tdd-ref-enumeration.json"),
    )
    args = parser.parse_args()

    branches = paged(args.repository, "branches")
    tags = paged(args.repository, "tags")
    pulls = paged(args.repository, "pulls?state=all")
    snapshot = {
        "schema_version": "helix-ut-ref-enumeration/v1",
        "repository": args.repository,
        "observed_at": datetime.now(timezone.utc).isoformat(),
        "generator": "scripts/generate-ut-tdd-ref-enumeration.py",
        "commands": [
            "gh api repos/{repository}/branches",
            "gh api repos/{repository}/tags",
            "gh api repos/{repository}/pulls?state=all",
        ],
        "branches": [
            {
                "ref": row["name"],
                "sha": row["commit"]["sha"],
                "protected": bool(row.get("protected")),
            }
            for row in sorted(branches, key=lambda item: item["name"])
        ],
        "tags": [
            {"ref": row["name"], "sha": row["commit"]["sha"]}
            for row in sorted(tags, key=lambda item: item["name"])
        ],
        "pulls": [
            {
                "number": row["number"],
                "state": row["state"],
                "head_ref": row["head"]["ref"],
                "head_sha": row["head"]["sha"],
                "base_ref": row["base"]["ref"],
                "merge_commit_sha": row.get("merge_commit_sha"),
                "merged_at": row.get("merged_at"),
            }
            for row in sorted(pulls, key=lambda item: item["number"])
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(
        f"wrote {args.output}: branches={len(snapshot['branches'])} "
        f"tags={len(snapshot['tags'])} pulls={len(snapshot['pulls'])}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
