#!/usr/bin/env python3
"""AC-CORE-04 検証: bulk TS再実装の PO 個別承認ゲート（ADR-010 決定1）。

保護対象は v0.5.1 時点で採用済み（reuse_as_is/patch/wrap/split）の意味コア 24 ファイル。
(1) baseline 採用行が replace/reject へ転じている、または (2) いずれかの行に decision:
replace（TS/Node 等による置換）が現れた場合、decisions/decision-ledger.md に
status=confirmed の bulk TS再実装承認 D-ID 行が無ければ exit 1（fail-close）。
baseline 非採用 5 件（fix_names/package/selftest/style/util = 汎用ユーティリティ、
実行境界責務）は意味コア採用ではないため本ゲートの保護対象外。
"""
import re
import sys
from pathlib import Path

import yaml

BASELINE_ADOPTED = {
    'tools/activation.py', 'tools/agent_docs.py', 'tools/agent_meta.py', 'tools/assign.py',
    'tools/build.py', 'tools/consistency.py', 'tools/derive_traces.py', 'tools/diagram_dsl.py',
    'tools/diff_report.py', 'tools/export_sheets.py', 'tools/hook_gate.py', 'tools/id_utils.py',
    'tools/impact.py', 'tools/md_export.py', 'tools/render.py', 'tools/review.py',
    'tools/schedule.py', 'tools/schema_check.py', 'tools/scope.py', 'tools/spec_check.py',
    'tools/spec_trace.py', 'tools/spec_types.py', 'tools/validate.py', 'tools/verify_files.py',
}

ROOT = Path(__file__).resolve().parent.parent
ledger = yaml.safe_load((ROOT / 'inventory' / 'python-partial-modification-ledger.yaml').read_text(encoding='utf-8'))
files = ledger.get('files', []) if isinstance(ledger, dict) else []
by_path = {f.get('path'): f for f in files}

violations = []
for path in sorted(BASELINE_ADOPTED):
    row = by_path.get(path)
    if row is None:
        violations.append(f'{path}: baseline採用行が台帳から消失')
    elif row.get('decision') in ('replace', 'reject'):
        violations.append(f"{path}: baseline採用行が decision={row['decision']} へ転換")
for f in files:
    if f.get('decision') == 'replace' and f.get('path') not in BASELINE_ADOPTED:
        violations.append(f"{f.get('path')}: 新規 replace（TS/Node置換）")

decision_text = (ROOT / 'decisions' / 'decision-ledger.md').read_text(encoding='utf-8')
approvals = [
    line for line in decision_text.splitlines()
    if re.search(r'\|\s*D-\d+\s*\|', line)
    and 'confirmed' in line
    and re.search(r'(bulk\s*TS再実装|TS再実装.*承認)', line)
]

print(f'ledger_files={len(files)} baseline_adopted={len(BASELINE_ADOPTED)} violations={len(violations)} confirmed_bulk_ts_approvals={len(approvals)}')
for v in violations:
    print('  violation:', v)

if violations and not approvals:
    print('FAIL: 意味コア採用行の TS 置換/廃止に confirmed 承認 D-ID が無い (AC-CORE-04)')
    sys.exit(1)
print('PASS: AC-CORE-04')
