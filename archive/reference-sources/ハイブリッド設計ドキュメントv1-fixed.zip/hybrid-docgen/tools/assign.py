# -*- coding: utf-8 -*-
"""実行割当台帳（assign）: 左翼(設計)の宣言から ID単位の実行タスクを導出し、
実行記録そのものを信号として工程表へ還流する。

  python tools/build.py assign    # docs/assign.yaml を生成/マージ + build/00_実行割当台帳_*.xlsx
  python tools/build.py signals   # docs/assign.yaml → build/signals.json を導出（証跡必須）
  python tools/build.py schedule --live   # 信号を工程表へ反映（既存機能）

台帳の意味論:
- 実装タスク(F-/NF-系): status = todo / doing / done / blocked
    done    → signals.impl[id] = true
    blocked → signals.impl[id] = false（apply_live が「未実装」黄にする）
- 検証タスク(UT-/IT-/ST-/AT-): status = todo / pass / fail
    pass/fail → signals.tests[id]（fail は対応要件を赤にする）
- done/pass/fail の行は evidence(証跡: 実行日・コマンド・結果要点) が必須。無ければ signals は exit 1。
- assign の再実行は冪等マージ: 既存行の status/evidence/assignee/date を温存し、新IDを追加、消えたIDを警告。
"""
import os, sys, json, re
import yaml
import id_utils as IU

# 証跡に最低1つ要求する「検証可能なアンカー」: URL / チケット参照(#123, JIRA-123) /
# ファイルパスや拡張子つき名 / PR参照。単なる「OKでした」を弾く。
EVID_RE = re.compile(r"(https?://\S+|#\d+|[A-Z]{2,10}-\d+|PR\s*#?\d+|[\w./\\-]+\.[A-Za-z]{1,5}\b|/[\w./-]+)")

HERE = os.path.dirname(os.path.abspath(__file__))
import sys as _sys; _sys.path.insert(0, HERE)
from util import load_tool
ROOT = os.path.abspath(os.path.join(HERE, ".."))
DOCS = os.path.join(ROOT, "docs")
OUT = os.path.join(ROOT, "build")
LEDGER = os.path.join(DOCS, "assign.yaml")
REQKIND = ("機能要件", "非機能要件")
TESTPFX = {"UT": ("L8", "L5"), "IT": ("L9", "L4"), "ST": ("L10", "L3"), "AT": ("L11", "L2")}
IMPL_ST = ("todo", "doing", "done", "blocked")
VERI_ST = ("todo", "pass", "fail")
SCRUM_IMPL_STATUS = {
    "done": "done", "完了": "done", "済": "done",
    "doing": "doing", "進行中": "doing", "着手中": "doing",
    "todo": "todo", "未着手": "todo", "next": "todo", "次": "todo",
    "blocked": "blocked", "block": "blocked", "ブロック": "blocked", "停止": "blocked",
}
SCRUM_TEST_RE = re.compile(r"(?<![A-Za-z0-9])(?:AC-\d+(?:-\d+)?|UT-\d+[A-Za-z]?|IT-\d+|ST-\d+|AT-\d+)(?![A-Za-z0-9._-])")


def _declared():
    """docs/ の spec.defines を (doc, entry) で列挙する。"""
    import glob
    for fp in sorted(glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml"))):
        d = yaml.safe_load(open(fp, encoding="utf-8")) or {}
        name = os.path.basename(fp)[:-5]
        for e in (d.get("spec", {}) or {}).get("defines", []) or []:
            yield name, e


def _doc_paths():
    import glob
    return sorted(glob.glob(os.path.join(DOCS, "[0-9][0-9]*_*.yaml")))


def _load_doc_by_prefix(prefix):
    for fp in _doc_paths():
        if os.path.basename(fp).startswith(prefix + "_"):
            return os.path.basename(fp)[:-5], yaml.safe_load(open(fp, encoding="utf-8")) or {}
    return None, {}


def _status(value):
    raw = str(value or "").strip()
    return SCRUM_IMPL_STATUS.get(raw.lower(), SCRUM_IMPL_STATUS.get(raw, "todo"))


def _scrum_acceptance_verify():
    """Hybrid向け: 29のAC一覧を検証タスクへ接続する。"""
    name, doc = _load_doc_by_prefix("29")
    if not doc:
        return []
    rows = []
    for ch in doc.get("chapters", []) or []:
        if "受入基準" not in str(ch.get("title", "")) and "AC" not in str(ch.get("title", "")):
            continue
        for b in ch.get("blocks", []) or []:
            if b.get("t") != "table":
                continue
            for r in b.get("rows", []) or []:
                if len(r) < 2:
                    continue
                ac, story = str(r[0]).strip(), str(r[1]).strip()
                if not IU.is_id(ac) or not ac.startswith("AC-"):
                    continue
                rows.append({"id": ac, "kind": "受入基準", "source": name,
                             "traces": [story] if IU.is_id(story) else [], "level": "AC",
                             "status": "todo", "assignee": "", "date": "", "evidence": ""})
    return rows


def _plain_test_ids(value):
    return set(SCRUM_TEST_RE.findall(str(value or "")))


def _scrum_sprint_impl(acceptance_rows):
    """Hybrid向け: 116のスプリントバックログを実行タスクへ接続する。"""
    name, doc = _load_doc_by_prefix("116")
    if not doc:
        return []
    story_to_ac = {}
    for r in acceptance_rows:
        for s in r.get("traces") or []:
            story_to_ac.setdefault(s, []).append(r["id"])
    sprint_id = "SP"
    for ch in doc.get("chapters", []) or []:
        for b in ch.get("blocks", []) or []:
            if b.get("t") == "kv":
                for k, v in b.get("rows", []) or []:
                    if "スプリントID" in str(k):
                        sprint_id = str(v).strip() or sprint_id
    out, seq = [], 1
    for ch in doc.get("chapters", []) or []:
        if "バックログ" not in str(ch.get("title", "")):
            continue
        for b in ch.get("blocks", []) or []:
            if b.get("t") != "table":
                continue
            for r in b.get("rows", []) or []:
                if len(r) < 5:
                    continue
                pbi, task, assignee, _, state = [str(x).strip() for x in r[:5]]
                check = str(r[5]).strip() if len(r) > 5 else ""
                st = _status(state)
                tid = f"{sprint_id}-TASK-{seq:02d}"
                tests = sorted(_plain_test_ids(check))
                if not tests and pbi in story_to_ac and ("BDD" in check or "29" in check or "受入" in check):
                    tests = sorted(story_to_ac[pbi])
                ev = ""
                if st in ("done", "blocked"):
                    ev = f"docs/{name}.yaml#スプリントバックログ:{tid}"
                out.append({"id": tid, "kind": "スプリントタスク", "source": name,
                            "design": [pbi] if IU.is_id(pbi) else [],
                            "tests": tests, "pair": "Scrum",
                            "status": st, "assignee": assignee, "date": "", "evidence": ev,
                            "task": task})
                seq += 1
    return out


def derive():
    """左翼の宣言から 実装タスク/検証タスク を導出する。"""
    b = load_tool("build")
    docs, defmap, defall, refs, dep = b._extract_ids()
    phase = b._PHASE
    impl, verify = [], []
    for doc, e in _declared():
        i, kind = e.get("id"), e.get("kind", "")
        if not i:
            continue
        pfx = i.split("-")[0]
        if kind in REQKIND:
            tests = list(e.get("tests") or [])
            # 対応設計 = 設計工程(phase>=4)でこのIDを参照する文書
            design = sorted(d for d, rs in refs.items()
                            if i in rs and phase.get(d.split("_")[0]) in (2, 3))
            pairs = sorted({f"{TESTPFX[t.split('-')[0]][1]}⇔{TESTPFX[t.split('-')[0]][0]}"
                            for t in tests if t.split("-")[0] in TESTPFX})
            impl.append({"id": i, "kind": kind, "source": doc,
                         "design": design, "tests": tests,
                         "pair": ",".join(pairs)})
        elif pfx in TESTPFX:
            verify.append({"id": i, "kind": kind, "source": doc,
                           "traces": list(e.get("traces_from") or []),
                           "level": TESTPFX[pfx][0]})
    if b._is_scrum_mode():
        scrum_verify = _scrum_acceptance_verify()
        existing_impl = {r["id"] for r in impl}
        existing_verify = {r["id"] for r in verify}
        impl.extend(r for r in _scrum_sprint_impl(scrum_verify) if r["id"] not in existing_impl)
        verify.extend(r for r in scrum_verify if r["id"] not in existing_verify)
    return impl, verify


def _fresh(row, is_impl):
    r = dict(row)
    r.setdefault("status", "todo")
    r.setdefault("assignee", "")
    r.setdefault("date", "")
    r.setdefault("evidence", "")
    return r


def _merge_kept(row, old_row, kept):
    if row.get("kind") == "スプリントタスク":
        # 116_スプリント計画が Scrum 運営レイヤの状態正本。旧生成の todo で検出状態を覆わない。
        for k in ("assignee", "date"):
            if k in old_row:
                row[k] = old_row[k]
        if old_row.get("status") not in ("", None, "todo") and old_row.get("evidence"):
            for k in ("status", "evidence"):
                if k in old_row:
                    row[k] = old_row[k]
        return row
    for k in kept:
        if k in old_row:
            row[k] = old_row[k]
    return row


def cmd_assign():
    impl, verify = derive()
    old = {}
    if os.path.exists(LEDGER):
        prev = yaml.safe_load(open(LEDGER, encoding="utf-8")) or {}
        for sec in ("impl", "verify"):
            for r in prev.get(sec) or []:
                old[(sec, r.get("id"))] = r
    kept = {"status", "assignee", "date", "evidence"}
    prev_arch = []
    if os.path.exists(LEDGER):
        prev_arch = (yaml.safe_load(open(LEDGER, encoding="utf-8")) or {}).get("archived") or []
    out = {"note": "実行割当台帳: 左翼の宣言から自動導出。status/assignee/date/evidence のみ手で更新する"
                    "（他の列は assign 再実行で上書き）。宣言から消えたIDの記録は archived に退避（監査証跡）。",
           "impl": [], "verify": [], "archived": prev_arch}
    stale = set(old)
    for sec, rows in (("impl", impl), ("verify", verify)):
        for r in rows:
            row = _fresh(r, sec == "impl")
            o = old.get((sec, r["id"]))
            if o:
                row = _merge_kept(row, o, kept)
                stale.discard((sec, r["id"]))
            out[sec].append(row)
    for sec, i in sorted(stale):
        r = dict(old[(sec, i)]); r["section"] = sec
        out["archived"].append(r)
    if not out["archived"]:
        del out["archived"]
    yaml.safe_dump(out, open(LEDGER, "w", encoding="utf-8"),
                   allow_unicode=True, sort_keys=False, width=120)
    n_done = sum(1 for r in out["impl"] if r["status"] == "done")
    n_pass = sum(1 for r in out["verify"] if r["status"] == "pass")
    print(f"[assign] 実装 {len(out['impl'])} 件(done {n_done}) / 検証 {len(out['verify'])} 件(pass {n_pass})"
          f" → docs/assign.yaml")
    for sec, i in sorted(stale):
        print(f"  ! 宣言から消えたID → archived に退避（記録保全）: [{sec}] {i}")
    emit_xlsx(out)
    return 0


def emit_xlsx(led):
    import style as S
    from openpyxl import Workbook
    b = load_tool("build")
    wb = Workbook(); wb.remove(wb.active)
    spec = [("実装タスク", "impl",
             [("ID", 10), ("種別", 12), ("宣言元", 22), ("対応設計", 34), ("完了条件テスト", 22),
              ("V字対", 12), ("状態", 8), ("担当", 10), ("日付", 11), ("証跡", 40)],
             lambda r: [r["id"], r["kind"], r["source"], ", ".join(r["design"]), ", ".join(r["tests"]),
                        r["pair"], r["status"], r["assignee"], r["date"], r["evidence"]]),
            ("検証タスク", "verify",
             [("ID", 10), ("種別", 12), ("宣言元", 22), ("トレース元", 16), ("検証レベル", 10),
              ("状態", 8), ("担当", 10), ("日付", 11), ("証跡", 40)],
             lambda r: [r["id"], r["kind"], r["source"], ", ".join(r["traces"]), r["level"],
                        r["status"], r["assignee"], r["date"], r["evidence"]])]
    for title, sec, cols, f in spec:
        ws = wb.create_sheet(title); ws.sheet_view.showGridLines = False
        last = chr(ord('A') + len(cols) - 1)
        S.merge(ws, f"A1:{last}1", f"実行割当台帳（{title}） — docs/assign.yaml が正本",
                S.F(13, True, S.WHITE), S.L, S.NAVY)
        ws.row_dimensions[1].height = 22
        for ci, (h, w) in enumerate(cols):
            c = ws.cell(row=2, column=ci + 1, value=h)
            c.font = S.F(10, True, S.WHITE); c.fill = S.fill(S.BLUE); c.border = S.BORDER
            ws.column_dimensions[chr(ord('A') + ci)].width = w
        for ri, r in enumerate(led[sec], start=3):
            for ci, v in enumerate(f(r)):
                c = ws.cell(row=ri, column=ci + 1, value=v); c.border = S.BORDER
                c.font = S.F(10)
                if v in ("fail", "blocked"): c.fill = S.fill("FFC7CE")
                elif v in ("pass", "done"): c.fill = S.fill("C6EFCE")
    p = os.path.join(OUT, f"00_実行割当台帳_{b.LBL}.xlsx")
    os.makedirs(OUT, exist_ok=True); wb.save(p)
    print(f"[assign] → build/00_実行割当台帳_{b.LBL}.xlsx")


def cmd_signals(check_only=False):
    if not os.path.exists(LEDGER):
        if check_only:
            print("[signals] 台帳なし（assign未運用）→ 検査スキップ")
            return 0
        print("[signals] docs/assign.yaml がありません。先に `python tools/build.py assign` を実行してください。")
        return 1
    led = yaml.safe_load(open(LEDGER, encoding="utf-8")) or {}
    issues, tests, impl = [], {}, {}
    for r in led.get("verify") or []:
        st = r.get("status", "todo")
        if st not in VERI_ST:
            issues.append(f"検証 {r.get('id')}: 不正な status '{st}'（todo/pass/fail）")
        elif st in ("pass", "fail"):
            ev = str(r.get("evidence", "")).strip()
            if not ev:
                issues.append(f"検証 {r.get('id')}: status={st} だが証跡(evidence)が空")
            elif not EVID_RE.search(ev):
                issues.append(f"検証 {r.get('id')}: 証跡に検証可能なアンカーが無い"
                              f"（URL/チケット#/ファイルパス/PR番号のいずれかを含めること）: '{ev[:40]}'")
            tests[r["id"]] = st
    for r in led.get("impl") or []:
        st = r.get("status", "todo")
        if st not in IMPL_ST:
            issues.append(f"実装 {r.get('id')}: 不正な status '{st}'（todo/doing/done/blocked）")
        elif st in ("done", "blocked"):
            ev = str(r.get("evidence", "")).strip()
            if not ev:
                issues.append(f"実装 {r.get('id')}: status={st} だが証跡(evidence)が空")
            elif not EVID_RE.search(ev):
                issues.append(f"実装 {r.get('id')}: 証跡に検証可能なアンカーが無い"
                              f"（URL/チケット#/ファイルパス/PR番号のいずれかを含めること）: '{ev[:40]}'")
            impl[r["id"]] = (st == "done")
    if issues:
        print(f"[signals] ✗ 台帳の不備 {len(issues)} 件（signals.json は生成しません）:")
        for m in issues: print("   -", m)
        return 1
    if check_only:
        print(f"[signals] ✓ 台帳健全（tests {len(tests)} / impl {len(impl)}、証跡形式OK）")
        return 0
    sig = {"tests": tests, "impl": impl}
    os.makedirs(OUT, exist_ok=True)
    json.dump(sig, open(os.path.join(OUT, "signals.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print(f"[signals] tests {len(tests)} 件 / impl {len(impl)} 件 → build/signals.json")
    print("  次: python tools/build.py schedule --live （工程表へ反映）")
    return 0


if __name__ == "__main__":
    if "--check" in sys.argv:
        sys.exit(cmd_signals(check_only=True))
    sys.exit(cmd_signals() if "signals" in sys.argv else cmd_assign())
