# 8. Detection System Database

検出DBは次のrelation graphを統合します。

```text
Source snapshot
→ Asset / capability / disposition / Python patch record
→ Requirement / workflow / design / task / test
→ Runtime event / capsule / allocation
→ Finding / evidence / audit
→ Improvement candidate / infinity cycle
```

DBのeventはappend-only、viewはrebuildableです。要求文書と既存Python sourceはDBへ投影できますが、DBからsilentに書き戻しません。

初期writerはNode transaction coordinatorです。Python detectorはread-only queryとtyped command requestを使います。Pythonの文書生成はDB writeではなくstaging file outputとして扱い、Nodeのpromotion後にsource/evidence eventを記録します。

`schemas/detection-finding.schema.json`のresolved_by/residual_riskはJSON側optionalだがJSON→DB projectionでは必須の永続化対象であり、detection_findings.resolved_by / detection_findings.residual_riskへNode transaction coordinatorが書き込む（ADR-009/ADR-010: Node実行境界が単一の書き込み口であり、Python意味コアはこの列に直接書き込まない）。finding_events.event_type='resolved'遷移時、payload_digestにresolved_by/residual_riskの値を含めてイベント化する。

finding.evidence[]の各要素は、evidence_recordsのうちsubject_kind='detection_finding' AND subject_id=finding_idに該当する行へ1:1対応するN行として永続化され、detection_findings.evidence_digestは当該evidence_records集合を正規化結合した合成digestである。Nodeがfinding受理時にevidence_records各行を書き込み、evidence_digestを再計算して一致検証した上でdetection_findingsへ書き込む。JSON evidence[]配列とDB上の複数行の対応はsubject_kind/subject_id経由のevidence_records JOINが唯一の正本であり、evidence_digest単独ではevidence[]を復元できない。参照整合性はtrg_evidence_records_detection_finding_fk（INSERT）/trg_evidence_records_detection_finding_fk_update（UPDATE）トリガーでDB層強制する。

将来この schema を実装するNode control plane（別PLANで新設）を追加する際は、同等のラウンドトリップテストをそちらの実装リポジトリにも追加すること。
