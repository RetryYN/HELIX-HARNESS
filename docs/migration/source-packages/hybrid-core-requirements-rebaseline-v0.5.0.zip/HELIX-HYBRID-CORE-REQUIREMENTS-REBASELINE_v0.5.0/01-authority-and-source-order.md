# 1. Authority / Source Order

## 規範precedence

1. 人が承認したHELIXのL0/L1/L2/L3要求・判断記録、および確定ADR（ADR-009-node-python-linux-runtime.md、ADR-001-helix-harness-redesign-and-language.md）
2. 層別権威（ADR-010、同格併記）
   - 意味判断・生成の正本: HELIX Hybrid Python Core（semantic core）のpinned sourceと承認済み部分修正台帳。要件抽出・typed spec・trace・検出・impact・review・文書生成の判断はPythonが正本であり、Nodeはこれを複製・代行しない。
   - 実行・トランザクションの正本: TypeScript / Node runtime contract（本パッケージのHELIX-native Design HARNESS契約・schema・gateを含む）。`harness.db`・Git/GitHubへのcommitと外部副作用は、schema／digest／lease-fence／policy検証を経てNodeの単一境界のみが実行する（ADR-009の存続条項）。DB path・credential・repository・`.helix/`をPythonへ渡さない実装手段も維持する。
3. Workflow Requirements Skill v1.1 adapter contract
4. Detection DBのevent / evidence / projection
5. generated docs / views / reports

Python semantic contractとNode runtime contractは層別権威（ADR-010）であり同格。意味判断の正本はPython、トランザクション・外部副作用の正本はNodeであって、一方を他方の全面上位として扱う記述を禁止する（v0.4.0の『Python上位』とv0.5.0初版の『Node上位』は、いずれもADR-010により層別同格へ改定済み）。

## 変換元と参考元

### Design HARNESS設計ベース

`ut-tdd-design-harness-internalization-v0.1(2).zip`は、HELIX Design HARNESSを作るための
**変換元設計ベース**である。byte pinしてprovenanceを保つが、ファイル内のUT固有名称・配置・gate接続を
そのままHELIX正本へ昇格しない。

Python coreはNodeにより再検証されるproposalの供給源であり、本節のいかなる順位もPythonへのauthoritative write権限を含意しない（ADR-009 §Decision）。

### UT-TDD_AGENT-HARNESS

UT-TDDはHELIXと別製品である。branch / PR / detector / ledger / gateの良い実装を採用候補として調査するが、
UTの要求ID、CLI、state path、DB名、PLAN、role、製品前提はHELIXのauthorityにならない。

#### `unison-ai-product/UT-TDD_AGENT-HARNESS` に対するsole authority（是正 UT-03）

`helix-agent-harness-explicit-repo-all-ref-content-ledger-2026-07-08.tsv` を含む3つのTSV
（外部OSS agent harness競合サーベイ資料。例: bradAGI/awesome-cli-coding-agents、
agentscope-ai/QwenPaw等の一覧）は、`unison-ai-product/UT-TDD_AGENT-HARNESS` のref/行を1件も
含まない（本パッケージおよび当該3TSVに対する `unison-ai-product|UT-TDD_AGENT-HARNESS` grepは
いずれも0件ヒットで機械照合済み）。したがって当該3TSVは `unison-ai-product/UT-TDD_AGENT-HARNESS`
の照合正本としてout-of-scopeであり、採用根拠として引用してはならない。

`unison-ai-product/UT-TDD_AGENT-HARNESS` に対する唯一の権威sourceは、次のいずれかに限定する。

1. `docs/governance/infinity-loop-source-capability-ledger.md` §1.2（前身Git authority
   receipts。`predecessor-ut` 行、本v0.5.0時点でstatus=BLOCKED）。
2. 同 §1.2.1（historical UT heads seed。current authorityではない、
   `authority_reuse_allowed=false` / `coverage_reuse_allowed=false`）。
3. HBR-INV-002が要求するlive Git enumeration（`refs/heads/*`、`refs/tags/*`、open/closed PR
   heads、merge bases）の実行結果（`inventory/ut-tdd-ref-audit.yaml` および将来生成される
   `inventory/ut-tdd-ref-enumeration.log`）。

### 旧HELIX（ai-dev-kit-vscode）

旧HELIXは個別機能ソースの正本であり、仕組み（Vモデル・gate・state DB・harness ルール）には従属する。
粒度に応じてL1=機能エリア/L3=機能ユニット/L4-L6=command/algorithmで取捨選択し、CLI識別子・state pathを
そのままHELIX正本へ昇格しない。棚卸し台帳は`docs/migration/helix-source-inventory.md`（snapshot
destination=`vendor/helix-source/`、copied files=1451、約12.2MiB）と`docs/migration/helix-porting-map.md`
を正本として引用する。

## 禁止

- `ut-tdd` identifierをHELIXのactive contractへ残すこと
- UTのPRや要件をHELIXの上位正本として扱うこと
- Design HARNESSを独立engineとしてHybrid Coreの外へ置くこと
- raw source ZIPを承認済みHELIX contractより優先すること
- Detection DBや生成物からauthoring sourceを逆書きすること
- PythonとNodeのどちらか一方を他方の全面上位の規範として扱うこと（ADR-010: 層別同格）
- ADR-009/ADR-010の権威をこの資料内のprecedenceで暗黙に反転させること
- Node commit境界（harness.db/Git単一書き込み口）を迂回すること、および動作しているPython意味コアのbulk TS再実装（いずれもPO個別承認なしに行うこと）
