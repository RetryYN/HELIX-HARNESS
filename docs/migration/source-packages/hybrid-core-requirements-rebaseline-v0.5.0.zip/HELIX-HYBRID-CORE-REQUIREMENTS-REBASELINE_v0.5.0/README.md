# HELIX Hybrid Core Requirements Rebaseline v0.4.0

本パッケージは、ハイブリッド設計ドキュメントv1の既存PythonをHELIXコアエンジンとして部分修正し、
提示されたDesign HARNESS設計ベースを**HELIX Design HARNESSネイティブ能力**へ統合する要件・契約パッケージである。

## Source roles

- Hybrid Design Document Python: HELIX core implementation baseline
- Design HARNESS v0.1(2): HELIX化するtransformation source
- Workflow Requirements Skill v1.1: elicitation / state-transition judgment adapter
- UT-TDD_AGENT-HARNESS: separate donor/reference product
- 旧HELIX（ai-dev-kit-vscode、git@github.com:RetryYN/ai-dev-kit-vscode.git）: 個別機能（command/skill/subagent/detector/advisor role）ソースの正本。read-only参照専用、bulk import禁止、behavior atom採取のうえTS/Node再実装またはPython proposal worker化する。棚卸し台帳＝`docs/migration/helix-source-inventory.md`／`docs/migration/helix-porting-map.md`。

## Start here

1. `00-executive-rebaseline.md`
2. `17-design-harness-integration.md`
3. `design-harness/python-core-binding.yaml`
4. `design-harness/hybrid-document-binding.yaml`
5. `19-v0.4.0-errata.md`
6. `requirements/requirements-catalog.yaml`
7. `decisions/decision-ledger.md`
8. `14-risks-and-open-decisions.md`

## Decision traceability

- Open decisions（`14-risks-and-open-decisions.md` #Open decisions）と意思決定台帳（`decisions/decision-ledger.md`）は相互参照する。
  各Open decision行は対応するD-ID（またはD-ID無し注記）を明記し、対応するdecision-ledger行は
  `関連Open decision: 14-risks-and-open-decisions.md #Open decisions` を明記する。
- `requirements/requirements-catalog.yaml`の要件エントリは、該当する場合`decision_refs: [D-00x]`欄で
  意思決定台帳のD-IDを参照できる（例: `HBR-CORE-014`, `HBR-ARCH-002`）。
