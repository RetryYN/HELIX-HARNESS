# Existing Hybrid Python / Node mapping

本章の境界定義はADR-009-node-python-linux-runtime.md（accepted）に従属する。ADR-009が改定された場合、本章とHBR-ARCH-*群は同一PLANで追補されなければならない。

| Existing Python | Design HARNESS responsibility |
|---|---|
| activation.py | UI scopeとsignalからoverlay候補を返す |
| schema_check.py | Design HARNESS schema検査 |
| spec_check.py | lifecycle/mission/receipt/profile制約 |
| spec_trace.py / derive_traces.py | L1→L10 semantic edge |
| scope.py / impact.py | UI Change Delta影響分析 |
| schedule.py / assign.py | layer obligation、role、readiness |
| review.py / consistency.py | false implemented claimとdrift検出 |
| build.py / render.py | read-only ledger/diagram/report生成 |
| agent_docs.py | HARNESS Capsuleへdesign contractを注入 |

NodeはPlaywright、axe-core、Lighthouse、snapshot/pixel comparison、Git/GitHub、provider、
canonical promotion、SQLite transactionを担当する。chrome-devtools-mcpはagentic補助でありCI決定経路へ入れない。
