# ADR-000 — Existing Hybrid Python Core Partial-Modification Rebaseline

- Status: proposed
- Supersedes-Check: ADR-009-node-python-linux-runtime (accepted) — 本ADRはADR-009を上書き・逸脱しない。抵触する場合はADR-009が優先する。
- 適用範囲: 本ADRの適用範囲はADR-009の許容範囲内に限定される。
- Decision:
  - `hybrid-docgen/tools/*.py`のうち、ADR-009の許可capability class（`source_atomization`/`document_engine`/`detector`/`product_data`/`analysis`）に属するbehavior atomのみを、versioned contract配下のPython proposal workerとして個別に採用する。それ以外（制御面・writer・orchestration相当）の機能はTS/Nodeで再実装する。bulk portは禁止し、採用単位は個別behavior atomとする。
  - file/function単位に`reuse_as_is / patch / wrap / split / replace / reject`を記録する
  - original archive/file digestとgolden behaviorをrollback/parity基準とする
  - 旧path/CLIをcompatibility facadeとして保持する
  - Pythonはgenerated/staging outputを生成し、Nodeがcanonical promotionと外部副作用を所有する。Nodeがschema・lineage・digest・lease/fence・policyを再検証し、唯一のtransaction writerとしてcommitする。Pythonはnetwork default denyとし、DB path・credential・repository・`.helix/`を受け取らない。
  - TypeScript/NodeをBun-free runtime/adapter層とする
  - Linuxをprimary platformとする
  - Workflow Requirements Engine v1.1をadapterで接続する
  - Detection DB、HARNESS Capsule、Infinity Loopをfirst-class contractにする
- Supersedes:
  - TS/Bun-only core assumptions
  - HELIX workflow-spine v0.2 proposal
  - v0.3.0のmandatory `packages/python-core` relocation interpretation
- Consequences:
  - migration量とbehavior riskを抑えられる
  - compatibility facadeとgolden suiteを一定期間維持する必要がある
  - physical path migrationは別cutoverになる
  - dual-language contract disciplineは引き続き必要

本ADRはPO承認までproposedであり、承認前に02章以降で確定事実として記述してはならない。
