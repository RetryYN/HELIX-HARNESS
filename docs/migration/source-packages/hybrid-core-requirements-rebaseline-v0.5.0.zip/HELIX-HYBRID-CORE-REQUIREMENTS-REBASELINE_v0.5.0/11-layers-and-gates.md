# 11. L0-L14 / Gate統合

| Layer | Workflow/Hybrid Coreの責務 | Gate追加・強化 |
|---|---|---|
| L0 | 価値・自動化境界・Infinity Loop許容範囲 | value hypothesis / irreversible boundary |
| L1 | 人が要求を作成、AI gap-check | chat/source trace、workflow候補、未決事項 |
| L2 | mock/操作から状態・異常・data要求を露出 | bounded 3 rounds、human convergence |
| L3 | AIがFR/AC/workflow draft、PO承認 | transition completeness、GWT、test pair |
| L4 | architecture、既存Python採用境界、Node責務、risk/allocation objective | original snapshot、disposition、no-big-bang-rewrite |
| L5 | API/DB/event/protocol/capsule、staging/promotion詳細 | schema/transaction/idempotency/fallback |
| L6 | file/function patch contract、task/resource/test oracle | golden parity、compat facade、Node/Python conformance、L8 unit design |
| L7 | 部分修正・adapter・Node実装 | Bun absence、patch scope、capsule/admission/evidence |
| L8-L12 | unit→integration→system→UX→acceptance | original-vs-patched parity、branch/loop/terminal/resource/crash evidence |
| L13 | deployment smoke/monitoring | Linux primary、rollback to pinned source |
| L14 | operational/value/self-improvement feedback | Infinity Loop audit、patch effectiveness、L0 feedback |

新gate番号を乱造せず、既存gateへtyped sub-checkを追加します。
