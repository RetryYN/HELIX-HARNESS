# 10. Full-ref Adoption

**in-progress: ref enumeration gate未実行**（是正 UT-04）。`inventory/ut-tdd-ref-audit.yaml` の
`coverage_boundary.product_requirement` が要求する `refs/heads/*`、`refs/tags/*`、open/closed PR
heads、merge basesのGitからの直接enumeration（`inventory/ut-tdd-ref-enumeration.log` 生成 +
本ファイルrefs一覧との完全一致確認、AC-INV-02拡張）は本v0.5.0時点で未実施であり、
`coverage_boundary.is_disposition_closed: false`である。したがって以下のPR単位の記述は
disposition closureの確定表明ではなく、enumeration gate通過前の暫定方針（`_provisional_pending_receipt`、
ledger §1.2 `predecessor-ut` status=BLOCKED解除待ち）として読む。

既存資産の採用は「mainをgrepした」だけでは閉じません。Git refs、archive、uploads、generated assetsに加え、Hybrid Pythonはfile/function単位で棚卸しします。

Python adoptionの既定は保存的です。

```text
reuse_as_is → patch → wrap → split → replace/reject
```

右へ進むほど、必要なevidenceとapprovalを強くします。

PR #64はclosed admission tuple、atomic draft、receipt、journal、diff fenceを持つためNode runtimeへ`split`採用を暫定方針とします（`adopt_with_hardening_provisional_pending_receipt`、enumeration gate通過前）。Bun依存と現行path前提を外し、domain contractを抽出します。

PR #54はmainよりahead 0であり、code adoptionは`reject`方針を暫定維持、監査履歴は保持します（enumeration gate通過前は確定closureとしない）。
