#!/usr/bin/env bash
# validation/detection-findings-resolved-fields.sh
#
# 是正F1の機械検証。sqlite3 CLIでdatabase/detection-system-schema.sqlを直接ロードし、
# detection_findings.resolved_by / detection_findings.residual_risk のNULLABLE設計を検証する。
# Node control plane実装非依存で成立する（本パッケージには対応するNode実装がまだ存在しない）。
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
SCHEMA="${PKG_ROOT}/database/detection-system-schema.sql"
WORKDIR="$(mktemp -d)"
DB="${WORKDIR}/detection-findings-resolved-fields.test.db"

cleanup() { rm -rf "${WORKDIR}"; }
trap cleanup EXIT

echo "[1/3] load schema"
sqlite3 "${DB}" < "${SCHEMA}"

echo "[2/3] non-resolved status keeps resolved_by/residual_risk NULL"
sqlite3 "${DB}" <<'SQL'
INSERT INTO source_snapshots (source_snapshot_id, source_kind, locator, ref_name, content_digest, observed_at)
VALUES ('snap-1', 'git_ref', 'origin/main', 'main', 'digest-1', '2026-07-17T00:00:00Z');

INSERT INTO detection_findings
  (finding_id, finding_type, severity, status, source_snapshot_id, detector_id, detector_version,
   detector_policy_digest, evidence_digest, route, created_at, updated_at)
VALUES
  ('finding-candidate', 'lint', 'warning', 'candidate', 'snap-1', 'detector-a', '1.0.0',
   'policy-digest-1', 'evidence-digest-1', 'route-a', '2026-07-17T00:00:00Z', '2026-07-17T00:00:00Z');
SQL

NULL_CHECK=$(sqlite3 "${DB}" "SELECT resolved_by IS NULL AND residual_risk IS NULL FROM detection_findings WHERE finding_id='finding-candidate';")
if [ "${NULL_CHECK}" != "1" ]; then
  echo "FAIL: non-resolved finding must keep resolved_by/residual_risk NULL" >&2
  exit 1
fi
echo "OK: non-resolved finding rows keep resolved_by/residual_risk NULL"

echo "[3/3] resolved status carries resolved_by/residual_risk values"
sqlite3 "${DB}" <<'SQL'
INSERT INTO detection_findings
  (finding_id, finding_type, severity, status, source_snapshot_id, detector_id, detector_version,
   detector_policy_digest, evidence_digest, route, created_at, updated_at, resolved_by, residual_risk)
VALUES
  ('finding-resolved', 'lint', 'warning', 'resolved', 'snap-1', 'detector-a', '1.0.0',
   'policy-digest-1', 'evidence-digest-2', 'route-a', '2026-07-17T00:00:00Z', '2026-07-17T01:00:00Z',
   'reviewer-x', 'residual-risk-note');
SQL

RESOLVED_CHECK=$(sqlite3 "${DB}" "SELECT resolved_by || '|' || residual_risk FROM detection_findings WHERE finding_id='finding-resolved';")
if [ "${RESOLVED_CHECK}" != "reviewer-x|residual-risk-note" ]; then
  echo "FAIL: resolved finding must persist resolved_by/residual_risk values, got: ${RESOLVED_CHECK}" >&2
  exit 1
fi
echo "OK: resolved finding rows persist resolved_by/residual_risk values (${RESOLVED_CHECK})"

echo "PASS: validation/detection-findings-resolved-fields.sh"
