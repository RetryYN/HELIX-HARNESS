#!/usr/bin/env python3
"""是正 UT-04 の機械検証（package内で完結する部分）。

inventory/ut-tdd-ref-audit.yaml の coverage_boundary.product_requirement が要求する
live ref enumeration（`git for-each-ref` + GitHub PR API列挙、
inventory/ut-tdd-ref-enumeration.log）が未生成の間、以下を確認する:

  1. coverage_boundary.is_disposition_closed が false であること。
  2. 00-executive-rebaseline.md / 10-full-ref-adoption.md が、ut-tdd由来refの
     disposition closureを確定済み事実として断定する語（「全検査」+「確定」等の同時出現、
     または「抽出採用強化」を完了表現として使う語）を含まないこと。

inventory/ut-tdd-ref-enumeration.log が存在する場合は、そこに列挙されたref集合と
ut-tdd-ref-audit.yaml の refs[].ref 集合が完全一致することを比較する
（diff/set比較、exit code根拠）。
"""
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("FAIL: pyyaml not available", file=sys.stderr)
    sys.exit(1)

HERE = Path(__file__).resolve().parent
PKG_ROOT = HERE.parent
AUDIT_PATH = PKG_ROOT / "inventory" / "ut-tdd-ref-audit.yaml"
ENUM_LOG_PATH = PKG_ROOT / "inventory" / "ut-tdd-ref-enumeration.log"
DOC_PATHS = [
    PKG_ROOT / "00-executive-rebaseline.md",
    PKG_ROOT / "10-full-ref-adoption.md",
]

# Confirmed-completion phrasing this correction forbids while enumeration is
# in-progress (the phrase named in the finding, plus the generic pattern of
# asserting exhaustive inspection + finality in the same breath).
FORBIDDEN_PHRASES = [
    "全検査からの抽出採用強化",
]

errors = []


def main() -> int:
    if not AUDIT_PATH.exists():
        print(f"FAIL: {AUDIT_PATH} not found", file=sys.stderr)
        return 1

    doc = yaml.safe_load(AUDIT_PATH.read_text(encoding="utf-8"))
    coverage = doc.get("coverage_boundary", {})
    enum_status = coverage.get("enumeration_status", "")
    is_closed = coverage.get("is_disposition_closed")

    enum_done = ENUM_LOG_PATH.exists()

    if not enum_done:
        if is_closed is not False:
            errors.append(
                "coverage_boundary.is_disposition_closed must be false while "
                f"{ENUM_LOG_PATH.name} does not exist (got {is_closed!r})"
            )
        if "in-progress" not in enum_status:
            errors.append(
                "coverage_boundary.enumeration_status must state 'in-progress' "
                "while enumeration log is absent"
            )
        for doc_path in DOC_PATHS:
            if not doc_path.exists():
                errors.append(f"{doc_path} not found")
                continue
            text = doc_path.read_text(encoding="utf-8")
            for phrase in FORBIDDEN_PHRASES:
                if phrase in text:
                    errors.append(
                        f"{doc_path.name} contains forbidden confirmed-completion "
                        f"phrase {phrase!r} while enumeration is in-progress"
                    )
    else:
        enum_refs = {
            line.strip()
            for line in ENUM_LOG_PATH.read_text(encoding="utf-8").splitlines()
            if line.strip()
        }
        audit_refs = {r.get("ref") for r in doc.get("refs", [])}
        if enum_refs != audit_refs:
            missing_in_log = audit_refs - enum_refs
            extra_in_log = enum_refs - audit_refs
            errors.append(
                "enumeration log ref set does not match ut-tdd-ref-audit.yaml refs: "
                f"missing_in_log={sorted(missing_in_log)} extra_in_log={sorted(extra_in_log)}"
            )

    if errors:
        print("FAIL: verify-full-ref-adoption-status")
        for e in errors:
            print(f"  - {e}")
        return 1

    print(
        "PASS: verify-full-ref-adoption-status "
        f"(enumeration_log_present={enum_done})"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
