# TODO — v0.5.0 authority是正 由来の将来lintチェック（リポジトリ側新設）

本ファイルは是正 AUTH-004(3) のfalsifiable claim検証を、パッケージ内で完結しない
リポジトリ側将来テストとして記録するNOTEである（ADR-009 / CLAUDE.md PLAN claim discipline準拠）。

## TODO: decision-ledger proposed/断定表現 近接lint

- 対象: `00-executive-rebaseline.md`、`02-core-engine-definition.md` の本文が、
  `decisions/decision-ledger.md` 内 status=proposed の決定ID（D-001〜D-013、ADR-000）を
  断定的事実表現（例:「である」「固定する」）として参照していないことを検出するCIチェック。
- 想定実装場所: HELIX-HARNESS本体リポジトリの `tests/` 配下（例:
  `tests/plan-claim-discipline.test.ts` 相当）に新設する。schema/grep検査で、
  decision-ledger.md の `status` フィールドと、参照元docsの断定キーワードの近接をlintする。
- 現時点（本パッケージ内）でのpartial verification: 本パッケージ内では
  `00-executive-rebaseline.md` / `02-core-engine-definition.md` の該当箇所を
  「（proposed、PO承認待ち）…提案する」调へ書き換え済みであることをgrepで確認済み
  （下記 self_checks 参照）。
- confirmed化条件: decision-ledger.md 該当決定IDが `status: confirmed` (または `accepted`) へ
  遷移した後にのみ、本文の断定調表現への復帰を許可する。

## TODO: runtime-boundary是正（RB-01〜RB-08）由来の将来リポジトリ側テスト

本パッケージ内で完結する検証（YAML/JSON parse、grep、ID重複検査、sources/traceability整合）は
このセッションで実行済み（下記 self_checks 参照）。リポジトリ本体側で新設すべき機械テストのみ
ここにTODOとして記録する。

- RB-04: Python worker起動adapterの単体テストで、生成されるsubprocess引数・env varにDBファイルパス・
  接続文字列・credentialトークンが含まれないことをアサートするテスト
  （例: `tests/python-worker-invocation.test.ts`）を新設する。
- RB-06: AC-SEC-PY-01対応のNodeテスト（例: `tests/python-worker-sandbox.test.ts`）で、
  (1) worker起動コマンド生成関数の出力引数・envにDB path/credentialが含まれないことのアサーション、
  (2) network default denyの起動設定（seccomp/network namespace/sandboxフラグ）のアサーション、
  (3) Python proposal出力を直接execする経路が存在しないことの静的検査（grep/ASTベースのlint rule）を
  実装し、harness-check gateへ組み込む。
- RB-07: `PLAN-M-01-cutover-backfill.md`系のcutover実行コマンド（`plan/execute/commit/reconcileNodeCutover`相当）が
  発行する`CutoverActivationReceipt`の構造（epoch・expected DB revision・fixed write set・approval記録を含むJSON）を
  schemaバリデーションし、receipt欠如時にAC-ARCH-02判定コマンドがfailすることを
  `tests/projection-writer.test.ts`等の既存cutover回帰テスト群に統合する。
- RB-08: terminal cutover receipt発行前後でCI必須ジョブ定義（package.json scripts / CI workflow yaml）を
  差分比較し、receipt発行後のコミットでレガシーCLI呼び出しが必須経路のスクリプトから消えていることを
  grep/diffベースの回帰チェック（AC-ARCH-07）として自動化する。

## TODO: linux-multios是正（LNX-03）由来の孤立sources ID再発防止lint

本パッケージ内で完結する検証（`HYBRID-UTIL`文字列の除去確認、`HNFR-PLAT-006`直下の
`traceability.yaml` refined_into edge検出）はこのセッションで実行済み（下記 self_checks 参照）。
再発防止のための恒常lintはリポジトリ本体側の新設が必要なため、ここにTODOとして記録する。

- LNX-03: `requirements-catalog.yaml` の全エントリの `sources[]` にある各IDが、
  `inventory/chat-requirements.yaml`・`inventory/source-references.yaml`・
  `inventory/ut-tdd-ref-audit.yaml` のいずれかに実体として存在することを検証する
  lint（例: `tests/requirements-sources-integrity.test.ts` または
  `helix plan lint` 相当の traceability lint 拡張）を新設する。孤立ID（当該3ファイル
  いずれにも実体が無いsources ID）が1件でも検出された時点でfail-closeする設計とする
  （`schemas/requirement-contract.schema.json` へのID存在制約追加、または独立lint
  scriptのいずれかで実装可）。

## TODO: capsule是正（CAPSULE-04）由来の将来リポジトリ側テスト

本パッケージ内で完結する検証（schema fixture 6件、CAPSULE-06 roster coverage）は
このセッションで実行済み（`validation/capsule-corrections.log` 参照）。CAPSULE-04 の
digest共有実装検証は実際のClaude/Codex adapterソースを要するため、ここにTODOとして記録する。

- CAPSULE-04 / HBR-AGENT-017: capsule発行を行うClaude adapter経路とCodex adapter経路
  それぞれが `src/runtime/digest.ts` の `canonicalJson`/`sha256Digest` を re-export/import
  しているだけであり、独自の digest 再実装が無いことを静的検査（import経路をassertする
  grepベースのlintテスト）で確認するテストを新設する
  （例: `tests/harness-capsule-digest-conformance.test.ts`）。
- 同テストで、同一capsule fixture（`capsule_digest` を空文字列にした状態）から両adapter経路が
  byte-identicalな `sha256:<hex>` を出力することを比較し、AC-AGENT-09 の conformance suite に
  組み込む。
- 対象adapterソース（`src/subagent/harness-capsule-claude-adapter.ts` /
  `harness-capsule-codex-adapter.ts` 相当）はSlice 9実装時に新設される想定であり、本design
  packageの段階ではplaceholderのhit_idとして `config/digest-canonicalization-inventory.json`
  （本package addendum）に登録済み。

## TODO: infinity-loop是正（INF-01〜INF-10）由来の将来リポジトリ側テスト

本パッケージ内で完結する検証（Ajv fixture PASS/FAIL、$defs/if-then整合、stop_conditions/enum一致、
verdict語彙一致）はこのセッションで実行済み（下記 self_checks 参照）。以下はリポジトリ本体側の
実装・テストを要するため新設が必要なTODOである。

- INF-01(a): `docs/governance/infinity-loop-requirement-coverage-ledger.md` §1/§2から抽出した
  HIL ID allowlist（115件、HIL-BR-01..25/HIL-FR-01..90相当）に対し、`requirements-catalog.yaml`の
  HBR-INF-*の`sources`および`acceptance-criteria.yaml`のAC-INF-*の`traces_to`の全値が
  membershipとして存在することを検証するテスト`test_hbr_inf_sources_are_known_hil_ids`を
  `tests/`配下に新設する（allowlistは新規複製ファイルを作らず、ビルド時にcoverage ledgerから
  直接抽出する）。
- INF-01(b): 本packageのHBR-INF-*エントリへ追記した`sources`（HIL-BR-xx/HIL-FR-xx）は本session
  （Claude、2026-07-17）によるAI委任judgmentのbest-effort mappingであり、人間またはTL advisor
  経由の確認は未実施。`helix plan lint`が`review_evidence`欠落（または「未確認」明記が無い状態）を
  fail-closeとして検出するルールをリポジトリ側で新設し、本packageの各`review_evidence`が
  確認待ちである事実を継続的に可視化する。
- INF-02: `test_ascii_diagram_matches_mmd_transition_order`（09-helix-infinity-loop.mdのASCII図と
  diagrams/infinity-loop.mmdのノード遷移順比較）を`tests/`配下に新設する。
- INF-03/INF-06/INF-08: `test_self_audit_independence_rejects_same_identity`、
  `test_learning_recipe_actor_set_uses_existing_role_separation`など、Node側の実際の
  `HIL_AGENT_VERIFIER_NOT_INDEPENDENT`/`enforceKnowledgePromoterSeparation`実装を呼び出す
  結線テストは、当該Node実装がSlice実装時に確定した後にリポジトリ側`tests/`へ新設する。
- INF-07: `test_no_progress_threshold_maps_to_stop_rule_threshold`（`terminal_policy.no_progress_threshold`
  を`src/orchestration/loop-stop-rules.ts`の`StopRule.threshold`として解釈できることの結線テスト）を
  リポジトリ側に新設する。`repeat`を`StopReason`型へ追加するadd-designは別途PLAN起票が前提。

## TODO: ut-tdd是正（UT-01〜UT-04）由来の将来リポジトリ側テスト

本パッケージ内で完結する検証（`inventory/ut-tdd-ref-audit.yaml`の`reconciled_against`/
`authority_status`/`coverage_boundary.is_disposition_closed`フィールド存在・整合、YAML/JSON parse、
enumeration未実施時の確定断定語不使用）はこのセッションで実行済み
（`validation/verify-ut-tdd-ref-reconciliation.py`、`validation/verify-full-ref-adoption-status.py`、
下記 self_checks 参照）。リポジトリ本体側で新設すべき機械テスト/doctor gateのみここにTODOとして
記録する。

- UT-01/UT-02: `helix doctor source-authority-consistency`（新設doctor gate）を
  `src/doctor/`配下に実装し、(a) `inventory/ut-tdd-ref-audit.yaml`の`authority_status`と
  `docs/governance/infinity-loop-source-capability-ledger.md` §1.2 `predecessor-ut`行の
  statusとの一致、(b) 各refの`reconciled_against`存在数とref件数の一致、(c) 未説明のsha不一致
  （`reconciliation_note`欠如）がある場合の`sha_mismatch_unreconciled`強制、をfail-closeで検証する。
  `validation/verify-ut-tdd-ref-reconciliation.py`のロジックをNode/TS実装へ移植し、
  `tests/doctor-source-authority-consistency.test.ts`として結線する。
- UT-02: `schemas/source-ref-audit.schema.json`をajvへ登録し、`authority_status`欠落のみを
  発生させたfixtureに対してajvのエラーパスが`authority_status`を名指しすることを確認する
  テスト（`tests/schema-source-ref-audit.test.ts`相当）を新設する。
- UT-04: `inventory/ut-tdd-ref-enumeration.log`（`git for-each-ref` + GitHub PR API列挙結果）を
  生成する本番inventoryコマンドをリポジトリ側に実装し、生成後は
  `validation/verify-full-ref-adoption-status.py`相当のロジック（ログのref集合と
  `ut-tdd-ref-audit.yaml`のrefs一覧の完全一致比較）を`tests/ut-tdd-ref-enumeration-parity.test.ts`
  として新設する。ログ生成後にのみ`coverage_boundary.is_disposition_closed`を`true`へ遷移してよい。

## TODO: github-freshness是正（GH-01〜GH-03）由来の将来リポジトリ側doctor gate/テスト

本パッケージ内で完結する検証（`inventory/ut-tdd-ref-audit.yaml`のYAML parse、
`schemas/source-ref-audit.schema.json`に対するschema validate、
`validation/verify-ut-tdd-ref-reconciliation.py`・`validation/verify-full-ref-adoption-status.py`の
再実行、`schemas/source-inventory.schema.json`改訂版がunsatisfiableでないことのfixture検証）は
このセッションで実行済み（下記 self_checks 参照、`validation/verify-source-inventory-freshness-sla.py`
新設）。リポジトリ本体側で新設すべき機械テスト/doctor gateのみここにTODOとして記録する。

- GH-01: `helix doctor source-ref-freshness`（新設doctor gate）を`src/doctor/`配下に実装し、
  対象上流リポジトリで`git fetch origin && git rev-parse origin/main`を実行した結果のshaが
  `inventory/ut-tdd-ref-audit.yaml`の`refs[main].sha`と一致することを検査する。不一致
  （delta>0かつobserved_at更新なし）ならfail-closeする回帰テスト（例:
  `tests/doctor-source-ref-freshness.test.ts`）を新設する。
- GH-02: `helix doctor ref-coverage-completeness`（新設doctor gate）を実装し、
  `git for-each-ref refs/heads refs/remotes`の出力に含まれる全refが
  `inventory/ut-tdd-ref-audit.yaml`のrefs配列に1:1で存在することを比較する
  （未列挙ref件数が0であることをassert）。`tests/doctor-ref-coverage-completeness.test.ts`として
  新設する。
- GH-03: `helix doctor source-ref-freshness-sla`（新設doctor gate）を実装し、
  `schemas/source-inventory.schema.json`（`next_reaudit_due`・`commits_behind_upstream`を含む
  改訂版）に対する2種のfixture（本パッケージの`validation/fixtures/source-inventory-fresh.json`・
  `validation/fixtures/source-inventory-stale.json`を初期値として流用可）で、
  (1) 全required項目を満たすvalid fixtureがajvで正しくvalidateされること、
  (2) observed_atが30日超過またはcommits_behind_upstreamが10超過かつre-audit未記録のfixtureに
  対してはgateがfail-closeすることを検証する。両ケースを`tests/source-freshness-sla.test.ts`として
  実装し、CIの`helix doctor`経由で実行する。

## TODO: internal-consistency是正（IC-01〜IC-04）由来の将来リポジトリ側テスト

本パッケージ内で完結する検証（acceptance-criteria.yaml `count`/実要素数/`13-acceptance-criteria.md`
本文件数の三者一致、`19-v0.4.0-errata.md`改名とREADMEリンク解決、`change-delta-v0.3.2.yaml`の
current_state/next_state整合、`requirements-catalog.yaml` statusのdelta chain終端一致、
`validation/check-chat-trace-closure.py`によるCHAT-ID×要件単位のtraceability突合、
`14-risks-and-open-decisions.md`/`decisions/decision-ledger.md`相互参照、MANIFEST.json
`roles.decision_ledger`キー整合）はこのセッションで実行済み（下記 self_checks 参照）。
リポジトリ本体側で新設すべき機械テスト/CI組み込みのみここにTODOとして記録する。

- IC-01: `13-acceptance-criteria.md`本文の件数claimと`requirements/acceptance-criteria.yaml`の
  `count`/実要素数/`validation/package-validation-report.json`の`catalog_counts`実測値が
  ドキュメント更新のたびに機械的に一致し続けることを検証するCIチェック（例:
  `tests/acceptance-criteria-count-consistency.test.ts`）をリポジトリ側に新設する。
- IC-01附帯所見: 本セッション開始時点で当該3値（`count`フィールド、実要素数、
  `package-validation-report.json`実測値）は111/115/116/163/168など複数の異なる値に分裂しており、
  是正案が前提とした「111」はいずれの実測値とも一致しなかった。本是正は実際に観測された値
  （acceptance=116、requirements=168）へ3箇所を揃えることで内部一貫性を回復した。今後の版で
  カタログ実体が変わった場合、上記CIチェックが機械的にdriftを検出する設計とする。
- IC-02附帯所見: `requirements/change-delta-v0.3.2.yaml`のファイル名（v0.3.2）と自身の
  `next_state`（v0.4.0）および既存`change-delta-v0.4.0.yaml`（current=next=v0.4.0）との
  ファイル命名不整合は本is正の対象外（correction文中で明示的に是正対象外と指定）としたため
  未解消のまま残っている。改名・統合を検討する別PLANをリポジトリ側で起票する。
- IC-03: `validation/check-chat-trace-closure.py`をパッケージ生成/検証パイプラインへ
  自動実行として組み込み（現状は手動実行のみ）、CI（`harness-check`相当）内で
  `requirements-catalog.yaml`更新のたびに要件単位のCHAT-ID trace closureを再検証する
  ステップとして結線する（例: `tests/chat-trace-closure.test.ts`からPythonスクリプトを
  subprocess呼び出しするか、同等ロジックをNode/TSへ移植する）。
- IC-04: `requirements-catalog.yaml`の`decision_refs`欄と`decisions/decision-ledger.md`の
  D-IDが常に整合する（decision_refsに存在しないD-IDを参照しない、D-ID削除時にdecision_refsが
  孤立しない）ことを検証するlintをリポジトリ側`tests/`に新設する。

## TODO: uwrs是正（UWRS-01〜UWRS-04）由来の将来リポジトリ側テスト

本パッケージ内で完結する検証（decision-ledger.md D-009行のNode CLI文言・status=proposed維持の
grep確認、`integration/workflow-engine-integration.md`のHybrid Python adapter表現削除とNode adapter
表現追加の確認、`06-workflow-requirements-judgment-core.md`の実行形態追記・成果物マッピング表の
vendorファイル実在確認、`schemas/derived-requirements.schema.json`のjsonschema contract test
（workflow_id/transition_id欠如instanceのreject確認）、`templates/L4-L6-workflow-judgment-design.template.yaml`の
YAML parse・フィールド形状確認）はこのセッションで実行済み（下記 self_checks 参照）。
リポジトリ本体側で新設すべき機械テストのみここにTODOとして記録する。

- UWRS-02: `schemas/derived-requirements.schema.json`をajvへ登録し、`business_flow`/`screen_flow`/
  `api_requirements`/`data_requirements`/`permission_matrix`/`notification_requirements`/
  `audit_requirements`/`test_scenarios`の各要素にworkflow_id/transition_idが欠落したfixtureで
  validationがfailすることを確認するテスト（`tests/schema-derived-requirements.test.ts`相当）を
  新設する。あわせて`validation/package-validation-report.json`の`derived_requirements_id_consistency`
  checkを、実際のderived-requirementsインスタンス文書が生成された時点で「instances=0」の
  placeholder状態から実測件数（missing/mismatch集計）へ更新する生成ロジックを実装する。
- UWRS-03: `templates/L4-L6-workflow-judgment-design.template.yaml`のswitching_bindings/
  routing_bindings/resource_pool_bindings/allocation_policy_bindingsが、実データ投入後の
  `templates/L3-workflow-contract.template.yaml`インスタンスのswitching/routing/resource_pools/
  allocation_policiesの全IDと1:1でtrace可能であることを検証する`trace_target_integrity`拡張テスト
  （`tests/l4-l6-workflow-judgment-trace.test.ts`相当）を、両テンプレートの実インスタンスデータが
  生成された後にリポジトリ側で新設する。
- UWRS-01: D-009のstatus=proposed→confirmed遷移はPO権限（CLAUDE.md charter §3）であるため、
  `helix doctor plan-claim-discipline`相当のgateが、decision-ledger.mdのstatus列変更コミットに
  PO承認evidence（review_evidenceまたはconfirmation gate記録）が伴わない場合にfail-closeする
  回帰テストをリポジトリ側に新設する。

## TODO: chat-reqs是正（F1 / AC-TRACE-02）由来の将来リポジトリ側テスト

本パッケージ内で完結する検証（`requirements/acceptance-criteria.yaml`の`count`/実要素数一致、
`validation/package-validation-report.json`の`catalog_counts`/`summary`数値一致、
`scripts/verify-chat-provenance.py`のproposal JSON出力とexit code、`inventory/chat-requirements.yaml`
全CHAT-IDと`inventory/chat-requirements-provenance.yaml`の1:1対応）はこのセッションで実行済み
（下記 self_checks 参照）。リポジトリ本体側で新設すべき機械テストのみここにTODOとして記録する。

- F1-01 (AC-TRACE-02): `scripts/verify-chat-provenance.py`のproposal JSON出力をNode側
  control-planeが再検証するテスト（両入力YAMLをNode自身が読み直してdigest/件数を再計算し、
  proposalの`inputs.*_digest`・`chat_ids_total`・`provenance_records_total`と突合、かつ出力JSONの
  schema検証を行う）を`tests/chat-provenance-node-reverify.test.ts`相当としてリポジトリ側に新設する。
  ADR-009によりPythonのexit 0単独をgate合否として直接信用してはならない。
- F1-02: `requirements/acceptance-criteria.yaml`の`count`/実要素数/
  `validation/package-validation-report.json`の`catalog_counts`実測値が、ドキュメント更新のたびに
  機械的に一致し続けることを検証するCIチェック（IC-01と同一の`tests/acceptance-criteria-count-consistency.test.ts`
  相当に統合可能）をリポジトリ側に新設する。
