# Existing Python / Node Boundary Contract

本章の境界定義はADR-009-node-python-linux-runtime.md（accepted）に従属する。ADR-009が改定された場合、本章とHBR-ARCH-*群は同一PLANで追補されなければならない。

## Python sourceの扱い

正本実装は現行`hybrid-docgen/tools/*.py`です。全面再実装・一括移設は行いません。

Pythonが所有するもの:

- 122文書catalog、profiles、activation
- schema/type validation
- requirement/spec/workflow normalization
- trace derivation/closure
- impact/diff/coverage/schedule
- deterministic detectorとadversarial review packet
- agent purpose digest
- 文書・表・図のgenerated output生成

## Python write boundary

Pythonは次だけを書けます。

- temporary workspace
- `build/`等のgenerated projection
- Nodeが発行したstaging directory

PythonはGit/GitHub/provider、canonical source promotion、approval record、release actionを直接実行しません。既存toolに該当処理がある場合はwrapまたはpatchしてNode portへ移します。

## Nodeが所有するもの

- CLIとprocess lifecycle
- Git/GitHub/provider adapter
- hook/CI adapter
- canonical file promotion、receipt、lease
- SQLite transaction coordinatorとprojection writer
- Web/IDE surface
- subagent launchとHARNESS capsule delivery

## Compatibility strategy

- 既存`python3 tools/<tool>.py ...`は互換期間中維持する。互換期間の終了条件 = ADR-009 terminal cutover receipt発行（Bun
  known-goodがactive execution graph外の固定commit／content-addressed artifact／DB backupとして保存された時点）。
  terminal receipt発行後はレガシーCLIをhistorical参照allowlistへ降格し、通常運用のcapability経路から除外する。
- 内部pure functionをsplitしても旧scriptをfacadeとして残す。
- JSON/NDJSON modeはHELIXが呼ぶcommandから追加し、全toolへ一括強制しない。
- stdout protocol modeではJSONだけ、human logはstderr。legacy text modeは明示flagで区別する。
- request ID + payload digestで冪等化する。
- invalid version/schemaはpartial canonical write 0で終了する。

## Promotion

```text
Python staging output
→ Node schema/trace/digest check
→ atomic promote
→ receipt + DB event
```
